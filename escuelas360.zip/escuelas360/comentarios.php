<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
try {
  $pdo->exec("CREATE TABLE IF NOT EXISTS comentarios (id INT AUTO_INCREMENT PRIMARY KEY, escuela_id INT NOT NULL, autor VARCHAR(150) NOT NULL, texto TEXT NOT NULL, estrellas TINYINT NOT NULL DEFAULT 5, fecha DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_comentarios_escuela (escuela_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  try{$pdo->exec("ALTER TABLE comentarios ADD COLUMN usuario_id INT NULL AFTER escuela_id");}catch(Throwable $e){}
  try{$pdo->exec("ALTER TABLE comentarios ADD KEY idx_comentarios_usuario (usuario_id)");}catch(Throwable $e){}
  try{$pdo->exec("ALTER TABLE comentarios ADD CONSTRAINT fk_comentarios_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE");}catch(Throwable $e){}
  $method=$_SERVER['REQUEST_METHOD'];
  if($method==='GET'){
    $id=(int)($_GET['escuela_id']??0); if($id<=0)throw new RuntimeException('Escuela inválida.');
    $st=$pdo->prepare('SELECT id,autor,texto,estrellas,fecha FROM comentarios WHERE escuela_id=? ORDER BY fecha DESC LIMIT 50');$st->execute([$id]);$items=$st->fetchAll();
    $st=$pdo->prepare('SELECT COALESCE(AVG(estrellas),0) promedio,COUNT(*) cantidad FROM comentarios WHERE escuela_id=?');$st->execute([$id]);$stats=$st->fetch()?:['promedio'=>0,'cantidad'=>0];
    echo json_encode(['success'=>true,'comentarios'=>$items,'promedio'=>round((float)$stats['promedio'],1),'cantidad'=>(int)$stats['cantidad']],JSON_UNESCAPED_UNICODE);exit;
  }
  if($method==='POST'){
    if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'error'=>'Iniciá sesión para publicar una reseña.']);exit;}
    $in=json_decode(file_get_contents('php://input'),true)?:$_POST;$id=(int)($in['escuela_id']??0);$texto=trim((string)($in['texto']??''));$stars=max(1,min(5,(int)($in['estrellas']??5)));$uid=(int)$_SESSION['user_id'];
    if($id<=0||$texto===''){http_response_code(400);echo json_encode(['success'=>false,'error'=>'Completá la reseña.']);exit;}
    if(mb_strlen($texto)>2000){http_response_code(400);echo json_encode(['success'=>false,'error'=>'La reseña es demasiado larga.']);exit;}
    $st=$pdo->prepare('SELECT nombre FROM usuarios WHERE id=?');$st->execute([$uid]);$u=$st->fetch();if(!$u)throw new RuntimeException('Usuario no encontrado.');
    $st=$pdo->prepare('INSERT INTO comentarios(escuela_id,usuario_id,autor,texto,estrellas) VALUES(?,?,?,?,?)');$st->execute([$id,$uid,$u['nombre'],$texto,$stars]);
    echo json_encode(['success'=>true,'id'=>(int)$pdo->lastInsertId()],JSON_UNESCAPED_UNICODE);exit;
  }
  http_response_code(405);echo json_encode(['success'=>false,'error'=>'Método no permitido.']);
}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'error'=>$e->getMessage()?:'Error interno.'],JSON_UNESCAPED_UNICODE);}
