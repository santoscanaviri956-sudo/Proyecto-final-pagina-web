<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/google-config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$input=json_decode(file_get_contents('php://input'),true); if(!is_array($input))$input=$_POST;
$token=trim((string)($input['credential']??''));
$password=(string)($input['password']??'');
$mode=(string)($input['mode']??'login');
if($token===''){http_response_code(400);echo json_encode(['success'=>false,'error'=>'No se recibió la credencial de Google.']);exit;}
if(!defined('GOOGLE_CLIENT_ID')||GOOGLE_CLIENT_ID===''){http_response_code(503);echo json_encode(['success'=>false,'error'=>'Google no está configurado en el servidor.']);exit;}
if($mode!=='register' && $mode!=='login')$mode='login';
$url='https://oauth2.googleapis.com/tokeninfo?id_token='.rawurlencode($token); $context=stream_context_create(['http'=>['timeout'=>8,'ignore_errors'=>true]]); $raw=@file_get_contents($url,false,$context); $data=$raw?json_decode($raw,true):null;
if(!is_array($data)||empty($data['sub'])||empty($data['email'])||($data['aud']??'')!==GOOGLE_CLIENT_ID||(($data['email_verified']??'')!=='true'&&($data['email_verified']??'')!==true)){http_response_code(401);echo json_encode(['success'=>false,'error'=>'La cuenta de Google no pudo ser verificada.']);exit;}
$email=strtolower(trim((string)$data['email'])); $nombre=trim((string)($data['name']??$data['given_name']??'Usuario')); $googleSub=(string)$data['sub'];
if(strlen($password)>0 && strlen($password)<6){http_response_code(400);echo json_encode(['success'=>false,'error'=>'La contraseña debe tener al menos 6 caracteres.']);exit;}
try{
  $stmt=$pdo->prepare('SELECT id,nombre,email,password,birth_year,google_sub FROM usuarios WHERE email=? LIMIT 1');$stmt->execute([$email]);$u=$stmt->fetch();
  if($mode==='register'){
    if($u){http_response_code(409);echo json_encode(['success'=>false,'error'=>'Ese correo ya tiene una cuenta. Iniciá sesión con esa cuenta.']);exit;}
    if($password===''){echo json_encode(['success'=>true,'needs_google_password'=>true],JSON_UNESCAPED_UNICODE);exit;}
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $st=$pdo->prepare('INSERT INTO usuarios(nombre,email,password,birth_year,google_sub) VALUES(?,?,?,?,?)');$st->execute([$nombre,$email,$hash,null,$googleSub]);
    $id=(int)$pdo->lastInsertId(); $u=['id'=>$id,'nombre'=>$nombre,'email'=>$email,'birth_year'=>null];
  } else {
    if(!$u){http_response_code(404);echo json_encode(['success'=>false,'error'=>'No existe una cuenta con ese correo. Registrate primero con Google.']);exit;}
    if($password===''){echo json_encode(['success'=>true,'needs_google_password'=>true],JSON_UNESCAPED_UNICODE);exit;}
    if(!password_verify($password,(string)$u['password'])){http_response_code(401);echo json_encode(['success'=>false,'error'=>'La contraseña de Colegio 360 es incorrecta.']);exit;}
    $st=$pdo->prepare('UPDATE usuarios SET nombre=?,google_sub=? WHERE id=?');$st->execute([$nombre,$googleSub,(int)$u['id']]);
    $u['nombre']=$nombre;
  }
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS configuraciones_usuario (id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL UNIQUE, tema VARCHAR(20) NOT NULL DEFAULT 'light', texto_grande TINYINT(1) NOT NULL DEFAULT 0, nivel_preferido VARCHAR(50) NULL, barrio_preferido VARCHAR(100) NULL, orientacion_preferida VARCHAR(100) NULL, notificaciones_email TINYINT(1) NOT NULL DEFAULT 1, actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, CONSTRAINT fk_config_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->prepare('INSERT IGNORE INTO configuraciones_usuario(usuario_id) VALUES(?)')->execute([(int)$u['id']]);
  } catch (Throwable $e) {}
  session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; $_SESSION['user_name']=$u['nombre'];
  echo json_encode(['success'=>true,'user'=>['id'=>(int)$u['id'],'nombre'=>$u['nombre'],'email'=>$u['email'],'birth_year'=>$u['birth_year']??null]],JSON_UNESCAPED_UNICODE);
}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'error'=>'No se pudo guardar o validar la cuenta de Google.']);}
