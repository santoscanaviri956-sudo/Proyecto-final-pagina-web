<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'error'=>'Sesión no iniciada.'],JSON_UNESCAPED_UNICODE);exit;}
$userId=(int)$_SESSION['user_id'];
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS configuraciones_usuario (
    id INT NOT NULL AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    tema VARCHAR(20) NOT NULL DEFAULT 'claro',
    texto_grande TINYINT(1) NOT NULL DEFAULT 0,
    nivel_preferido VARCHAR(50) DEFAULT NULL,
    barrio_preferido VARCHAR(100) DEFAULT NULL,
    orientacion_preferida VARCHAR(100) DEFAULT NULL,
    notificaciones_email TINYINT(1) NOT NULL DEFAULT 1,
    actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY(id), UNIQUE KEY uq_config_usuario(usuario_id),
    CONSTRAINT fk_config_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  foreach([
    'texto_grande'=>'TINYINT(1) NOT NULL DEFAULT 0',
    'nivel_preferido'=>'VARCHAR(50) DEFAULT NULL',
    'barrio_preferido'=>'VARCHAR(100) DEFAULT NULL',
    'orientacion_preferida'=>'VARCHAR(100) DEFAULT NULL',
    'notificaciones_email'=>'TINYINT(1) NOT NULL DEFAULT 1',
    'actualizado_en'=>'DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
  ] as $c=>$def){try{$pdo->exec("ALTER TABLE configuraciones_usuario ADD COLUMN `$c` $def");}catch(Throwable $e){}}
  $pdo->prepare('INSERT IGNORE INTO configuraciones_usuario(usuario_id,notificaciones_email) SELECT id,COALESCE(notif_email,1) FROM usuarios WHERE id=?')->execute([$userId]);
  $in=json_decode(file_get_contents('php://input'),true);if(!is_array($in))$in=$_POST;
  $action=(string)($in['action']??'get');
  $pdo->exec("CREATE TABLE IF NOT EXISTS favoritos (id INT NOT NULL AUTO_INCREMENT, usuario_id INT NOT NULL, escuela_id INT NOT NULL, fecha_guardado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id), UNIQUE KEY uq_favorito_usuario_escuela(usuario_id,escuela_id), KEY idx_favoritos_usuario(usuario_id), KEY idx_favoritos_escuela(escuela_id), CONSTRAINT fk_favoritos_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS comparaciones (id INT NOT NULL AUTO_INCREMENT, usuario_id INT NOT NULL, escuela_id INT NOT NULL, fecha_agregado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id), UNIQUE KEY uq_comparacion_usuario_escuela(usuario_id,escuela_id), KEY idx_comparaciones_usuario(usuario_id), KEY idx_comparaciones_escuela(escuela_id), CONSTRAINT fk_comparaciones_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $readList=function(string $table)use($pdo,$userId){$st=$pdo->prepare("SELECT escuela_id FROM {$table} WHERE usuario_id=? ORDER BY id ASC");$st->execute([$userId]);return array_map('strval',array_column($st->fetchAll(),'escuela_id'));};
  $read=function()use($pdo,$userId){$s=$pdo->prepare('SELECT tema,texto_grande,nivel_preferido,barrio_preferido,orientacion_preferida,notificaciones_email,actualizado_en FROM configuraciones_usuario WHERE usuario_id=? LIMIT 1');$s->execute([$userId]);$r=$s->fetch()?:[];return ['tema'=>($r['tema']??'claro'),'texto_grande'=>(bool)($r['texto_grande']??false),'nivel_preferido'=>$r['nivel_preferido']??'','barrio_preferido'=>$r['barrio_preferido']??'','orientacion_preferida'=>$r['orientacion_preferida']??'','notificaciones_email'=>(bool)($r['notificaciones_email']??true),'actualizado_en'=>$r['actualizado_en']??null];};
  if($action==='get'){echo json_encode(['success'=>true,'settings'=>$read(),'favorites'=>$readList('favoritos'),'compare'=>$readList('comparaciones')],JSON_UNESCAPED_UNICODE);exit;}
  if($action==='clear'){ $pdo->beginTransaction(); $pdo->prepare('DELETE FROM favoritos WHERE usuario_id=?')->execute([$userId]); $pdo->prepare('DELETE FROM comparaciones WHERE usuario_id=?')->execute([$userId]); $pdo->commit(); echo json_encode(['success'=>true,'favorites'=>[],'compare'=>[]],JSON_UNESCAPED_UNICODE); exit; }
  if($action==='replace' || $action==='sync'){
    $fav=array_values(array_unique(array_filter(array_map('intval',(array)($in['favorites']??[])),fn($v)=>$v>0)));
    $cmp=array_slice(array_values(array_unique(array_filter(array_map('intval',(array)($in['compare']??[])),fn($v)=>$v>0))),0,3);
    $pdo->beginTransaction();
    if($action==='replace'){ $pdo->prepare('DELETE FROM favoritos WHERE usuario_id=?')->execute([$userId]); $pdo->prepare('DELETE FROM comparaciones WHERE usuario_id=?')->execute([$userId]); }
    $sf=$pdo->prepare('INSERT IGNORE INTO favoritos(usuario_id,escuela_id) VALUES(?,?)'); foreach($fav as $id)$sf->execute([$userId,$id]);
    $sc=$pdo->prepare('INSERT IGNORE INTO comparaciones(usuario_id,escuela_id) VALUES(?,?)'); foreach($cmp as $id)$sc->execute([$userId,$id]);
    $pdo->commit(); echo json_encode(['success'=>true,'favorites'=>$readList('favoritos'),'compare'=>$readList('comparaciones')],JSON_UNESCAPED_UNICODE); exit;
  }
  if($action==='save'){
    $sets=[];$vals=[];
    if(array_key_exists('tema',$in)){ $sets[]='tema=?'; $vals[]=(($in['tema']??'')==='dark'?'dark':'light'); }
    if(array_key_exists('texto_grande',$in)){ $sets[]='texto_grande=?'; $vals[]=!empty($in['texto_grande'])?1:0; }
    if(array_key_exists('nivel_preferido',$in)){ $v=trim((string)($in['nivel_preferido']??'')); if((function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v))>50) throw new RuntimeException('El nivel preferido es demasiado largo.'); $sets[]='nivel_preferido=?'; $vals[]=$v?:null; }
    if(array_key_exists('barrio_preferido',$in)){ $v=trim((string)($in['barrio_preferido']??'')); if((function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v))>100) throw new RuntimeException('La zona preferida es demasiado larga.'); $sets[]='barrio_preferido=?'; $vals[]=$v?:null; }
    if(array_key_exists('orientacion_preferida',$in)){ $v=trim((string)($in['orientacion_preferida']??'')); if((function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v))>100) throw new RuntimeException('La orientación preferida es demasiado larga.'); $sets[]='orientacion_preferida=?'; $vals[]=$v?:null; }
    if(array_key_exists('notificaciones_email',$in)){ $sets[]='notificaciones_email=?'; $vals[]=!empty($in['notificaciones_email'])?1:0; }
    if($sets){ $vals[]=$userId; $st=$pdo->prepare('UPDATE configuraciones_usuario SET '.implode(',',$sets).' WHERE usuario_id=?'); $st->execute($vals); }
    echo json_encode(['success'=>true,'settings'=>$read()],JSON_UNESCAPED_UNICODE);exit;
  }
  if($action==='search'){
    $nivel=trim((string)($in['nivel_preferido']??''));$zona=trim((string)($in['barrio_preferido']??''));$ori=trim((string)($in['orientacion_preferida']??''));
    if((function_exists('mb_strlen')?mb_strlen($ori,'UTF-8'):strlen($ori))>100) throw new RuntimeException('La orientación preferida es demasiado larga.');
    $st=$pdo->prepare('UPDATE configuraciones_usuario SET nivel_preferido=?,barrio_preferido=?,orientacion_preferida=? WHERE usuario_id=?');$st->execute([$nivel?:null,$zona?:null,$ori?:null,$userId]);
    echo json_encode(['success'=>true,'settings'=>$read()],JSON_UNESCAPED_UNICODE);exit;
  }
  throw new RuntimeException('Acción no válida.');
}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'error'=>'No se pudieron guardar las preferencias.'],JSON_UNESCAPED_UNICODE);}
