<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

$email = strtolower(trim((string)($input['email'] ?? '')));
$password = (string)($input['password'] ?? '');

if ($email === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Completá correo y contraseña.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El correo electrónico no es válido.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    try { $pdo->exec("ALTER TABLE usuarios ADD COLUMN birth_year SMALLINT NULL"); } catch (Throwable $e) {}

    $stmt = $pdo->prepare('SELECT id, nombre, email, password, birth_year FROM usuarios WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if (!$usuario || !password_verify($password, $usuario['password'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Correo o contraseña incorrectos.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$usuario['id'];
    $_SESSION['user_name'] = $usuario['nombre'];

    echo json_encode([
        'success' => true,
        'user' => [
            'id' => (int)$usuario['id'],
            'nombre' => $usuario['nombre'],
            'email' => $usuario['email'],
            'birth_year' => $usuario['birth_year'] ?? null
        ]
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error al validar las credenciales.'], JSON_UNESCAPED_UNICODE);
}
