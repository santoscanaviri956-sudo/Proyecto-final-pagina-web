<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$_SESSION=[];
if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],(bool)$p['secure'],(bool)$p['httponly']); }
session_destroy();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') { header('Location: ' . (($return = $_GET['return'] ?? 'inicio.html') && !preg_match('/^https?:\/\//i', $return) ? ltrim($return, '/') : 'inicio.html')); exit; }
header('Content-Type: application/json; charset=utf-8'); echo json_encode(['success'=>true],JSON_UNESCAPED_UNICODE);
