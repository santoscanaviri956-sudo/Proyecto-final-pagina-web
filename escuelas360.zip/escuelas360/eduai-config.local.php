<?php
declare(strict_types=1);

// Copiá este archivo como eduai-config.local.php y agregá una clave NUEVA de Gemini.
// No subas eduai-config.local.php ni compartas su contenido.
return [
    'GEMINI_API_KEY' => 'AQ.Ab8RN6K5KO-gIBGMq4UiUa7xhpp3UIICfQ6uYxC-fKaJC2IU8Q',
];
