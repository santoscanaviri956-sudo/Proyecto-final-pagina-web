<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['success'=>false,'error'=>'Necesitás iniciar sesión.'],JSON_UNESCAPED_UNICODE); exit; }
try {
  foreach (['birth_year'=>'SMALLINT NULL','zona'=>'VARCHAR(100) NULL','telefono'=>'VARCHAR(40) NULL','direccion'=>'VARCHAR(190) NULL','dni'=>'VARCHAR(30) NULL'] as $col=>$def) { try{$pdo->exec("ALTER TABLE usuarios ADD COLUMN `$col` $def");}catch(Throwable $e){} }
  if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $st=$pdo->prepare('SELECT id,nombre,email,birth_year,zona,telefono,direccion,dni FROM usuarios WHERE id=? LIMIT 1');$st->execute([(int)$_SESSION['user_id']]);$u=$st->fetch();
    if(!$u) throw new RuntimeException('Usuario no encontrado.');
    echo json_encode(['success'=>true,'user'=>$u],JSON_UNESCAPED_UNICODE); exit;
  }
  $in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
  $nombre=trim((string)($in['nombre']??'')); $birth=(int)($in['birth_year']??0); $zona=trim((string)($in['zona']??'')); $tel=trim((string)($in['telefono']??'')); $dir=trim((string)($in['direccion']??'')); $dni=trim((string)($in['dni']??''));
  if($nombre==='') throw new RuntimeException('El nombre no puede quedar vacío.');
  if($birth && ($birth<1900 || $birth>(int)date('Y'))) throw new RuntimeException('El año de nacimiento no es válido.');
  if(mb_strlen($nombre)>150||mb_strlen($zona)>100||mb_strlen($tel)>40||mb_strlen($dir)>190||mb_strlen($dni)>30) throw new RuntimeException('Algún dato supera el límite permitido.');
  $st=$pdo->prepare('UPDATE usuarios SET nombre=?,birth_year=?,zona=?,telefono=?,direccion=?,dni=? WHERE id=?');
  $st->execute([$nombre,$birth?:null,$zona?:null,$tel?:null,$dir?:null,$dni?:null,(int)$_SESSION['user_id']]);
  $_SESSION['user_name']=$nombre;
  echo json_encode(['success'=>true,'user'=>['nombre'=>$nombre,'birth_year'=>$birth?:null,'zona'=>$zona,'telefono'=>$tel,'direccion'=>$dir,'dni'=>$dni]],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){http_response_code(400);echo json_encode(['success'=>false,'error'=>$e->getMessage() ?: 'No se pudo guardar el perfil.'],JSON_UNESCAPED_UNICODE);}
