<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

$nombre = trim((string)($input['nombre'] ?? ''));
$email = strtolower(trim((string)($input['email'] ?? '')));
$password = (string)($input['password'] ?? '');
$birthYear = (int)($input['birth_year'] ?? 0);

if ($nombre === '' || $email === '' || $password === '' || $birthYear === 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Completá nombre, correo, año de nacimiento y contraseña.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El correo electrónico no es válido.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (mb_strlen($nombre) > 150) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El nombre es demasiado largo.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($birthYear < 1900 || $birthYear > (int)date('Y')) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El año de nacimiento no es válido.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'La contraseña debe tener al menos 6 caracteres.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(150) NOT NULL,
        email VARCHAR(190) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        birth_year SMALLINT NULL,
        google_sub VARCHAR(255) NULL UNIQUE,
        creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    try { $pdo->exec("ALTER TABLE usuarios ADD COLUMN birth_year SMALLINT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE usuarios ADD COLUMN google_sub VARCHAR(255) NULL UNIQUE"); } catch (Throwable $e) {}

    $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);

    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'error' => 'Ese correo ya está registrado.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare('INSERT INTO usuarios (nombre, email, password, birth_year) VALUES (?, ?, ?, ?)');
    $stmt->execute([$nombre, $email, $hash, $birthYear]);

    if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
    session_regenerate_id(true);
    $newUserId = (int)$pdo->lastInsertId();
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS configuraciones_usuario (id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL UNIQUE, tema VARCHAR(20) NOT NULL DEFAULT 'light', texto_grande TINYINT(1) NOT NULL DEFAULT 0, nivel_preferido VARCHAR(50) NULL, barrio_preferido VARCHAR(100) NULL, orientacion_preferida VARCHAR(100) NULL, notificaciones_email TINYINT(1) NOT NULL DEFAULT 1, actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, CONSTRAINT fk_config_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->prepare('INSERT IGNORE INTO configuraciones_usuario(usuario_id) VALUES(?)')->execute([$newUserId]);
    } catch (Throwable $e) {}
    $_SESSION['user_id'] = $newUserId;
    $_SESSION['user_name'] = $nombre;

    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $newUserId,
            'nombre' => $nombre,
            'email' => $email,
            'birth_year' => $birthYear
        ]
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error al registrar el usuario en la base de datos.'], JSON_UNESCAPED_UNICODE);
}
