(() => {
  const $ = id => document.getElementById(id);
  const TEXT_KEY = 'colegio360-text-size', NIVEL_KEY='c360_default_nivel', ZONA_KEY='c360_default_zona', ORI_KEY='c360_default_orientation';
  const root=document.documentElement;
  const textToggle=$('text-size-toggle');
  function applyTextSize(large){root.setAttribute('data-text-size',large?'large':'normal');if(textToggle){textToggle.classList.toggle('is-on',large);textToggle.setAttribute('aria-checked',large?'true':'false');}}
  function saveServerSettings(extra={}){
    fetch('preferencias.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save',tema:window.Colegio360Theme?.get?.()||root.getAttribute('data-theme')||'light',texto_grande:root.getAttribute('data-text-size')==='large',nivel_preferido:$('default-nivel')?.value||'',barrio_preferido:$('default-zona')?.value||'',orientacion_preferida:$('default-orientacion')?.value||'',...extra})}).catch(()=>{});
  }
  applyTextSize(localStorage.getItem(TEXT_KEY)==='large');
  textToggle?.addEventListener('click',()=>{const large=root.getAttribute('data-text-size')!=='large';localStorage.setItem(TEXT_KEY,large?'large':'normal');applyTextSize(large);saveServerSettings();});

  const nivelSel=$('default-nivel'),zonaSel=$('default-zona'),oriSel=$('default-orientacion'),searchStatus=$('search-pref-status');
  function loadSettings(){
    fetch('preferencias.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():null).then(d=>{
      if(!d?.success) return;
      const s=d.settings||{};
      if(s.tema){ localStorage.setItem('colegio360-theme',s.tema==='dark'?'dark':'light'); window.Colegio360Theme?.apply(s.tema==='dark'?'dark':'light'); }
      if(nivelSel) nivelSel.value=s.nivel_preferido||localStorage.getItem(NIVEL_KEY)||'';
      if(zonaSel) zonaSel.value=s.barrio_preferido||localStorage.getItem(ZONA_KEY)||'';
      if(oriSel) oriSel.value=s.orientacion_preferida||localStorage.getItem(ORI_KEY)||'';
      if(s.texto_grande!==undefined){localStorage.setItem(TEXT_KEY,s.texto_grande?'large':'normal');applyTextSize(!!s.texto_grande);}
    }).catch(()=>{
      if(nivelSel)nivelSel.value=localStorage.getItem(NIVEL_KEY)||''; if(zonaSel)zonaSel.value=localStorage.getItem(ZONA_KEY)||''; if(oriSel)oriSel.value=localStorage.getItem(ORI_KEY)||'';
    });
  }
  loadSettings();
  $('save-search-pref')?.addEventListener('click',()=>{
    localStorage.setItem(NIVEL_KEY,nivelSel.value);localStorage.setItem(ZONA_KEY,zonaSel.value);localStorage.setItem(ORI_KEY,oriSel?.value||'');
    fetch('preferencias.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'search',nivel_preferido:nivelSel.value,barrio_preferido:zonaSel.value,orientacion_preferida:oriSel?.value||''})}).then(r=>r.json()).then(d=>{
      if(!d.success)throw new Error(d.error||'No se pudo guardar.');
      if(searchStatus){searchStatus.textContent='Preferencia guardada en tu cuenta ✓';searchStatus.className='account-status success';setTimeout(()=>searchStatus.textContent='',2600);}
    }).catch(()=>{if(searchStatus){searchStatus.textContent='Guardado localmente. Iniciá sesión para sincronizar tu cuenta.';searchStatus.className='account-status';}});
  });

  const confirmModal=$('confirm-modal');
  function openConfirm({title,text,extraHTML='',acceptLabel='Confirmar',onAccept}){$('confirm-modal-title').textContent=title;$('confirm-modal-text').textContent=text;$('confirm-modal-extra').innerHTML=extraHTML;$('confirm-modal-accept').textContent=acceptLabel;$('confirm-modal-status').textContent='';confirmModal.classList.add('is-open');document.body.classList.add('modal-open');$('confirm-modal-accept').onclick=async()=>{await onAccept?.();};}
  function closeConfirm(){confirmModal.classList.remove('is-open');document.body.classList.remove('modal-open');}
  $('confirm-modal-close')?.addEventListener('click',closeConfirm);$('confirm-modal-cancel')?.addEventListener('click',closeConfirm);

  $('clear-favorites-btn')?.addEventListener('click',async e=>{e.preventDefault();const session=await getSession();if(!session.authenticated){location.href='login.html?return=ajustes.html';return;}openConfirm({title:'Borrar favoritos y comparaciones',text:'Esto borra de tu cuenta todos los colegios guardados en Favoritos y Comparar. No se puede deshacer.',acceptLabel:'Borrar',onAccept:async()=>{const status=$('confirm-modal-status');status.textContent='Borrando…';try{const r=await fetch('preferencias.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'clear'})});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.error||'No se pudieron borrar los datos.');localStorage.removeItem('c360_favorites');localStorage.removeItem('c360_compare');status.textContent='Listo, se borraron tus favoritos y comparaciones.';status.className='account-status success';setTimeout(closeConfirm,1400);}catch(err){status.textContent=err.message||'No se pudieron borrar los datos.';status.className='account-status error';}}});});

  async function getSession(){try{const r=await fetch('session.php',{credentials:'same-origin',cache:'no-store'});return await r.json();}catch(_){return{authenticated:false};}}
  function setupNotif(){const toggle=$('notif-toggle'),note=$('notif-login-note');note?.remove();toggle.disabled=false;fetch('notificaciones.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{if(d.success){toggle.classList.toggle('is-on',d.notif_email);toggle.setAttribute('aria-checked',d.notif_email?'true':'false');}});toggle.addEventListener('click',()=>{const next=!toggle.classList.contains('is-on');toggle.disabled=true;fetch('notificaciones.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({notif_email:next})}).then(r=>r.json()).then(d=>{toggle.disabled=false;if(d.success){toggle.classList.toggle('is-on',d.notif_email);toggle.setAttribute('aria-checked',d.notif_email?'true':'false');}}).catch(()=>toggle.disabled=false);});}
  function setupPassword(){$('password-login-note')?.remove();const form=$('password-form');form.hidden=false;form.addEventListener('submit',async e=>{e.preventDefault();const status=$('password-status'),actual=$('pwd-actual').value,nueva=$('pwd-nueva').value,repetir=$('pwd-repetir').value;if(nueva!==repetir){status.textContent='La nueva contraseña no coincide en ambos campos.';status.className='account-status error';return;}status.textContent='Guardando…';try{const r=await fetch('cambiar-password.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({actual,nueva})});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.error||'No se pudo cambiar la contraseña.');status.textContent='Contraseña actualizada ✓';status.className='account-status success';form.reset();}catch(err){status.textContent=err.message||'No se pudo cambiar la contraseña.';status.className='account-status error';}});}
  function setupDeleteAccount(){$('delete-account-btn')?.addEventListener('click',e=>{e.preventDefault();openConfirm({title:'Eliminar mi cuenta',text:'Esta acción borra tu cuenta y todos los datos asociados de forma permanente. Ingresá tu contraseña para confirmar.',acceptLabel:'Eliminar cuenta',extraHTML:'<input type="password" id="delete-account-password" class="confirm-modal-input" placeholder="Tu contraseña" autocomplete="current-password">',onAccept:async()=>{const password=$('delete-account-password')?.value||'',status=$('confirm-modal-status');if(!password){status.textContent='Ingresá tu contraseña.';status.className='account-status error';return;}status.textContent='Eliminando…';try{const r=await fetch('eliminar-cuenta.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({password})});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.error||'No se pudo eliminar la cuenta.');localStorage.removeItem('c360_favorites');localStorage.removeItem('c360_compare');location.href='inicio.html';}catch(err){status.textContent=err.message||'No se pudo eliminar la cuenta.';status.className='account-status error';}}});});}
  getSession().then(session=>{if(session.authenticated){setupNotif();setupPassword();setupDeleteAccount();}else{$('delete-account-btn')?.addEventListener('click',e=>{e.preventDefault();location.href='login.html?return=ajustes.html';});}});
})();
