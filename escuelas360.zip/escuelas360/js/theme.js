(() => {
  const KEY = 'colegio360-theme';
  const root = document.documentElement;
  const meta = document.querySelector('meta[name="theme-color"]') || (() => {
    const m = document.createElement('meta'); m.name = 'theme-color'; document.head.appendChild(m); return m;
  })();

  function normalize(value) { return value === 'dark' ? 'dark' : 'light'; }
  function apply(value) {
    const theme = normalize(value);
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = theme;
    meta.setAttribute('content', theme === 'dark' ? '#0d1c21' : '#f5fafc');
    document.querySelectorAll('[data-theme-choice]').forEach(btn => {
      const active = btn.getAttribute('data-theme-choice') === theme;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    window.dispatchEvent(new CustomEvent('colegio360:themechange', { detail: { theme } }));
  }
  function set(value) { const theme = normalize(value); localStorage.setItem(KEY, theme); apply(theme); syncServer({theme}); }

  let syncTimer = null;
  function syncServer(partial = {}) {
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      if (!window.currentUser && !document.cookie.includes('PHPSESSID')) return;
      fetch('preferencias.php', {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'save', tema:root.getAttribute('data-theme') || 'light', texto_grande:document.documentElement.getAttribute('data-text-size') === 'large', ...partial})}).catch(()=>{});
    }, 150);
  }
  document.addEventListener('colegio360:userchange', () => {
    fetch('preferencias.php', {credentials:'same-origin', cache:'no-store'}).then(r=>r.ok?r.json():null).then(d=>{
      if (!d?.success) return;
      const s=d.settings||{};
      if(s.tema) { localStorage.setItem(KEY, normalize(s.tema)); apply(s.tema); }
      if(typeof s.texto_grande === 'boolean') { localStorage.setItem('colegio360-text-size',s.texto_grande?'large':'normal'); document.documentElement.setAttribute('data-text-size',s.texto_grande?'large':'normal'); }
    }).catch(()=>{});
  });

  const saved = localStorage.getItem(KEY);
  apply(saved || 'light');
  document.addEventListener('DOMContentLoaded', () => apply(root.getAttribute('data-theme') || saved || 'light'), { once:true });
  window.Colegio360Theme = { get: () => root.getAttribute('data-theme') || 'light', set, apply };
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-theme-choice]');
    if (!btn) return;
    e.preventDefault();
    set(btn.getAttribute('data-theme-choice'));
  });
})();
