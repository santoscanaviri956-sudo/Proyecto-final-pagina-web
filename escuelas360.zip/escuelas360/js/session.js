(() => {
  window.currentUser = null;
  const menu = document.getElementById('profile-menu-wrap');
  const login = document.getElementById('login-btn');
  const register = document.getElementById('register-btn');
  const set = (id,v) => { const e=document.getElementById(id); if(e) e.value=v ?? ''; };
  const text = (id,v) => { const e=document.getElementById(id); if(e) e.textContent=v ?? ''; };
  function fillProfile(u){
    text('profile-name-short', u.nombre || 'Mi perfil'); text('profile-heading-name', u.nombre || 'Mi perfil'); text('profile-email-view', u.email || '');
    set('profile-nombre',u.nombre);set('profile-birth',u.birth_year);set('profile-zona',u.zona);set('profile-telefono',u.telefono);set('profile-direccion',u.direccion);set('profile-dni',u.dni);
  }
  async function loadProfile(){
    const r=await fetch('perfil.php',{credentials:'same-origin',cache:'no-store'}); if(!r.ok) throw new Error('perfil'); return r.json();
  }
  function initProfileForm(){
    const form=document.getElementById('profile-form'); if(!form) return;
    form.addEventListener('submit',async e=>{e.preventDefault(); const status=document.getElementById('profile-status'); if(status) status.textContent='Guardando…';
      const payload={nombre:document.getElementById('profile-nombre')?.value.trim(),birth_year:Number(document.getElementById('profile-birth')?.value||0),zona:document.getElementById('profile-zona')?.value.trim(),telefono:document.getElementById('profile-telefono')?.value.trim(),direccion:document.getElementById('profile-direccion')?.value.trim(),dni:document.getElementById('profile-dni')?.value.trim()};
      try{const r=await fetch('perfil.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.error);window.currentUser={...window.currentUser,...d.user};fillProfile(window.currentUser);document.dispatchEvent(new CustomEvent('colegio360:userchange',{detail:window.currentUser}));if(status)status.textContent='Perfil guardado ✓';setTimeout(()=>{if(status)status.textContent='';},2200);}catch(err){if(status)status.textContent=err.message||'No se pudo guardar';}
    });
  }
  fetch('session.php',{credentials:'same-origin',cache:'no-store'})
    .then(r=>r.json())
    .then(async data=>{
      window.currentUser=data.authenticated?data.user:null;
      document.dispatchEvent(new CustomEvent('colegio360:userchange',{detail:window.currentUser}));
      if(window.currentUser){
        if(login) login.style.display='none'; if(register) register.style.display='none';
        if(menu) { menu.hidden=false; fillProfile(window.currentUser); initProfileForm(); loadProfile().then(d=>{if(d.success&&d.user){window.currentUser={...window.currentUser,...d.user};fillProfile(window.currentUser);}}).catch(()=>{}); }
      } else { if(menu) menu.hidden=true; }
    })
    .catch(()=>{ window.currentUser=null; if(menu) menu.hidden=true; });
})();
