(() => {
  const byId = id => document.getElementById(id);
  const setText = (id, value) => { const el = byId(id); if (el) el.textContent = value ?? ''; };
  const setValue = (id, value) => { const el = byId(id); if (el) el.value = value ?? ''; };

  async function getSession() {
    const r = await fetch('session.php', { credentials: 'same-origin', cache: 'no-store' });
    if (!r.ok) throw new Error('No se pudo comprobar la sesión.');
    return r.json();
  }

  async function getProfile() {
    const r = await fetch('perfil.php', { credentials: 'same-origin', cache: 'no-store' });
    if (!r.ok) throw new Error('No se pudo cargar el perfil.');
    return r.json();
  }

  function fill(u) {
    if (!u) return;
    setText('account-name', u.nombre || 'Mi perfil');
    setText('account-email', u.email || '');
    setText('account-initial', (u.nombre || 'U').trim().charAt(0).toUpperCase());
    setValue('profile-nombre', u.nombre);
    setValue('profile-birth', u.birth_year);
    setValue('profile-zona', u.zona);
    setValue('profile-telefono', u.telefono);
    setValue('profile-direccion', u.direccion);
    setValue('profile-dni', u.dni);
    setText('profile-summary-name', u.nombre || 'Sin completar');
    setText('profile-summary-email', u.email || 'Sin correo');
    setText('profile-summary-zone', u.zona || 'Todavía no agregada');
  }

  function bindForm() {
    const form = byId('account-profile-form');
    if (!form) return;
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const status = byId('profile-page-status');
      if (status) { status.textContent = 'Guardando cambios…'; status.className = 'account-status'; }
      const payload = {
        nombre: byId('profile-nombre')?.value.trim(),
        birth_year: Number(byId('profile-birth')?.value || 0),
        zona: byId('profile-zona')?.value.trim(),
        telefono: byId('profile-telefono')?.value.trim(),
        direccion: byId('profile-direccion')?.value.trim(),
        dni: byId('profile-dni')?.value.trim()
      };
      try {
        const r = await fetch('perfil.php', { method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
        const d = await r.json();
        if (!r.ok || !d.success) throw new Error(d.error || 'No se pudieron guardar los cambios.');
        fill(d.user);
        if (status) { status.textContent = 'Perfil actualizado correctamente ✓'; status.className = 'account-status success'; }
        window.dispatchEvent(new CustomEvent('colegio360:userchange', { detail:d.user }));
        setTimeout(() => { if (status) status.textContent = ''; }, 2600);
      } catch (err) {
        if (status) { status.textContent = err.message || 'No se pudo guardar.'; status.className = 'account-status error'; }
      }
    });
  }

  function guard() {
    getSession().then(async session => {
      if (!session.authenticated) {
        const target = encodeURIComponent(location.pathname.split('/').pop() + location.search);
        location.href = 'login.html?return=' + target;
        return;
      }
      fill(session.user);
      try { const profile = await getProfile(); if (profile.success && profile.user) fill(profile.user); } catch (_) {}
      bindForm();
    }).catch(() => { location.href = 'login.html?return=inicio.html'; });
  }
  guard();
})();
