(() => {
  'use strict';
  const modal = document.getElementById('feature-modal');
  const content = document.getElementById('feature-content');
  const card = modal?.querySelector('.feature-card');
  const toastStack = document.getElementById('toast-stack');
  const esc = v => String(v ?? '').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  // Los CUE del padrón pueden venir con ceros a la izquierda (ej. 020000100),
  // pero la BD actual los almacena como INT (20000100). Usamos una clave
  // canónica para que favoritos/comparaciones sigan apuntando al mismo colegio.
  const canonicalId = value => {
    const raw = String(value ?? '').trim();
    if (!raw) return '';
    if (/^\d+$/.test(raw)) {
      const n = raw.replace(/^0+(?=\d)/, '');
      return n || '0';
    }
    return raw;
  };
  const key = s => canonicalId(s?.id ?? s?.cue_anexo ?? s?.cue ?? s?.nombre ?? '');
  const name = s => s?.nombre || s?.name || 'Colegio';
  let favorites = [];
  let compare = [];

  // Se cargan exclusivamente desde la cuenta autenticada. Esto evita mostrar
  // selecciones antiguas antes de que session.php confirme qué usuario está activo.
  favorites = [];
  compare = [];

  function loggedIn(){ return !!window.currentUser; }
  function toast(message){
    if (!toastStack) return;
    const el=document.createElement('div'); el.className='toast'; el.textContent=message; toastStack.appendChild(el);
    setTimeout(()=>el.remove(),2800);
  }
  function closeAuthChoice(){ document.getElementById('c360-auth-choice')?.remove(); document.body.classList.remove('modal-open'); }
  function showAuthChoice(){
    if (loggedIn()) return true;
    document.getElementById('c360-auth-choice')?.remove();
    const wrap=document.createElement('div');
    wrap.id='c360-auth-choice'; wrap.className='c360-auth-choice';
    const returnTo=encodeURIComponent(location.pathname.split('/').pop()+'?'+location.search.replace(/^\?/,'')+location.hash);
    wrap.innerHTML=`<div class="c360-auth-choice-card" role="dialog" aria-modal="true" aria-labelledby="c360-auth-title">
      <button class="c360-auth-close" type="button" aria-label="Cerrar">×</button>
      <div class="c360-auth-icon"><i class="fa-regular fa-heart"></i></div>
      <h2 id="c360-auth-title">Iniciá sesión para continuar</h2>
      <p>Para guardar colegios en favoritos o compararlos necesitás tener una cuenta.</p>
      <div class="c360-auth-actions">
        <a class="btn btn-primary" href="login.html?return=${returnTo}">Iniciar sesión</a>
        <a class="btn btn-ghost" href="registro.html?return=${returnTo}">Registrarme</a>
        <a class="c360-google-action" href="login.html?return=${returnTo}&google=1"><span class="c360-google-g">G</span> Continuar con Google</a>
      </div>
    </div>`;
    document.body.appendChild(wrap);
    document.body.classList.add('modal-open');
    const close=()=>closeAuthChoice();
    wrap.querySelector('.c360-auth-close')?.addEventListener('click',close);
    wrap.addEventListener('click',e=>{if(e.target===wrap)close();});
    document.addEventListener('keydown',function handler(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',handler);}}, {once:true});
    requestAnimationFrame(()=>wrap.classList.add('is-open'));
    return false;
  }
  function requireLogin(){ return loggedIn() || showAuthChoice(); }
  let dbReady = false;
  async function dbPreferences(action='get', payload={}) {
    if (!loggedIn()) return null;
    try {
      const r = await fetch('preferencias.php', {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action, ...payload})});
      const d = await r.json();
      if (!r.ok || !d.success) throw new Error(d.error || 'No se pudieron guardar tus preferencias.');
      return d;
    } catch (_) { return null; }
  }
  async function loadDbPreferences(){
    if(!loggedIn()) return;
    // La base de datos es la fuente de verdad al iniciar/cambiar de cuenta.
    // No sincronizamos automáticamente el localStorage hacia la BD porque
    // podría reinsertar selecciones antiguas o pertenecientes a otra sesión.
    const d = await dbPreferences('get');
    if(d?.favorites){
      favorites=d.favorites.map(canonicalId);
      compare=(d.compare||[]).map(canonicalId);
      dbReady=true;
      localStorage.setItem('c360_favorites',JSON.stringify(favorites));
      localStorage.setItem('c360_compare',JSON.stringify(compare));
      syncCounts();
    } else {
      favorites=[];
      compare=[];
      dbReady=false;
      localStorage.removeItem('c360_favorites');
      localStorage.removeItem('c360_compare');
      syncCounts();
    }
  }
  function persist(){
    if (!loggedIn()) return;
    favorites = [...new Set(favorites.map(canonicalId).filter(Boolean))];
    compare = [...new Set(compare.map(canonicalId).filter(Boolean))].slice(0,3);
    localStorage.setItem('c360_favorites', JSON.stringify(favorites));
    localStorage.setItem('c360_compare', JSON.stringify(compare));
  }
  async function persistDb(){
    if(!loggedIn()) return;
    await dbPreferences('replace', {favorites, compare});
  }
  function syncCounts(){
    document.querySelectorAll('#favorites-btn .nav-count').forEach(e=>e.textContent=loggedIn()?favorites.length:0);
    document.querySelectorAll('#compare-btn .nav-count').forEach(e=>e.textContent=loggedIn()?compare.length:0);
    document.querySelectorAll('.save-school').forEach(b=>{
      const active=loggedIn() && favorites.includes(b.dataset.schoolId);
      b.classList.toggle('is-saved',active);
      const i=b.querySelector('i'); if(i){i.className=active?'fa-solid fa-heart':'fa-regular fa-heart';}
      if (b.dataset.label === '1') b.innerHTML=`<i class="${active?'fa-solid':'fa-regular'} fa-heart"></i> ${active?'Guardado':'Guardar'}`;
    });
    document.querySelectorAll('[data-action="compare"]').forEach(b=>{
      const active=loggedIn() && compare.includes(b.dataset.schoolId);
      b.classList.toggle('is-active',active);
      if (b.dataset.label === '1') b.innerHTML=`<i class="fa-solid fa-scale-balanced"></i> ${active?'Quitar':'Comparar'}`;
    });
  }

  function openModal(html, mode='detail', size=0){
    if(!modal || !content) return;
    content.innerHTML=html;
    modal.classList.remove('compare-mode','favorites-mode','detail-mode','size-0','size-1','size-2','size-3');
    modal.classList.add(`${mode}-mode`, `size-${Math.min(Number(size)||0,3)}`);
    modal.classList.add('is-open'); modal.setAttribute('aria-hidden','false');
    document.body.classList.add('modal-open');
    requestAnimationFrame(()=>{ if(card) card.scrollTop=0; if(modal) modal.scrollTop=0; });
  }
  function closeModal(){
    modal?.classList.remove('is-open'); modal?.setAttribute('aria-hidden','true'); document.body.classList.remove('modal-open');
    window.c360CurrentSchool = null;
  }
  document.getElementById('feature-close')?.addEventListener('click',closeModal);
  modal?.addEventListener('click',e=>{if(e.target===modal)closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape' && modal?.classList.contains('is-open'))closeModal();});

  function schoolImage(s){
    return 'assets/escuela-generica.svg';
  }

  async function openDetail(s, from){
    const k=key(s), isFav=loggedIn() && favorites.includes(k), isComp=loggedIn() && compare.includes(k);
    const location=s?.barrio||s?.localidad||s?.location||'Ciudad de Buenos Aires';
    const contact=[s?.telefono,s?.email].filter(Boolean).join(' · ') || 'Sin datos de contacto';
    const services=Array.isArray(s?.servicios)?s.servicios:(s?.servicios?String(s.servicios).split(','):[]);
    const detail=s?.detail || s?.address || [s?.nivel,s?.modalidad,s?.orientacion].filter(Boolean).join(' · ') || 'Institución educativa';
    const img=schoolImage(s);
    window.c360CurrentSchool = {
      id:k, nombre:name(s), nivel:s?.nivel||'', modalidad:s?.modalidad||'', orientacion:s?.orientacion||'',
      barrio:s?.barrio||s?.localidad||'', direccion:s?.direccion||'', gestion:s?.gestion||s?.sector||'',
      telefono:s?.telefono||'', email:s?.email||'', cuota:s?.cuota??null, matricula:s?.matricula??null,
      becas:s?.becas??null, rating:s?.rating??null
    };
    const cameFromFavorites = from === 'favorites';

    // Email: tomamos la primera dirección válida (a veces el padrón trae varias separadas por "/")
    const firstEmail = s?.email ? (String(s.email).match(/[^\s/,;]+@[^\s/,;]+\.[^\s/,;]+/)||[])[0] : '';
    const gmailHref = firstEmail ? `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(firstEmail)}&su=${encodeURIComponent('Consulta sobre '+name(s))}` : '';

    // Instagram: si el padrón trae un perfil lo usamos directo; si no, ayudamos a buscarlo.
    let instaHref, instaLabel;
    if (s?.instagram) {
      const handle = String(s.instagram).trim();
      instaHref = /^https?:\/\//i.test(handle) ? handle : `https://www.instagram.com/${handle.replace(/^@/, '')}`;
      instaLabel = 'Ver perfil';
    } else {
      instaHref = `https://www.google.com/search?q=${encodeURIComponent('instagram ' + name(s) + ' ' + location)}`;
      instaLabel = 'Buscar perfil';
    }
    openModal(`<div class="school-detail-page">
      <div class="school-detail-hero">
        <img src="${esc(img)}" alt="Imagen de ${esc(name(s))}" loading="eager" onerror="this.onerror=null;this.src='assets/escuela-generica.svg';">
        <div class="school-detail-hero-shade"></div>
        <div class="school-detail-hero-content">
          <div class="school-detail-badges"><span>${esc(s?.nivel||'Secundaria')}</span><span>${esc(s?.modalidad||'Común')}</span>${s?.gestion?`<span>${esc(s.gestion)}</span>`:''}</div>
          <h2>${esc(name(s))}</h2><p><i class="fa-solid fa-location-dot"></i> ${esc(location)}${s?.direccion?` · ${esc(s.direccion)}`:''}</p>
        </div>
      </div>
      <div class="school-detail-body"><div class="school-detail-main">
        <section class="school-detail-section school-about"><div class="section-kicker">Información del colegio</div><h3>Conocé esta institución</h3><p class="school-detail-description">${esc(detail)}</p>
          <div class="school-info-grid">
            <div class="school-info-card"><i class="fa-solid fa-location-dot"></i><div><small>Ubicación</small><strong>${esc(location)}</strong></div></div>
            <div class="school-info-card"><i class="fa-solid fa-graduation-cap"></i><div><small>Nivel</small><strong>${esc(s?.nivel||'—')}</strong></div></div>
            <div class="school-info-card"><i class="fa-solid fa-shapes"></i><div><small>Modalidad</small><strong>${esc(s?.modalidad||'—')}</strong></div></div>
            <div class="school-info-card"><i class="fa-solid fa-compass"></i><div><small>Orientación</small><strong>${esc(s?.orientacion||'—')}</strong></div></div>
            <div class="school-info-card"><i class="fa-solid fa-building-columns"></i><div><small>Gestión</small><strong>${esc(s?.gestion||s?.sector||'—')}</strong></div></div>
            <div class="school-info-card"><i class="fa-solid fa-phone"></i><div><small>Contacto</small><strong>${esc(contact)}</strong></div></div>
          </div>
        </section>
        ${services.length?`<section class="school-detail-section"><div class="section-kicker">Propuesta</div><h3>Servicios y características</h3><div class="school-service-list">${services.map(x=>`<span><i class="fa-solid fa-check"></i>${esc(String(x).trim())}</span>`).join('')}</div></section>`:''}
        <section class="school-detail-section school-contact-links"><div class="section-kicker">Contacto y presencia online</div><h3>Encontrá a esta institución</h3><div class="school-links-grid">
          ${s?.telefono?`<a class="school-link-card" href="tel:${esc(String(s.telefono).replace(/[^0-9+]/g,''))}"><i class="fa-solid fa-phone"></i><span><small>Teléfono</small><strong>${esc(s.telefono)}</strong></span></a>`:''}
          ${firstEmail?`<a class="school-link-card" href="${esc(gmailHref)}" target="_blank" rel="noopener"><i class="fa-solid fa-envelope"></i><span><small>Email</small><strong>${esc(firstEmail)}</strong></span></a>`:''}
          ${s?.web_busqueda?`<a class="school-link-card" href="${esc(s.web_busqueda)}" target="_blank" rel="noopener"><i class="fa-solid fa-globe"></i><span><small>Sitio web</small><strong>Visitar / buscar</strong></span></a>`:''}
          <a class="school-link-card" href="${esc(instaHref)}" target="_blank" rel="noopener"><i class="fa-brands fa-instagram"></i><span><small>Instagram</small><strong>${esc(instaLabel)}</strong></span></a>
        </div></section>
        <section class="school-detail-section school-reviews" id="school-reviews">
          <div class="section-kicker">Opiniones</div><h3>Reseñas de la comunidad</h3>
          <div class="reviews-summary"><strong id="reviews-average">—</strong><span id="reviews-stars">☆☆☆☆☆</span><small id="reviews-count">Sin reseñas todavía</small></div>
          <div id="reviews-list" class="reviews-list"><div class="reviews-loading">Cargando reseñas…</div></div>
          <div class="review-form-wrap">
            ${loggedIn()?`<form id="review-form" class="review-form"><label>Tu puntuación<select id="review-stars"><option value="5">5 estrellas</option><option value="4">4 estrellas</option><option value="3">3 estrellas</option><option value="2">2 estrellas</option><option value="1">1 estrella</option></select></label><label>Tu reseña<textarea id="review-text" maxlength="2000" rows="4" placeholder="Contá tu experiencia con esta institución…" required></textarea></label><button class="btn btn-primary" type="submit">Publicar reseña</button><div id="review-status" class="account-status"></div></form>`:`<div class="review-login-note"><strong>¿Estuviste en este colegio?</strong><span>Iniciá sesión para dejar una reseña y una puntuación.</span><button class="btn btn-primary" id="review-login" type="button">Iniciar sesión</button></div>`}
          </div>
        </section>
      </div>
      <aside class="school-detail-side">
        ${cameFromFavorites?`<button class="school-detail-back" id="detail-back-favorites" type="button"><i class="fa-solid fa-arrow-left"></i> Volver a favoritos</button>`:''}
        <button class="school-detail-favorite ${isFav?'is-active':''}" id="detail-favorite-btn" type="button"><i class="${isFav?'fa-solid':'fa-regular'} fa-heart"></i> ${isFav?'Guardado en favoritos':'Guardar en favoritos'}</button>
        <button class="school-detail-compare ${isComp?'is-active':''}" id="detail-compare-btn" type="button"><i class="fa-solid fa-scale-balanced"></i> ${isComp?'Quitar de comparar':'Comparar colegio'}</button>
        <div class="school-side-card"><small>Oferta educativa</small><strong>${esc(s?.oferta_educativa||s?.nivel||'—')}</strong></div>
        <div class="school-side-card"><small>Dirección</small><strong>${esc(s?.direccion||'Ciudad de Buenos Aires')}</strong></div>
      </aside></div></div>`);

    const hero=content.querySelector('.school-detail-hero>img');
    if(hero) hero.src=img;
    content.querySelector('#detail-favorite-btn')?.addEventListener('click',async()=>{
      if(!requireLogin()) return; const exists=favorites.includes(k); favorites=exists?favorites.filter(x=>x!==k):[...favorites,k]; persist(); syncCounts(); await persistDb(); openDetail(s,from);
    });
    content.querySelector('#detail-compare-btn')?.addEventListener('click',async()=>{
      if(!requireLogin()) return; const exists=compare.includes(k); if(exists) compare=compare.filter(x=>x!==k); else {if(compare.length>=3){toast('Podés comparar hasta 3 colegios.');return;} compare=[...compare,k];} persist(); syncCounts(); await persistDb(); openDetail(s,from);
    });
    content.querySelector('#detail-back-favorites')?.addEventListener('click',()=>{ renderFavorites(); });

    const reviewSchoolId=parseInt(k,10);
    const reviewList=content.querySelector('#reviews-list');
    const reviewAvg=content.querySelector('#reviews-average');
    const reviewStars=content.querySelector('#reviews-stars');
    const reviewCount=content.querySelector('#reviews-count');
    const paintReviews=(d)=>{
      if(reviewAvg) reviewAvg.textContent=Number(d.promedio||0).toFixed(1);
      if(reviewStars){const n=Math.round(Number(d.promedio||0));reviewStars.textContent='★'.repeat(n)+'☆'.repeat(5-n);}
      if(reviewCount) reviewCount.textContent=`${d.cantidad||0} reseña${Number(d.cantidad||0)===1?'':'s'}`;
      if(reviewList) reviewList.innerHTML=d.comentarios?.length?d.comentarios.map(c=>`<article class="review-item"><div class="review-item-head"><strong>${esc(c.autor)}</strong><span>${'★'.repeat(Math.max(1,Math.min(5,Number(c.estrellas)||5)))}</span></div><p>${esc(c.texto)}</p><small>${esc(c.fecha||'')}</small></article>`).join(''):'<div class="reviews-empty">Todavía no hay reseñas para este colegio.</div>';
    };
    if(reviewSchoolId>0){
      fetch(`comentarios.php?escuela_id=${reviewSchoolId}`,{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{if(d.success)paintReviews(d);else if(reviewList)reviewList.innerHTML='<div class="reviews-empty">No se pudieron cargar las reseñas.</div>';}).catch(()=>{if(reviewList)reviewList.innerHTML='<div class="reviews-empty">No se pudieron cargar las reseñas.</div>';});
      content.querySelector('#review-form')?.addEventListener('submit',async e=>{e.preventDefault();const status=content.querySelector('#review-status');const text=content.querySelector('#review-text')?.value.trim()||'';const stars=Number(content.querySelector('#review-stars')?.value||5);if(!text)return;status.textContent='Publicando…';try{const r=await fetch('comentarios.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({escuela_id:reviewSchoolId,texto:text,estrellas:stars})});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.error||'No se pudo publicar la reseña.');content.querySelector('#review-form').reset();status.textContent='Reseña publicada ✓';const rr=await fetch(`comentarios.php?escuela_id=${reviewSchoolId}`,{credentials:'same-origin',cache:'no-store'});paintReviews(await rr.json());}catch(err){status.textContent=err.message||'No se pudo publicar la reseña.';status.className='account-status error';}});
      content.querySelector('#review-login')?.addEventListener('click',()=>{if(!requireLogin())return;openDetail(s,from);});
    }
  }

  function renderFavorites(){
    if(!requireLogin()) return;
    const schools=window.schoolLocations||[], items=favorites.map(k=>schools.find(s=>key(s)===canonicalId(k))).filter(Boolean);
    const size=Math.min(items.length,3);
    const empty=items.length===0;
    openModal(`<div class="feature-inner favorites-inner"><div class="compare-heading"><div class="section-kicker">Tu selección</div><h2>Favoritos</h2><p>${items.length?`Tenés ${items.length} colegio${items.length===1?'':'s'} guardado${items.length===1?'':'s'}. Desde acá podés abrir su ficha o quitarlo de tu selección.`:'Todavía no guardaste colegios.'}</p></div>
      ${empty?'<div class="compare-empty"><div class="empty-icon-wrap"><i class="fa-regular fa-heart"></i></div><strong>No tenés favoritos todavía</strong><span>Guardá un colegio desde una tarjeta o desde su ficha. Después vas a poder volver acá para consultarlo rápidamente.</span></div>':`<div class="favorites-grid">${items.map(s=>`<article class="favorite-item"><img src="${esc(schoolImage(s))}" onerror="this.onerror=null;this.src='assets/escuela-generica.svg';" alt=""><div class="favorite-item-body"><div class="favorite-item-heading"><h3>${esc(name(s))}</h3><span class="favorite-badge"><i class="fa-solid fa-heart"></i> Guardado</span></div><p><i class="fa-solid fa-location-dot"></i> ${esc(s.direccion||s.barrio||s.localidad||'CABA')}</p><div class="favorite-item-actions"><button data-fav-view="${esc(key(s))}" class="btn btn-primary">Ver ficha</button><button data-fav-remove="${esc(key(s))}" class="btn btn-ghost favorite-remove"><i class="fa-solid fa-trash-can"></i> Quitar</button></div></div></article>`).join('')}</div>`}</div>`, 'favorites', size);
    content.querySelectorAll('[data-fav-view]').forEach(b=>b.addEventListener('click',()=>{const s=schools.find(x=>key(x)===b.dataset.favView);if(s)openDetail(s,'favorites');}));
    content.querySelectorAll('[data-fav-remove]').forEach(b=>b.addEventListener('click',async()=>{favorites=favorites.filter(x=>x!==b.dataset.favRemove);persist();await persistDb();syncCounts();renderFavorites();}));
  }

  function renderCompare(){
    if(!requireLogin()) return;
    const schools=window.schoolLocations||[], items=compare.map(k=>schools.find(s=>key(s)===canonicalId(k))).filter(Boolean);
    if(items.length===0){openModal('<div class="feature-inner compare-inner"><div class="compare-heading"><div class="section-kicker">Tu selección</div><h2>Compará colegios</h2><p>Todavía no agregaste instituciones.</p></div><div class="compare-empty"><div class="empty-icon-wrap compare-icon"><i class="fa-solid fa-code-compare"></i></div><strong>No hay colegios para comparar</strong><span>Elegí <b>Comparar</b> en las tarjetas o dentro de una ficha. Podés sumar hasta 3 colegios y ver sus diferencias lado a lado.</span></div></div>','compare',0);return;}
    const groups=[
      {name:'Propuesta educativa',icon:'fa-graduation-cap',hint:'Qué ofrece y cómo se organiza la formación.',rows:[['Nivel','nivel'],['Modalidad','modalidad'],['Orientación','orientacion']]},
      {name:'Gestión',icon:'fa-building-columns',hint:'Quién administra la institución.',rows:[['Tipo de gestión','gestion']]},
      {name:'Jornada',icon:'fa-clock',hint:'Cuándo y cómo se desarrolla la jornada escolar.',rows:[['Turno / jornada','jornada']]},
      {name:'Ubicación',icon:'fa-location-dot',hint:'Dónde se encuentra la institución.',rows:[['Dirección','direccion']]},
      {name:'Costos',icon:'fa-wallet',hint:'Información disponible sobre matrícula.',rows:[['Matrícula','matricula']]},
      {name:'Beneficios',icon:'fa-hand-holding-heart',hint:'Ayudas económicas o beneficios registrados.',rows:[['Becas disponibles','becas']]}
    ];
    const value=(s,prop)=>prop==='becas'?(s.becas?'Sí':'No'):prop==='matricula'?(Number(s.matricula||0)?'$'+Number(s.matricula).toLocaleString('es-AR'):'Sin matrícula'):(s[prop]||'—');
    const benefit='La comparación está pensada para leer las diferencias de un vistazo: cada bloque explica qué estás mirando y cada colegio queda en su propia columna.';
    let groupRows='';
    groups.forEach(g=>{
      groupRows += `<tr class="compare-section-row"><th colspan="${items.length+1}"><span class="compare-section-title"><i class="fa-solid ${g.icon}"></i>${esc(g.name)}</span><small>${esc(g.hint)}</small></th></tr>`;
      g.rows.forEach(([label,prop])=>{
        const help={nivel:'Nivel educativo',modalidad:'Tipo de modalidad',orientacion:'Orientación elegida',gestion:'Administración',jornada:'Turno o jornada',direccion:'Ubicación física',matricula:'Costo informado',becas:'Ayuda registrada'}[prop]||'Información';
        groupRows += `<tr class="compare-data-row"><th scope="row"><span class="compare-field-label">${esc(label)}</span><small class="compare-field-help">${esc(help)}</small></th>${items.map(s=>`<td><span class="compare-value">${esc(value(s,prop))}</span></td>`).join('')}</tr>`;
      });
    });
    openModal(`<div class="feature-inner compare-inner"><div class="compare-heading"><div class="section-kicker">Comparación</div><h2>Compará tus colegios</h2><p>${benefit}</p></div><div class="compare-benefits"><div><i class="fa-solid fa-layer-group"></i><span><strong>Lectura clara</strong> Cada sección está separada para identificar rápidamente qué dato estás viendo.</span></div><div><i class="fa-solid fa-wallet"></i><span><strong>Costos y beneficios</strong> Revisá matrícula y becas para detectar diferencias importantes.</span></div><div><i class="fa-solid fa-scale-balanced"></i><span><strong>Decisión</strong> Compará columnas y elegí la alternativa que mejor encaje con tus prioridades.</span></div></div><div class="compare-table-wrap"><table class="compare-table"><thead><tr><th><span>Aspecto</span><small>Qué estás comparando</small></th>${items.map(s=>`<th><span class="compare-school-name">${esc(name(s))}</span><button class="compare-remove" data-remove-compare="${esc(key(s))}" type="button"><i class="fa-solid fa-xmark"></i> Quitar</button></th>`).join('')}</tr></thead><tbody>${groupRows}</tbody></table></div><div class="compare-footer"><span><i class="fa-solid fa-circle-info"></i> Podés quitar cualquier colegio y la comparación se actualizará automáticamente.</span><button type="button" class="btn btn-ghost compare-export-btn" id="compare-export-btn"><i class="fa-solid fa-file-arrow-down"></i> Descargar PDF</button><span class="compare-limit">${items.length}/3 seleccionados</span></div></div>`,'compare',items.length);
    content.querySelectorAll('[data-remove-compare]').forEach(b=>b.addEventListener('click',async()=>{compare=compare.filter(x=>x!==b.dataset.removeCompare);persist();await persistDb();syncCounts();renderCompare();}));
    content.querySelector('#compare-export-btn')?.addEventListener('click',()=>exportCompareToPDF(items,groups,value));
  }

  function exportCompareToPDF(items,groups,value){
    const JsPDFCtor = window.jspdf && window.jspdf.jsPDF;
    if(!JsPDFCtor){ toast('No se pudo generar el PDF. Revisá tu conexión.'); return; }
    const doc = new JsPDFCtor({unit:'pt',format:'a4'});
    const marginX=40; let y=50;
    doc.setFontSize(16); doc.text('Colegio 360 — Comparación de colegios', marginX, y); y+=22;
    doc.setFontSize(9); doc.setTextColor(110);
    doc.text(`Generado el ${new Date().toLocaleDateString('es-AR')}`, marginX, y); y+=20;
    doc.setTextColor(20);
    doc.setFontSize(11);
    doc.text(items.map(s=>name(s)).join('   ·   '), marginX, y, {maxWidth:515}); y+=24;
    groups.forEach(g=>{
      if(y>760){doc.addPage();y=50;}
      doc.setFontSize(11); doc.setFont(undefined,'bold'); doc.text(g.name, marginX, y); doc.setFont(undefined,'normal'); y+=16;
      g.rows.forEach(([label,prop])=>{
        if(y>780){doc.addPage();y=50;}
        doc.setFontSize(9); doc.setTextColor(90); doc.text(String(label), marginX, y);
        doc.setTextColor(20);
        const vals = items.map(s=>name(s)+': '+value(s,prop)).join('   |   ');
        doc.text(vals, marginX+110, y, {maxWidth:400});
        y+=16;
      });
      y+=8;
    });
    doc.save('colegio360-comparacion.pdf');
    toast('PDF descargado.');
  }

  document.addEventListener('click',async e=>{
    const save=e.target.closest('.save-school');
    if(save){e.preventDefault();e.stopPropagation();if(!requireLogin())return;const k=canonicalId(save.dataset.schoolId);favorites=favorites.includes(k)?favorites.filter(x=>x!==k):[...favorites,k];persist();syncCounts();await persistDb();toast(favorites.includes(k)?'Colegio guardado en favoritos.':'Colegio quitado de favoritos.');return;}
    const cmp=e.target.closest('[data-action="compare"]');
    if(cmp){e.preventDefault();e.stopPropagation();if(!requireLogin())return;const k=canonicalId(cmp.dataset.schoolId);compare=compare.includes(k)?compare.filter(x=>x!==k):compare.length<3?[...compare,k]:compare;if(compare.length>=3&&!compare.includes(k))toast('Podés comparar hasta 3 colegios.');else {persist();syncCounts();await persistDb();toast(compare.includes(k)?'Colegio agregado a comparar.':'Colegio quitado de comparar.');}return;}
    const view=e.target.closest('[data-action="view"]');
    if(view){const s=(window.schoolLocations||[])[Number(view.dataset.schoolIndex)];if(s){e.preventDefault();openDetail(s);}}
  },true);

  document.getElementById('favorites-btn')?.addEventListener('click',()=>{if(requireLogin())renderFavorites();});
  document.getElementById('compare-btn')?.addEventListener('click',()=>{if(requireLogin())renderCompare();});
  document.addEventListener('colegio360:userchange',()=>{if(!window.currentUser){favorites=[];compare=[];dbReady=false;localStorage.removeItem('c360_favorites');localStorage.removeItem('c360_compare');}else{loadDbPreferences();}syncCounts();});
  syncCounts();
  if (new URLSearchParams(location.search).get('abrir') === 'comparar') {
    document.addEventListener('colegio360:schools-rendered', () => { if (requireLogin()) renderCompare(); }, { once: true });
  }
  window.C360Features={openDetail,renderFavorites,renderCompare,requireLogin};
})();
