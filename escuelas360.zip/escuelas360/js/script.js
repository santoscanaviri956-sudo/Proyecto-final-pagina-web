(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = v => String(v ?? '').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const params = new URLSearchParams(location.search);

  // El padrón oficial de CABA no trae el barrio de cada escuela, solo la
  // comuna ("Comuna 4"). Usamos la partición oficial de barrios por comuna
  // para poder seguir ofreciendo el filtro por barrio en la interfaz.
  const COMUNA_BARRIOS = {
    1: ['Retiro','San Nicolás','Puerto Madero','San Telmo','Monserrat','Constitución'],
    2: ['Recoleta'],
    3: ['Balvanera','San Cristóbal'],
    4: ['La Boca','Barracas','Parque Patricios','Nueva Pompeya'],
    5: ['Almagro','Boedo'],
    6: ['Caballito'],
    7: ['Flores','Parque Chacabuco'],
    8: ['Villa Soldati','Villa Riachuelo','Villa Lugano'],
    9: ['Liniers','Mataderos','Parque Avellaneda'],
    10: ['Versalles','Monte Castro','Floresta','Vélez Sarsfield','Villa Luro','Villa Real'],
    11: ['Villa General Mitre','Villa Devoto','Villa del Parque','Villa Santa Rita'],
    12: ['Coghlan','Saavedra','Villa Urquiza','Villa Pueyrredón'],
    13: ['Núñez','Belgrano','Colegiales'],
    14: ['Palermo'],
    15: ['Chacarita','La Paternal','Villa Crespo','Parque Chas','Agronomía','Villa Ortúzar'],
  };
  const BARRIO_COMUNA = {};
  Object.entries(COMUNA_BARRIOS).forEach(([comuna, barrios]) => barrios.forEach(b => { BARRIO_COMUNA[norm(b)] = Number(comuna); }));

  // Hash simple y determinístico (mismo nombre -> mismo resultado siempre)
  // usado para completar campos demo que el padrón oficial no trae
  // (jornada, becas, rating) sin tener que inventar datos al azar en cada carga.
  function hashOf(str) { let h = 0; for (const ch of String(str)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; }

  // The old project used {name, position, detail}; the current project uses
  // {nombre, lat, lng, ...}. Normalize both formats once so every feature can
  // use the same object shape.
  function normalizeSchool(raw, index = 0) {
    const s = { ...raw };
    if (!s.nombre) s.nombre = s.name || `Escuela secundaria ${index + 1}`;
    if (!s.id) s.id = s.cue_anexo || s.cue || `demo-${index + 1}`;
    if (/^\d+$/.test(String(s.id))) s.id = String(s.id).replace(/^0+(?=\d)/, '') || '0';
    if (!s.position && Number.isFinite(Number(s.lat)) && Number.isFinite(Number(s.lng))) s.position = [Number(s.lat), Number(s.lng)];
    if ((!Number.isFinite(Number(s.lat)) || !Number.isFinite(Number(s.lng))) && Array.isArray(s.position) && s.position.length >= 2) {
      s.lat = Number(s.position[0]);
      s.lng = Number(s.position[1]);
    }
    const hasCoords = Number.isFinite(Number(s.lat)) && Number.isFinite(Number(s.lng));
    if (hasCoords) {
      s.lat = Number(s.lat);
      s.lng = Number(s.lng);
      s.position = [s.lat, s.lng];
    } else {
      // El padrón oficial no incluye coordenadas en este archivo. No inventamos
      // una ubicación: el mapa solo muestra escuelas con coordenadas reales.
      s.lat = null;
      s.lng = null;
      s.position = null;
    }
    s.nivel = s.nivel || 'Secundaria';
    s.modalidad = s.modalidad || (norm(s.nombre).includes('tecnica') ? 'Técnica' : 'Común');
    const modalidadMapa = {
      'tecnica':'Educación Técnico Profesional',
      'educacion tecnico profesional':'Educación Técnico Profesional',
      'técnica':'Educación Técnico Profesional',
      'artistica':'Educación Artística',
      'artística':'Educación Artística',
      'jovenes y adultos':'Educación Permanente de Jóvenes y Adultos',
      'jóvenes y adultos':'Educación Permanente de Jóvenes y Adultos',
      'educacion permanente de jovenes y adultos':'Educación Permanente de Jóvenes y Adultos',
      'eib':'Educación Intercultural Bilingüe (EIB)',
      'educacion intercultural bilingue':'Educación Intercultural Bilingüe (EIB)',
      'educación intercultural bilingüe':'Educación Intercultural Bilingüe (EIB)',
      'especial':'Educación Especial',
      'educacion especial':'Educación Especial',
      'adultos':'Educación Permanente de Jóvenes y Adultos'
    };
    const modalNorm = norm(s.modalidad);
    s.modalidad = modalidadMapa[modalNorm] || s.modalidad;
    // Guardamos también todas las modalidades/niveles que declara el padrón
    // (puede enseñar varios niveles a la vez) para poder filtrar por
    // coincidencia parcial en vez de exigir una igualdad exacta.
    s.niveles = Array.isArray(raw.niveles) && raw.niveles.length ? raw.niveles : String(s.nivel || '').split('·').map(x => x.trim()).filter(Boolean);
    s.modalidades = Array.isArray(raw.modalidades) && raw.modalidades.length ? raw.modalidades.map(m => modalidadMapa[norm(m)] || m) : [s.modalidad];
    // Some legacy/demo records only said 'General'. Map those demo values to
    // the real orientation categories used by the new filters.
    if (!s.orientacion || norm(s.orientacion) === 'general') {
      if (s.modalidad === 'Técnica') s.orientacion = 'Técnica';
      else {
        const orientations = ['Ciencias Sociales y Humanidades','Ciencias Naturales','Economía y Administración','Comunicación','Arte','Educación Física','Informática / Ed. Digital / Programación / Robótica','Lenguas y Literatura','Turismo','Agro y Ambiente','Educación','Energía y Sustentabilidad / Matemática y Física'];
        let hash = 0; for (const ch of s.nombre) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
        s.orientacion = orientations[hash % orientations.length];
      }
    }
    s.localidad = s.localidad || 'Ciudad de Buenos Aires';
    // El padrón oficial trae "Comuna N" en departamento, no el barrio. Lo
    // convertimos a comuna numérica para poder matchear contra los barrios
    // reales que se eligen en el filtro.
    const comunaMatch = /comuna\s*(\d{1,2})/i.exec(String(s.departamento || ''));
    s.comuna = comunaMatch ? Number(comunaMatch[1]) : null;
    s.barrio = s.barrio || s.zona || (s.comuna && COMUNA_BARRIOS[s.comuna] ? COMUNA_BARRIOS[s.comuna].join(' / ') : null) || s.departamento || 'CABA';
    s.zona = s.barrio;
    s.direccion = s.direccion || s.detail || 'Ciudad Autónoma de Buenos Aires';
    s.gestion = s.gestion || (norm(s.nombre).includes('instituto') ? 'Privada' : 'Estatal');
    const h = hashOf(s.nombre || s.id);
    // Rating, jornada y becas: cuando el padrón no trae el dato real, usamos
    // un valor demo determinístico (mismo colegio -> mismo valor siempre) en
    // vez de un único valor fijo para todos, así los filtros que dependen de
    // estos campos no devuelven 0 resultados sistemáticamente.
    s.rating = Number(s.rating || (3.7 + (h % 14) / 10).toFixed(1));
    s.cuota = Number(s.cuota || 0);
    s.matricula = Number(s.matricula || 0);
    s.becas = s.becas != null ? Boolean(s.becas) : (h % 10) < 3;
    if (!s.jornada && !s.turno && !s.turnos && !s.jornadas) {
      const turnos = ['Mañana','Tarde','Noche'];
      const tipos = ['Simple','Media','Extendida'];
      s.jornada = turnos[h % 3];
      s.jornadas = `${s.jornada} · ${tipos[(h >> 2) % 3]}`;
    }
    const schoolQuery = encodeURIComponent(`${s.nombre} ${s.barrio || s.localidad || 'Ciudad de Buenos Aires'}`);
    s.sitio_web = s.sitio_web || s.website || s.web || '';
    s.instagram = s.instagram || s.instagram_url || '';
    s.web_busqueda = s.sitio_web || `https://www.google.com/search?q=${schoolQuery}+sitio+oficial+escuela`;
    s.instagram_busqueda = s.instagram || `https://www.google.com/search?q=${schoolQuery}+Instagram`;
    return s;
  }

  let schoolLocations = window.schoolLocations = [];
  window.getSchoolDetail = s => [s?.nivel, s?.modalidad, s?.orientacion, s?.localidad].filter(Boolean).join(' · ');

  const mainLayout = document.querySelector('.main-layout');
  const filterToggle = $('filter-toggle');
  if (filterToggle && mainLayout) {
    const setCollapsed = collapsed => {
      mainLayout.classList.toggle('filters-collapsed', collapsed);
      filterToggle.setAttribute('aria-expanded', String(!collapsed));
      localStorage.setItem('filters-collapsed', String(collapsed));
    };
    setCollapsed(localStorage.getItem('filters-collapsed') === 'true');
    filterToggle.addEventListener('click', () => setCollapsed(!mainLayout.classList.contains('filters-collapsed')));
  }

  // Assistant: deliberately simple and non-observing, so it cannot create DOM loops.
  const chatContainer = $('assistant-container'), chatBtn = $('chat-btn'), chatWindow = $('chat-window');
  function toggleChat() { if (chatWindow) chatWindow.style.display = chatWindow.style.display === 'flex' ? 'none' : 'flex'; }
  window.toggleChat = toggleChat;
  if (chatBtn && chatContainer) {
    let drag = false, moved = false, ox = 0, oy = 0, sx = 0, sy = 0;
    chatBtn.addEventListener('pointerdown', e => {
      e.preventDefault(); drag = true; moved = false; sx = e.clientX; sy = e.clientY;
      const r = chatContainer.getBoundingClientRect(); ox = e.clientX - r.left; oy = e.clientY - r.top;
      chatBtn.setPointerCapture?.(e.pointerId);
    });
    chatBtn.addEventListener('pointermove', e => {
      if (!drag) return;
      if (Math.abs(e.clientX - sx) > 5 || Math.abs(e.clientY - sy) > 5) moved = true;
      const l = Math.max(0, Math.min(e.clientX - ox, innerWidth - chatContainer.offsetWidth));
      const t = Math.max(0, Math.min(e.clientY - oy, innerHeight - chatContainer.offsetHeight));
      chatContainer.style.left = `${l}px`; chatContainer.style.top = `${t}px`;
      chatContainer.style.right = 'auto'; chatContainer.style.bottom = 'auto';
    });
    chatBtn.addEventListener('pointerup', () => { if (!drag) return; drag = false; if (!moved) toggleChat(); });
    chatBtn.addEventListener('pointercancel', () => { drag = false; });
  }

  const actionStatus = $('action-status');
  const showAction = m => { if (actionStatus) actionStatus.textContent = m; };

  // Mapa: usamos OpenStreetMap directamente con Leaflet; no necesita API key.
  let map = null;
  const markers = [];
  let userMarker = null;
  let userAccuracy = null;
  const mapEl = $('map');
  if (window.L && mapEl) {
    try {
      map = L.map(mapEl, { preferCanvas: true, zoomControl: true }).setView([-34.6037, -58.3816], 12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);
    } catch (e) {
      console.error('Error inicializando Leaflet:', e);
      map = null;
      mapEl.innerHTML = '<div class="map-fallback"><strong>Mapa no disponible</strong><small>La lista de colegios sigue disponible.</small></div>';
    }
  } else if (mapEl) {
    mapEl.innerHTML = '<div class="map-fallback"><strong>Mapa no disponible</strong><small>No se pudo cargar Leaflet.</small></div>';
  }

  const schoolGrid = $('school-grid'), detailedGrid = $('detailed-school-grid');
  const directoryCount = $('directory-count'), visibleCount = $('visible-school-count');
  let detailedVisibleCount = 6;

  const controls = {
    search: $('filter-search'), hero: $('hero-search'), level: $('filter-level'),
    modality: $('filter-modality'), orientation: $('filter-orientation'), zone: $('filter-zone'),
    enrollment: $('filter-enrollment'), rating: $('filter-rating'),
    jornada: $('filter-jornada'), jornadaSimple: $('filter-jornada-simple'), jornadaMedia: $('filter-jornada-media'), jornadaExtendida: $('filter-jornada-extendida'),
    scholarships: $('filter-scholarships'), free: $('filter-free'), price: $('price-filter'),
    priceVal: $('price-val'), active: $('active-filter-count')
  };

  function hydrateFromQuery() {
    if (controls.search) controls.search.value = params.get('q') || '';
    if (controls.hero) controls.hero.value = controls.search?.value || '';
    const set = (el, key) => { if (el && params.get(key) !== null) el.value = params.get(key); };
    set(controls.level, 'nivel'); set(controls.modality, 'modalidad'); set(controls.orientation, 'orientacion'); set(controls.zone, 'zona');
    // Si no vino nivel/zona por la URL, aplicamos la preferencia por defecto guardada en Ajustes.
    try {
      if (controls.level && !params.get('nivel')) {
        const defNivel = localStorage.getItem('c360_default_nivel');
        if (defNivel) controls.level.value = defNivel;
      }
      if (controls.zone && !params.get('zona')) {
        const defZona = localStorage.getItem('c360_default_zona');
        if (defZona) controls.zone.value = defZona;
      }
      if (controls.orientation && !params.get('orientacion')) {
        const defOri = localStorage.getItem('c360_default_orientation');
        if (defOri) controls.orientation.value = defOri;
      }
    } catch (_) {}
    set(controls.enrollment, 'matricula'); set(controls.rating, 'rating'); set(controls.jornada, 'jornada');
    const jt=(params.get('jornada_tipo')||'').split(',').filter(Boolean); ['simple','media','extendida'].forEach(t=>{const el=controls['jornada'+t.charAt(0).toUpperCase()+t.slice(1)]; if(el) el.checked=jt.includes(t);});
    if (controls.scholarships && params.get('becas')) controls.scholarships.value = 'Con becas disponibles';
    if (controls.free && params.get('gratuita')) controls.free.value = 'gratuita';
    if (controls.price && params.get('precio')) controls.price.value = params.get('precio');
    if (controls.priceVal && controls.price) controls.priceVal.textContent = '$' + Number(controls.price.value).toLocaleString('es-AR');
  }

  function matches(s) {
    const q = norm(controls.search?.value);
    const text = norm([s.nombre, s.nombre_abreviado, s.barrio, s.localidad, s.direccion, s.modalidad, s.orientacion, s.oferta_educativa].join(' '));
    if (q && !text.includes(q)) return false;
    if (controls.level?.value && controls.level.value !== 'Todos los niveles') {
      const niveles = Array.isArray(s.niveles) && s.niveles.length ? s.niveles : [s.nivel];
      if (!niveles.some(n => norm(n) === norm(controls.level.value))) return false;
    }
    if (controls.modality?.value && controls.modality.value !== 'Todas las modalidades') {
      const modalidades = Array.isArray(s.modalidades) && s.modalidades.length ? s.modalidades : [s.modalidad];
      if (!modalidades.some(m => norm(m) === norm(controls.modality.value))) return false;
    }
    if (controls.orientation?.value && controls.orientation.value !== 'Todas las orientaciones' && norm(s.orientacion) !== norm(controls.orientation.value)) return false;
    if (controls.zone?.value) {
      const comunaDelBarrio = BARRIO_COMUNA[norm(controls.zone.value)];
      const matchByComuna = comunaDelBarrio && s.comuna === comunaDelBarrio;
      const matchByName = norm(s.barrio).includes(norm(controls.zone.value));
      if (!matchByComuna && !matchByName) return false;
    }
    const jornadaText = norm([s.jornada, s.jornadas, s.turno, s.turnos].join(' '));
    if (controls.jornada?.value && !jornadaText.includes(norm(controls.jornada.value))) return false;
    const tiposJornada = [
      controls.jornadaSimple?.checked ? 'simple' : '',
      controls.jornadaMedia?.checked ? 'media' : '',
      controls.jornadaExtendida?.checked ? 'extendida' : ''
    ].filter(Boolean);
    if (tiposJornada.length && !tiposJornada.some(t => jornadaText.includes(t))) return false;
    if (controls.price && Number(s.cuota || 0) > Number(controls.price.value || 250000)) return false;
    if (controls.enrollment?.value === 'Hasta $100.000' && Number(s.matricula || 0) > 100000) return false;
    if (controls.enrollment?.value === 'Sin matrícula' && Number(s.matricula || 0) > 0) return false;
    if (controls.scholarships?.value === 'Con becas disponibles' && !s.becas) return false;
    if (controls.free?.value === 'gratuita' && !(Number(s.cuota || 0) === 0 || norm(s.gestion) === 'estatal')) return false;
    if (controls.rating?.value === '4.5 o más' && Number(s.rating || 0) < 4.5) return false;
    if (controls.rating?.value === '4.8 o más' && Number(s.rating || 0) < 4.8) return false;
    return true;
  }

  const idKey = s => { const raw = String(s.id ?? s.cue_anexo ?? s.cue ?? s.nombre); return /^\d+$/.test(raw) ? (raw.replace(/^0+(?=\d)/,'') || '0') : raw; };

  function card(s, i) {
    const pos = schoolLocations.indexOf(s);
    const fallback = 'assets/escuela-generica.svg';
    return `<article class="school-card">
      <div class="school-image-wrap"><img class="school-card-photo" src="${esc(fallback)}" alt="Edificio de ${esc(s.nombre)}" loading="lazy"><span class="school-image-label"><i class="fa-solid fa-school"></i> Colegio</span></div>
      <div class="school-card-top"><h3>${esc(s.nombre)}</h3><span class="school-card-type">${esc(s.modalidad)}</span></div>
      <div class="school-rating"><div><strong>★ ${Number(s.rating || 4.5).toFixed(1)}</strong><span>${esc(s.gestion || 'Institución')}</span></div><small>${s.becas ? 'Becas' : ((Number(s.cuota || 0) === 0 || norm(s.gestion) === 'estatal') ? 'Escuela gratuita' : 'Información institucional')}</small></div>
      <div class="rating-details"><span>📚 Nivel <b>${esc(s.nivel)}</b></span><span>🏫 Orientación <b>${esc(s.orientacion)}</b></span><span>📍 Zona <b>${esc(s.barrio || s.departamento || s.localidad)}</b></span></div>
      <p><i class="fa-solid fa-location-dot"></i> ${esc(s.direccion || s.localidad)}</p>
      <div class="school-card-actions">
        <button type="button" class="view-school" data-action="view" data-school-index="${pos}"><i class="fa-solid fa-eye"></i> Ver ficha</button>
        <button type="button" class="save-school" data-school-id="${esc(idKey(s))}" aria-label="Guardar en favoritos"><i class="fa-regular fa-heart"></i></button>
        <button type="button" data-action="compare" data-school-id="${esc(idKey(s))}" aria-label="Comparar colegio"><i class="fa-solid fa-scale-balanced"></i></button>
      </div>
    </article>`;
  }

  function detailedCard(s, i) {
    const pos = schoolLocations.indexOf(s), cuota = Number(s.cuota || 0), matricula = Number(s.matricula || 0);
    const fallback = 'assets/escuela-generica.svg';
    return `<article class="detailed-school-card">
      <div class="detailed-school-image"><img class="school-card-photo" src="${esc(fallback)}" alt="${esc(s.nombre)}" loading="lazy"></div>
      <div class="detailed-school-content"><div class="detailed-title-row"><h3><i class="fa-solid fa-school"></i> ${esc(s.nombre)}</h3><span class="rating-main">★ ${Number(s.rating || 4.5).toFixed(1)}<small>/5</small></span></div>
      <div class="school-meta"><span><i class="fa-solid fa-location-dot"></i> <b>${esc(s.barrio || s.departamento || s.localidad)}</b></span><span><i class="fa-solid fa-graduation-cap"></i> ${esc(s.modalidad)}</span><span><i class="fa-solid fa-compass-drafting"></i> ${esc(s.orientacion)}</span><span><i class="fa-solid fa-wallet"></i> ${cuota ? 'Cuota demo $' + cuota.toLocaleString('es-AR') : 'Sin cuota'}</span></div>
      <div class="school-method"><i class="fa-solid fa-circle-info"></i> Matrícula: <b>${matricula ? '$' + matricula.toLocaleString('es-AR') : 'sin matrícula'}</b> · ${esc(s.gestion)}</div>
      <div class="service-tags">${(Number(s.cuota || 0) === 0 || norm(s.gestion) === 'estatal') ? '<span class="free-badge">🏫 Escuela gratuita</span>' : ''}${String(s.servicios || '').split(',').filter(Boolean).slice(0, 4).map(x => `<span>${esc(x.trim())}</span>`).join('')}${s.becas ? '<span>🎓 Becas</span>' : ''}</div>
      <div class="detailed-actions"><button type="button" class="save-school" data-school-id="${esc(idKey(s))}"><i class="fa-regular fa-heart"></i> Guardar</button><button type="button" data-action="compare" data-school-id="${esc(idKey(s))}"><i class="fa-solid fa-scale-balanced"></i> Comparar</button><button class="view-school" type="button" data-action="view" data-school-index="${pos}">Ver colegio <i class="fa-solid fa-arrow-right"></i></button></div></div></article>`;
  }

  function render() {
    let filtered = schoolLocations.filter(matches);
    if (nearbyMode) {
      filtered.sort((a,b)=>(a._distanceKm??999)-(b._distanceKm??999));
      const withinRadius = filtered.filter(s => Number.isFinite(s._distanceKm) && s._distanceKm <= NEARBY_RADIUS_KM);
      if (withinRadius.length) filtered = withinRadius;
      else filtered = filtered.slice(0, 8);
    }
    if (directoryCount) directoryCount.textContent = `${filtered.length} ${filtered.length === 1 ? 'institución' : 'instituciones'} encontradas`;
    if (schoolGrid) schoolGrid.innerHTML = filtered.slice(0, 56).map(card).join('') || '<div class="empty-results"><strong>No encontramos colegios con esos filtros.</strong><span>Probá ampliar la búsqueda.</span></div>';
    const shown = filtered.slice(0, detailedVisibleCount);
    if (detailedGrid) detailedGrid.innerHTML = shown.map(detailedCard).join('');
    if (visibleCount) visibleCount.textContent = `Mostrando ${shown.length} de ${filtered.length} colegios`;
    const more = $('show-more-schools'), less = $('show-less-schools');
    if (more) more.hidden = detailedVisibleCount >= filtered.length;
    if (less) less.hidden = detailedVisibleCount <= 6;

    const values = [controls.search?.value, controls.level?.selectedIndex, controls.modality?.selectedIndex, controls.orientation?.selectedIndex, controls.zone?.selectedIndex, controls.enrollment?.selectedIndex, controls.rating?.selectedIndex, controls.jornada?.selectedIndex, controls.jornadaSimple?.checked, controls.jornadaMedia?.checked, controls.jornadaExtendida?.checked, controls.scholarships?.selectedIndex, controls.free?.selectedIndex, controls.price && Number(controls.price.value) < Number(controls.price.max)];
    const active = values.filter(Boolean).length;
    if (controls.active) controls.active.textContent = `${active} ${active === 1 ? 'filtro activo' : 'filtros activos'}`;

    markers.splice(0).forEach(m => { try { m.remove(); } catch (_) {} });
    if (!map || !window.L) { document.dispatchEvent(new CustomEvent('colegio360:schools-rendered')); return; }
    const bounds = [];
    filtered.slice(0, 150).forEach(s => {
      if (!Number.isFinite(s.lat) || !Number.isFinite(s.lng)) return;
      const marker = L.marker([s.lat, s.lng], { riseOnHover: true }).addTo(map)
        .bindPopup(`<strong>${esc(s.nombre)}</strong><br>${esc(s.direccion || s.localidad)}<br><small>${esc(s.modalidad)} · ${esc(s.orientacion)}</small>`);
      markers.push(marker); bounds.push([s.lat, s.lng]);
    });
    if (bounds.length && !params.toString() && !nearbyMode) {
      try { map.fitBounds(bounds, { padding: [25, 25], maxZoom: 13 }); } catch (_) {}
    }
    if (nearbyMode && userMarker) {
      try { userMarker.bringToFront(); } catch (_) {}
    }
    document.dispatchEvent(new CustomEvent('colegio360:schools-rendered'));
  }

  function mergeSchools(list) {
    const seen = new Set(schoolLocations.map(s => norm(s.cue_anexo || s.cue || s.nombre)));
    for (const raw of list || []) {
      const s = normalizeSchool(raw, schoolLocations.length);
      const key = norm(s.cue_anexo || s.cue || s.nombre);
      if (!key || seen.has(key)) continue;
      seen.add(key); schoolLocations.push(s);
    }
  }

  async function fetchJson(url, timeout = 1800) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const r = await fetch(url, { cache: 'no-store', signal: controller.signal });
      if (!r.ok) throw new Error(`${r.status}`);
      return await r.json();
    } finally { clearTimeout(timer); }
  }


  async function loadSchools() {
    // Fuente principal: padrón oficial de CABA. Las fichas se generan desde
    // estos registros cuando el usuario aplica filtros o abre un colegio.
    const official = await fetchJson('data/padron_caba.json', 5000).catch(() => []);
    schoolLocations = window.schoolLocations = Array.isArray(official) ? official.map(normalizeSchool) : [];
    render();

    // Conservamos únicamente fuentes complementarias para datos que todavía
    // aportan coordenadas u otros campos no presentes en el padrón.
    const legacy = Array.isArray(window.cabaSecondarySchools) ? window.cabaSecondarySchools : [];
    const jobs = [
      Promise.resolve().then(() => mergeSchools(legacy)),
      fetchJson('escuelas.php', 3000).then(d => Array.isArray(d?.escuelas) ? mergeSchools(d.escuelas) : null).catch(() => null)
    ];
    await Promise.allSettled(jobs);
    window.schoolLocations = schoolLocations;
    render();
    setTimeout(() => { try { map?.invalidateSize(); } catch (_) {} }, 200);
  }

  $('school-grid')?.addEventListener('click', e => {
    const b = e.target.closest('[data-school-index]'); if (!b) return;
    const s = schoolLocations[Number(b.dataset.schoolIndex)]; if (!s) return;
    if (map) { map.setView([s.lat, s.lng], 15); const m = markers.find(x => { const p = x.getLatLng(); return Math.abs(p.lat - s.lat) < 1e-7 && Math.abs(p.lng - s.lng) < 1e-7; }); m?.openPopup(); }
    showAction(`${s.nombre}: ${s.direccion || s.localidad}.`);
  });
  $('detailed-school-grid')?.addEventListener('click', e => {
    const b = e.target.closest('[data-action="view"]'); if (!b) return;
    const s = schoolLocations[Number(b.dataset.schoolIndex)]; if (s && map) map.setView([s.lat, s.lng], 15);
  });
  $('show-more-schools')?.addEventListener('click', () => { detailedVisibleCount += 6; render(); });
  $('show-less-schools')?.addEventListener('click', () => { detailedVisibleCount = Math.max(6, detailedVisibleCount - 6); render(); });

  $('apply-filters')?.addEventListener('click', () => {
    const q = new URLSearchParams();
    if (controls.search?.value) q.set('q', controls.search.value);
    if (controls.level?.value && controls.level.value !== 'Todos los niveles') q.set('nivel', controls.level.value);
    if (controls.modality?.value && controls.modality.value !== 'Todas las modalidades') q.set('modalidad', controls.modality.value);
    if (controls.orientation?.value && controls.orientation.value !== 'Todas las orientaciones') q.set('orientacion', controls.orientation.value);
    if (controls.zone?.value) q.set('zona', controls.zone.value);
    if (controls.price) q.set('precio', controls.price.value);
    if (controls.enrollment?.value && controls.enrollment.value !== 'Cualquier matrícula') q.set('matricula', controls.enrollment.value);
    if (controls.scholarships?.value === 'Con becas disponibles') q.set('becas', 'Con becas disponibles');
    if (controls.free?.value === 'gratuita') q.set('gratuita', '1');
    if (controls.rating?.value && controls.rating.value !== 'Cualquiera') q.set('rating', controls.rating.value);
    if (controls.jornada?.value) q.set('jornada', controls.jornada.value);
    const jornadaTipos=['simple','media','extendida'].filter(t=>controls['jornada'+t.charAt(0).toUpperCase()+t.slice(1)]?.checked);
    if(jornadaTipos.length) q.set('jornada_tipo',jornadaTipos.join(','));
    location.href = 'menu.html?' + q.toString();
  });
  $('reset-filters')?.addEventListener('click', () => {
    [controls.search, controls.level, controls.modality, controls.orientation, controls.zone, controls.enrollment, controls.rating, controls.jornada, controls.scholarships, controls.free].forEach(e => { if (e) e.selectedIndex = 0; });
    if (controls.search) controls.search.value = '';
    if (controls.hero) controls.hero.value = '';
    if (controls.price) { controls.price.value = controls.price.max; if (controls.priceVal) controls.priceVal.textContent = '$' + Number(controls.price.max).toLocaleString('es-AR'); }
    [controls.jornadaSimple, controls.jornadaMedia, controls.jornadaExtendida].forEach(e=>{if(e)e.checked=false;});
    render();
  });
  controls.hero?.addEventListener('input', () => { if (controls.search) controls.search.value = controls.hero.value; render(); });
  $('search-clear')?.addEventListener('click', () => { if (controls.hero) controls.hero.value = ''; if (controls.search) controls.search.value = ''; render(); });
  controls.price?.addEventListener('input', () => { if (controls.priceVal) controls.priceVal.textContent = '$' + Number(controls.price.value).toLocaleString('es-AR'); });

  let nearbyMode = false;
  const NEARBY_RADIUS_KM = 5;
  function distanceKm(a,b,c,d){const R=6371, p=Math.PI/180, x=(c-a)*p, y=(d-b)*p; const h=Math.sin(x/2)**2+Math.cos(a*p)*Math.cos(c*p)*Math.sin(y/2)**2; return 2*R*Math.asin(Math.sqrt(h));}
  const applyNearbyResults = (lat,lng) => {
    schoolLocations = window.schoolLocations = schoolLocations.map(s => ({...s, _distanceKm: distanceKm(lat,lng,s.lat,s.lng)}));
    nearbyMode = true;
    render();
  };
  const locateUser = () => {
    if (!navigator.geolocation) return showAction('Tu navegador no permite geolocalización.');
    showAction('Obteniendo tu ubicación…');
    navigator.geolocation.getCurrentPosition(p => {
      if (!map) return showAction('El mapa no está disponible.');
      const lat = p.coords.latitude, lng = p.coords.longitude;
      if (userMarker) userMarker.remove();
      if (userAccuracy) userAccuracy.remove();
      userAccuracy = L.circle([lat,lng], { radius: Math.max(30, Number(p.coords.accuracy || 50)), color:'#6654c7', fillOpacity:.08, weight:1 }).addTo(map);
      userMarker = L.circleMarker([lat,lng], { radius: 9, color:'#fff', weight:3, fillColor:'#6654c7', fillOpacity:1 }).addTo(map).bindPopup('<strong>Tu ubicación</strong><br><small>Las escuelas cercanas se ordenaron desde este punto.</small>');
      map.setView([lat,lng], 14, { animate:true, duration:.7 });
      applyNearbyResults(lat,lng);
      userMarker.openPopup();
      const nearest = schoolLocations.filter(s => Number.isFinite(s._distanceKm)).slice().sort((a,b)=>a._distanceKm-b._distanceKm);
      const close = nearest.filter(s => s._distanceKm <= NEARBY_RADIUS_KM);
      const count = close.length || Math.min(nearest.length, 8);
      showAction(count ? `Ubicación detectada. ${count} colegios cercanos, ordenados por distancia.` : 'Ubicación detectada, pero no hay colegios con coordenadas disponibles.');
    }, err => {
      const message = err?.code === 1 ? 'Permiso de ubicación rechazado. Habilitalo en el navegador para usar esta función.' : 'No se pudo obtener tu ubicación. Verificá que la ubicación esté habilitada.';
      showAction(message);
    }, { enableHighAccuracy:true, timeout:10000, maximumAge:60000 });
  };
  $('nearby-btn')?.addEventListener('click', locateUser); $('gps-btn')?.addEventListener('click', locateUser);
  document.querySelectorAll('[data-quick-filter]').forEach(b => b.addEventListener('click', () => {
    const t = b.dataset.quickFilter;
    if (t === 'price' && controls.price) { controls.price.value = 100000; if (controls.priceVal) controls.priceVal.textContent = '$100.000'; render(); }
    if (t === 'bilingual' && controls.orientation) { controls.orientation.value = 'Lenguas y Literatura'; render(); }
    if (t === 'top' && controls.rating) { controls.rating.value = '4.5 o más'; render(); }
    if (t === 'nearby') locateUser();
  }));
  // EduAI: conversación real con Gemini. El navegador sólo aporta el
  // contexto de la página; el razonamiento y la redacción vienen del modelo.
  function addEduAIMessage(text, type='assistant') {
    const body = document.querySelector('.chat-body');
    if (!body) return;
    const m = document.createElement('div');
    m.className = `chat-msg chat-${type}`;
    m.textContent = text;
    body.appendChild(m);
    body.scrollTop = body.scrollHeight;
    return m;
  }

  const eduAIHistory = [];
  let eduAISending = false;

  function currentFiltersSnapshot() {
    return {
      busqueda: $('filter-search')?.value || '',
      zona: $('filter-zone')?.value || '',
      nivel: $('filter-level')?.value || '',
      modalidad: $('filter-modality')?.value || '',
      orientacion: $('filter-orientation')?.value || '',
      jornada: $('filter-jornada')?.value || '',
      jornada_simple: !!$('filter-jornada-simple')?.checked,
      jornada_media: !!$('filter-jornada-media')?.checked,
      jornada_extendida: !!$('filter-jornada-extendida')?.checked,
      matricula: $('filter-enrollment')?.value || '',
      becas: $('filter-scholarships')?.value || '',
      gratuita: $('filter-free')?.value || '',
      rating: $('filter-rating')?.value || '',
      cuota_maxima: Number($('price-filter')?.value || 0),
    };
  }

  function visibleSchoolsSnapshot() {
    const out=[];
    document.querySelectorAll('#school-grid [data-action="view"][data-school-index]').forEach((el) => {
      const index=Number(el.dataset.schoolIndex);
      const s=Array.isArray(window.schoolLocations) ? window.schoolLocations[index] : null;
      if(!s) return;
      out.push({
        id:s.id ?? s.cue_anexo ?? s.cue ?? '', nombre:s.nombre || '', nivel:s.nivel || '', modalidad:s.modalidad || '',
        orientacion:s.orientacion || '', barrio:s.barrio || s.localidad || '', localidad:s.localidad || '',
        direccion:s.direccion || '', gestion:s.gestion || s.sector || '', cuota:s.cuota ?? null,
        matricula:s.matricula ?? null, becas:s.becas ?? null, rating:s.rating ?? null,
      });
    });
    return out.slice(0,10);
  }

  function userContextSnapshot() {
    const u=window.currentUser || null;
    return u ? { authenticated:true, nombre:u.nombre||'', email:u.email||'', birth_year:u.birth_year??null, zona:u.zona||'' } : { authenticated:false };
  }

  function pageContextSnapshot() {
    const current=window.c360CurrentSchool;
    return {
      page:location.pathname.split('/').pop() || 'menu.html',
      url:location.href,
      visibleCount:document.querySelectorAll('#school-grid .school-card').length,
      filters:currentFiltersSnapshot(),
      visibleSchools:visibleSchoolsSnapshot(),
      currentSchool: typeof current === 'object' && current ? current : (current ? {nombre:String(current)} : null),
      favoritesCount:Number(document.querySelector('#favorites-btn .nav-count')?.textContent || 0),
      compareCount:Number(document.querySelector('#compare-btn .nav-count')?.textContent || 0),
      user:userContextSnapshot(),
    };
  }

  async function loadEduAIHistory() {
    if(!window.currentUser) return;
    try {
      const r=await fetch('eduai.php?history=1',{credentials:'same-origin',cache:'no-store'});
      const d=await r.json();
      if(d?.success && Array.isArray(d.history)) {
        eduAIHistory.splice(0,eduAIHistory.length,...d.history.slice(-10));
        const body=document.querySelector('.chat-body');
        if(body && eduAIHistory.length) {
          body.querySelectorAll('.chat-msg:not(.chat-welcome)').forEach(e=>e.remove());
          eduAIHistory.forEach(h=>addEduAIMessage(h.text,h.role==='user'?'user':'assistant'));
        }
      }
    } catch (_) {}
  }

  function isOpenFavoritesCommand(q) {
    const n=norm(q);
    return /\b(abrir|mostrame|mostrar|ver|ir a)\b.*\b(favoritos|favorito)\b/.test(n);
  }
  function isOpenCompareCommand(q) {
    const n=norm(q);
    return /\b(abrir|mostrame|mostrar|ver|ir a)\b.*\b(comparar|comparador|comparacion)\b/.test(n);
  }

  async function askEduAIBackend(question, onToken) {
    const controller=new AbortController();
    const timeout=window.setTimeout(()=>controller.abort(),45000);
    try {
      const r=await fetch('eduai.php?stream=1',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({
        message:question,history:eduAIHistory.slice(-10),context:pageContextSnapshot()
      }),signal:controller.signal});
      if(!r.ok && !r.body) {
        const d=await r.json().catch(()=>null);
        throw new Error(d?.reason || ('http_' + r.status));
      }
      const type=(r.headers.get('content-type')||'').toLowerCase();
      if(!r.body || !type.includes('text/event-stream')) {
        const d=await r.json().catch(()=>null);
        if(d?.success) return d.reply;
        throw new Error(d?.message || d?.reason || 'backend_error');
      }
      const reader=r.body.getReader();
      const decoder=new TextDecoder();
      let buffer='', reply='', done=false;
      while(!done) {
        const part=await reader.read();
        buffer+=decoder.decode(part.value||new Uint8Array(),{stream:!part.done});
        const lines=buffer.split(/\r?\n/); buffer=lines.pop()||'';
        for(const line of lines) {
          if(!line.startsWith('data:')) continue;
          const raw=line.slice(5).trim(); if(!raw || raw==='[DONE]') continue;
          let data; try{data=JSON.parse(raw);}catch(_){continue;}
          if(data.text){ reply+=data.text; onToken?.(data.text,reply); }
          if(data.reply){ reply=data.reply; onToken?.('',reply); done=true; }
          if(data.success===false && data.reason){ throw new Error(data.reason); }
        }
        if(part.done) done=true;
      }
      return reply.trim() || null;
    } catch (err) {
      const reason=String(err?.message || '');
      if(reason==='no_api_key') throw new Error('no_api_key');
      if(reason.startsWith('api_error_')) throw new Error(reason);
      if(reason==='network_error' || reason==='AbortError') throw new Error('network_error');
      throw err;
    } finally { window.clearTimeout(timeout); }
  }

  async function sendEduAI() {
    if(eduAISending) return;
    const i=$('chat-input'); const question=i?.value.trim(); if(!question) return;
    eduAISending=true;
    const sendBtn=$('chat-send'); if(sendBtn) sendBtn.disabled=true;
    addEduAIMessage(question,'user'); i.value='';
    // La pregunta actual se agrega al historial interno después de obtener su respuesta;
    // de ese modo no se envía duplicada dentro de contents a Gemini.

    // Estos dos comandos interactúan con la interfaz; todo lo demás lo razona Gemini.
    if(isOpenFavoritesCommand(question)) {
      document.getElementById('favorites-btn')?.click();
      addEduAIMessage('Listo, abrí Favoritos.','assistant');
      eduAIHistory.push({role:'user',text:question},{role:'assistant',text:'Listo, abrí Favoritos.'});
      eduAIHistory.splice(0,Math.max(0,eduAIHistory.length-10));
      eduAISending=false; if(sendBtn) sendBtn.disabled=false; return;
    }
    if(isOpenCompareCommand(question)) {
      document.getElementById('compare-btn')?.click();
      addEduAIMessage('Listo, abrí el comparador.','assistant');
      eduAIHistory.push({role:'user',text:question},{role:'assistant',text:'Listo, abrí el comparador.'});
      eduAIHistory.splice(0,Math.max(0,eduAIHistory.length-10));
      eduAISending=false; if(sendBtn) sendBtn.disabled=false; return;
    }

    const typing=addEduAIMessage('','typing');
    let reply=null;
    let backendError='';
    try {
      reply=await askEduAIBackend(question,(chunk,full)=>{ if(typing) { typing.textContent=full||'EduAI está pensando…'; const body=document.querySelector('.chat-body'); if(body) body.scrollTop=body.scrollHeight; } });
    } catch(err) {
      backendError=String(err?.message || 'network_error');
    }
    typing?.remove();
    const finalReply=reply || (backendError==='no_api_key'
      ? 'EduAI está bien conectado a la página, pero falta configurar la clave GEMINI_API_KEY en el servidor. Creá una clave nueva de Gemini y configurala en eduai-config.local.php o como variable de entorno.'
      : backendError.startsWith('api_error_')
        ? 'Gemini rechazó la solicitud (' + backendError.replace('api_error_','HTTP ') + '). Revisá la clave, el acceso al modelo y la configuración de la API.'
        : 'No pude conectarme con EduAI en este momento. Revisá la conexión del servidor y volvé a intentarlo.');
    addEduAIMessage(finalReply);
    eduAIHistory.push({role:'user',text:question},{role:'assistant',text:finalReply});
    eduAIHistory.splice(0,Math.max(0,eduAIHistory.length-10));
    eduAISending=false; if(sendBtn) sendBtn.disabled=false;
  }
  $('chat-send')?.addEventListener('click',sendEduAI);
  $('chat-input')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();sendEduAI();}});
  async function syncAccountPreferences(){
    if(!window.currentUser) return;
    try{
      const r=await fetch('preferencias.php',{credentials:'same-origin',cache:'no-store'});
      const d=await r.json(); if(!d?.success) return;
      const s=d.settings||{};
      if(s.nivel_preferido) localStorage.setItem('c360_default_nivel',s.nivel_preferido); else localStorage.removeItem('c360_default_nivel');
      if(s.barrio_preferido) localStorage.setItem('c360_default_zona',s.barrio_preferido); else localStorage.removeItem('c360_default_zona');
      if(s.orientacion_preferida) localStorage.setItem('c360_default_orientation',s.orientacion_preferida); else localStorage.removeItem('c360_default_orientation');
      if(!params.get('nivel') && controls.level) controls.level.value=s.nivel_preferido||'';
      if(!params.get('zona') && controls.zone) controls.zone.value=s.barrio_preferido||'';
      if(!params.get('orientacion') && controls.orientation) controls.orientation.value=s.orientacion_preferida||'';
      if(!params.toString()) render();
    }catch(_){ }
  }
  document.addEventListener('colegio360:userchange',()=>{ loadEduAIHistory(); syncAccountPreferences(); });

  hydrateFromQuery();
  loadSchools();
})();


/* Colegio 360 — microinteracciones suaves para controles de filtros */
document.addEventListener('focusin', (e) => {
  const group = e.target.closest('.filter-group, .landing-field, .landing-option-card');
  if (group) group.classList.add('is-focused');
});
document.addEventListener('focusout', (e) => {
  const group = e.target.closest('.filter-group, .landing-field, .landing-option-card');
  if (group) group.classList.remove('is-focused');
});
