<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['success'=>false,'error'=>'Necesitás iniciar sesión.'],JSON_UNESCAPED_UNICODE); exit; }
try {
  $in = json_decode(file_get_contents('php://input'), true);
  if (!is_array($in)) $in = $_POST;
  $password = (string)($in['password'] ?? '');
  if ($password === '') throw new RuntimeException('Ingresá tu contraseña para confirmar.');

  $uid = (int)$_SESSION['user_id'];
  $st = $pdo->prepare('SELECT password FROM usuarios WHERE id=? LIMIT 1');
  $st->execute([$uid]);
  $row = $st->fetch();
  if (!$row) throw new RuntimeException('Usuario no encontrado.');
  if (!password_verify($password, $row['password'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'error'=>'Tu contraseña no es correcta.'],JSON_UNESCAPED_UNICODE);
    exit;
  }
  $st = $pdo->prepare('DELETE FROM usuarios WHERE id=?');
  $st->execute([$uid]);
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
  }
  session_destroy();
  echo json_encode(['success'=>true],JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>$e->getMessage() ?: 'No se pudo eliminar la cuenta.'],JSON_UNESCAPED_UNICODE);
}
