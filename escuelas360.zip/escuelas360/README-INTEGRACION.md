# Colegio 360 — integración

## Flujo actual
- `inicio.html`: nueva portada de entrada con búsqueda y filtros.
- `menu.html`: interfaz completa de resultados, mapa, favoritos, comparación, Matcher, reseñas y asistente.
- Al aplicar filtros en la portada se navega a `menu.html` con los filtros en la URL y el menú los aplica automáticamente.
- Login y registro siguen siendo páginas separadas.
- Registro tradicional: nombre, correo, año de nacimiento y contraseña.
- Registro con Google: autentica con Google y, si es una cuenta nueva, pide el año de nacimiento antes de crear el usuario.
- `google-config.php` contiene el Client ID configurado para desarrollo local.

## Datos de demo
`data/demo_100_escuelas.json` contiene 100 instituciones secundarias basadas en registros del Padrón Oficial de Establecimientos Educativos de CABA del 16/06/2026. La información institucional procede del padrón; cuota, matrícula, metodología, becas y servicios son **datos de demostración** para poder visualizar los filtros y no deben presentarse como aranceles o prestaciones oficiales.

Cuando la tabla `escuelas` tiene menos de 100 registros, `escuelas.php` completa automáticamente la demo hasta llegar a 100 registros. Si ya tenés escuelas importadas en MySQL, no las reemplaza.

## Google
En Google Cloud, para desarrollo local, el origen autorizado debe ser `http://localhost`. El flujo usa Google Identity Services y valida el ID token en `google-login.php`.


## Estructura limpia
- `inicio.html`: portada/filtros.
- `menu.html`: resultados y funcionalidades.
- `css/`: estilos.
- `js/`: lógica de filtros, sesión y funcionalidades.
- `data/demo_100_escuelas.json`: respaldo de 100 colegios para demo.
- `index.php` y `.htaccess`: redirección técnica para que `http://localhost/escuelas360/` abra `inicio.html`.


### Perfil de usuario
El menú ahora incluye un perfil desplegable al pasar el cursor. Los campos nombre, año de nacimiento, zona/barrio, teléfono, dirección y DNI se guardan en la tabla `usuarios` mediante `perfil.php`. Si la tabla ya existe, el endpoint agrega automáticamente las columnas faltantes.

### Datos de escuelas demo
`data/caba_secondary_demo_oficial.json` contiene registros secundarios de CABA basados en el Padrón Oficial 16/06/2026. Nombre, dirección, sector y barrio detectado se conservan del padrón; cuota, valoración, becas, orientación y algunos servicios son metadatos de demo para poder probar los filtros.

## EduAI actualizado
EduAI usa Gemini del lado del servidor y puede transmitir la respuesta en tiempo real con `streamGenerateContent`. El contexto se construye a partir del padrón cargado, colegios enriquecidos para las fichas y el estado actual de la página. Las conversaciones se guardan únicamente para usuarios autenticados en `eduai_conversaciones`; no se almacenan contraseñas.

## Ajustes y persistencia
Tema, tamaño de texto, nivel/zona de búsqueda por defecto y notificaciones quedan asociados a `configuraciones_usuario`. Favoritos, comparaciones y reseñas siguen vinculados al usuario.

### EduAI y servidor
EduAI usa `gemini-3.8-flash` mediante el endpoint del servidor y transmite la respuesta con SSE cuando el navegador lo solicita. Si PHP tiene la extensión cURL, se usa cURL; si no, `eduai.php` tiene un fallback HTTP nativo de PHP. La API key se mantiene del lado del servidor y `.htaccess` bloquea el acceso directo a `eduai-config.php` y `db.php`.

### Clave de Gemini
Por seguridad, el paquete final no incluye una clave activa. Configurá la variable de entorno `GEMINI_API_KEY` o colocá una nueva clave en `eduai-config.php`. La clave anterior debe considerarse expuesta y conviene regenerarla en Google AI Studio.

Para XAMPP/local, copiá `eduai-config.local.php.example` como `eduai-config.local.php` y pegá una clave NUEVA en `GEMINI_API_KEY`. `eduai.php` busca primero una variable de entorno y luego ese archivo local. Si falta la clave, el chat ahora muestra el motivo exacto en vez de un error genérico.
