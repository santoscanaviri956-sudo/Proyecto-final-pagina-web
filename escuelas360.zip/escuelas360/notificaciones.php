<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'error'=>'Necesitás iniciar sesión.'],JSON_UNESCAPED_UNICODE);exit;}
$uid=(int)$_SESSION['user_id'];
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS configuraciones_usuario (id INT NOT NULL AUTO_INCREMENT,usuario_id INT NOT NULL,tema VARCHAR(20) NOT NULL DEFAULT 'claro',texto_grande TINYINT(1) NOT NULL DEFAULT 0,nivel_preferido VARCHAR(50) DEFAULT NULL,barrio_preferido VARCHAR(100) DEFAULT NULL,orientacion_preferida VARCHAR(100) DEFAULT NULL,notificaciones_email TINYINT(1) NOT NULL DEFAULT 1,actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_config_usuario(usuario_id),CONSTRAINT fk_config_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->prepare('INSERT IGNORE INTO configuraciones_usuario(usuario_id,notificaciones_email) SELECT id,COALESCE(notif_email,1) FROM usuarios WHERE id=?')->execute([$uid]);
  if($_SERVER['REQUEST_METHOD']==='GET'){
    $st=$pdo->prepare('SELECT notificaciones_email FROM configuraciones_usuario WHERE usuario_id=? LIMIT 1');$st->execute([$uid]);$row=$st->fetch();
    echo json_encode(['success'=>true,'notif_email'=>(bool)($row['notificaciones_email']??true)],JSON_UNESCAPED_UNICODE);exit;
  }
  $in=json_decode(file_get_contents('php://input'),true);if(!is_array($in))$in=$_POST;$value=!empty($in['notif_email'])?1:0;
  $st=$pdo->prepare('UPDATE configuraciones_usuario SET notificaciones_email=? WHERE usuario_id=?');$st->execute([$value,$uid]);
  try{$pdo->prepare('UPDATE usuarios SET notif_email=? WHERE id=?')->execute([$value,$uid]);}catch(Throwable $e){}
  echo json_encode(['success'=>true,'notif_email'=>(bool)$value],JSON_UNESCAPED_UNICODE);
}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'error'=>'No se pudo guardar la preferencia.'],JSON_UNESCAPED_UNICODE);}
