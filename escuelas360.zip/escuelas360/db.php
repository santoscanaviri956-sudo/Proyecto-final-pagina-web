<?php
declare(strict_types=1);

/*
 * Conexión de Colegio 360 con MySQL/MariaDB.
 * Configuración típica de XAMPP:
 * host: localhost | base: escuelas360 | usuario: root | contraseña: vacía
 */
const DB_HOST = 'localhost';
const DB_NAME = 'escuelas360';
const DB_USER = 'root';
const DB_PASS = '';

try {
    // Primero intentamos conectar directamente a la base.
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $firstError) {
    // Si la base todavía no existe, la creamos y volvemos a conectar.
    try {
        $server = new PDO(
            'mysql:host=' . DB_HOST . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        $server->exec(
            'CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` ' .
            'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
        );

        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
    } catch (PDOException $e) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false,
            'error' => 'No se pudo conectar a MySQL ni crear la base de datos escuelas360.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
