<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

function ensureSchoolsTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS escuelas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cue VARCHAR(30) NULL,
        cue_anexo VARCHAR(30) NULL UNIQUE,
        nombre VARCHAR(255) NOT NULL,
        nombre_abreviado VARCHAR(255) NULL,
        provincia VARCHAR(100) NULL,
        jurisdiccion VARCHAR(150) NULL,
        departamento VARCHAR(150) NULL,
        localidad VARCHAR(150) NULL,
        barrio VARCHAR(150) NULL,
        direccion VARCHAR(255) NULL,
        numero VARCHAR(30) NULL,
        codigo_postal VARCHAR(20) NULL,
        lat DECIMAL(10,7) NULL,
        lng DECIMAL(10,7) NULL,
        nivel VARCHAR(150) NULL,
        modalidad VARCHAR(150) NULL,
        orientacion VARCHAR(255) NULL,
        tipo VARCHAR(150) NULL,
        gestion VARCHAR(100) NULL,
        sector VARCHAR(100) NULL,
        ambito VARCHAR(100) NULL,
        turno VARCHAR(100) NULL,
        jornada VARCHAR(100) NULL,
        telefono VARCHAR(100) NULL,
        email VARCHAR(190) NULL,
        web VARCHAR(255) NULL,
        oferta_educativa TEXT NULL,
        dependencia VARCHAR(255) NULL,
        estado VARCHAR(100) NULL,
        rating DECIMAL(3,2) NULL,
        img TEXT NULL,
        cert VARCHAR(255) NULL,
        fuente VARCHAR(255) NULL,
        fecha_actualizacion DATE NULL,
        cuota INT NULL DEFAULT 0,
        matricula INT NULL DEFAULT 0,
        metodologia VARCHAR(100) NULL,
        becas TINYINT(1) NOT NULL DEFAULT 0,
        servicios VARCHAR(500) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // La BD original de algunos equipos tenía una tabla `escuelas` reducida.
    // El frontend/importador usan el esquema completo, así que completamos
    // las columnas faltantes sin borrar ni reemplazar datos existentes.
    $missingColumns = [
        'cue' => 'VARCHAR(30) NULL',
        'cue_anexo' => 'VARCHAR(30) NULL',
        'nombre_abreviado' => 'VARCHAR(255) NULL',
        'provincia' => 'VARCHAR(100) NULL',
        'jurisdiccion' => 'VARCHAR(150) NULL',
        'departamento' => 'VARCHAR(150) NULL',
        'localidad' => 'VARCHAR(150) NULL',
        'barrio' => 'VARCHAR(150) NULL',
        'numero' => 'VARCHAR(30) NULL',
        'codigo_postal' => 'VARCHAR(20) NULL',
        'lat' => 'DECIMAL(10,7) NULL',
        'lng' => 'DECIMAL(10,7) NULL',
        'nivel' => 'VARCHAR(150) NULL',
        'modalidad' => 'VARCHAR(150) NULL',
        'orientacion' => 'VARCHAR(255) NULL',
        'tipo' => 'VARCHAR(150) NULL',
        'gestion' => 'VARCHAR(100) NULL',
        'sector' => 'VARCHAR(100) NULL',
        'ambito' => 'VARCHAR(100) NULL',
        'turno' => 'VARCHAR(100) NULL',
        'jornada' => 'VARCHAR(100) NULL',
        'telefono' => 'VARCHAR(100) NULL',
        'email' => 'VARCHAR(190) NULL',
        'web' => 'VARCHAR(255) NULL',
        'oferta_educativa' => 'TEXT NULL',
        'dependencia' => 'VARCHAR(255) NULL',
        'estado' => 'VARCHAR(100) NULL',
        'rating' => 'DECIMAL(3,2) NULL',
        'img' => 'TEXT NULL',
        'cert' => 'VARCHAR(255) NULL',
        'fuente' => 'VARCHAR(255) NULL',
        'fecha_actualizacion' => 'DATE NULL',
        'cuota' => 'INT NULL DEFAULT 0',
        'matricula' => 'INT NULL DEFAULT 0',
        'metodologia' => 'VARCHAR(100) NULL',
        'becas' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'servicios' => 'VARCHAR(500) NULL',
        'created_at' => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
        'updated_at' => 'DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
    ];
    foreach ($missingColumns as $column => $definition) {
        try { $pdo->exec("ALTER TABLE escuelas ADD COLUMN `$column` $definition"); } catch (Throwable $e) {}
    }

    // Conservamos los nombres del esquema viejo y los copiamos a los nombres
    // que usa el importador/frontend cuando todavía están vacíos.
    try { $pdo->exec("UPDATE escuelas SET nivel=COALESCE(NULLIF(nivel,''),nivel_educativo) WHERE nivel_educativo IS NOT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("UPDATE escuelas SET gestion=COALESCE(NULLIF(gestion,''),tipo_gestion) WHERE tipo_gestion IS NOT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("UPDATE escuelas SET email=COALESCE(NULLIF(email,''),email_contacto) WHERE email_contacto IS NOT NULL"); } catch (Throwable $e) {}

    try { $pdo->exec("ALTER TABLE escuelas ADD UNIQUE KEY uq_escuelas_cue_anexo (cue_anexo)"); } catch (Throwable $e) {}
}

function seedDemo(PDO $pdo): void {
    $count=(int)$pdo->query('SELECT COUNT(*) FROM escuelas')->fetchColumn();
    if($count>=100) return;
    $file=__DIR__.'/data/demo_100_escuelas.json';
    if(!is_file($file)) return;
    $items=json_decode((string)file_get_contents($file),true);
    if(!is_array($items)) return;
    $stmt=$pdo->prepare("INSERT IGNORE INTO escuelas (cue_anexo,nombre,provincia,jurisdiccion,departamento,localidad,direccion,codigo_postal,telefono,email,nivel,modalidad,orientacion,tipo,gestion,sector,ambito,oferta_educativa,estado,rating,lat,lng,fuente,fecha_actualizacion,cuota,matricula,metodologia,becas,servicios) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach($items as $s){$stmt->execute([$s['cue_anexo'],$s['nombre'],$s['provincia'],$s['jurisdiccion'],$s['departamento'],$s['localidad'],$s['direccion'],$s['codigo_postal'],$s['telefono'],$s['email'],$s['nivel'],$s['modalidad'],$s['orientacion'],$s['tipo'],$s['gestion'],$s['sector'],$s['ambito'],$s['oferta_educativa'],$s['estado'],$s['rating'],$s['lat'],$s['lng'],$s['fuente'],$s['fecha_actualizacion'],$s['cuota'],$s['matricula'],$s['metodologia'],$s['becas']?1:0,$s['servicios']]);}
}

try {
    ensureSchoolsTable($pdo); seedDemo($pdo);
    $stmt=$pdo->query("SELECT * FROM escuelas WHERE nivel LIKE '%Secund%' OR modalidad LIKE '%Técnica%' ORDER BY nombre ASC");
    $escuelas=$stmt->fetchAll();
    echo json_encode(['success'=>true,'count'=>count($escuelas),'escuelas'=>$escuelas],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch(Throwable $e) { http_response_code(500); echo json_encode(['success'=>false,'error'=>'No se pudieron cargar las escuelas desde MySQL.','detail'=>$e->getMessage()],JSON_UNESCAPED_UNICODE); }
