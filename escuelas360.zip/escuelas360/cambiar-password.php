<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['success'=>false,'error'=>'Necesitás iniciar sesión.'],JSON_UNESCAPED_UNICODE); exit; }
try {
  $in = json_decode(file_get_contents('php://input'), true);
  if (!is_array($in)) $in = $_POST;
  $actual = (string)($in['actual'] ?? '');
  $nueva = (string)($in['nueva'] ?? '');
  if ($actual === '' || $nueva === '') throw new RuntimeException('Completá tu contraseña actual y la nueva.');
  if (strlen($nueva) < 6) throw new RuntimeException('La nueva contraseña debe tener al menos 6 caracteres.');

  $uid = (int)$_SESSION['user_id'];
  $st = $pdo->prepare('SELECT password FROM usuarios WHERE id=? LIMIT 1');
  $st->execute([$uid]);
  $row = $st->fetch();
  if (!$row) throw new RuntimeException('Usuario no encontrado.');
  if (!password_verify($actual, $row['password'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'error'=>'Tu contraseña actual no es correcta.'],JSON_UNESCAPED_UNICODE);
    exit;
  }
  $hash = password_hash($nueva, PASSWORD_DEFAULT);
  $st = $pdo->prepare('UPDATE usuarios SET password=? WHERE id=?');
  $st->execute([$hash, $uid]);
  echo json_encode(['success'=>true],JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>$e->getMessage() ?: 'No se pudo cambiar la contraseña.'],JSON_UNESCAPED_UNICODE);
}
