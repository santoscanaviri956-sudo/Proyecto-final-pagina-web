<?php
declare(strict_types=1);

/*
 * Colegio 360 — EduAI
 *
 * El navegador nunca llama a Gemini directamente. Este endpoint arma un
 * contexto acotado y verificable con los datos que usa la web, mantiene el
 * hilo de la conversación y puede devolver la respuesta por SSE para que
 * aparezca mientras el modelo la genera.
 */
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/eduai-config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function eduai_json(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function eduai_sse(string $event, array $data): void {
    echo "event: {$event}\n";
    echo 'data: ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\n";
    @ob_flush();
    flush();
}

function eduai_fail(string $reason, int $status = 200): never {
    if (defined('EDUAI_STREAM') && EDUAI_STREAM && isset($_GET['stream']) && $_GET['stream'] === '1') {
        header('Content-Type: text/event-stream; charset=utf-8');
        header('Cache-Control: no-cache, no-transform');
        header('X-Accel-Buffering: no');
        eduai_sse('error', ['success' => false, 'reason' => $reason]);
        exit;
    }
    eduai_json(['success' => false, 'needs_fallback' => true, 'reason' => $reason], $status);
}

function eduai_strlen(string $s): int { return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s); }
function eduai_substr(string $s, int $start, int $length): string { return function_exists('mb_substr') ? mb_substr($s, $start, $length, 'UTF-8') : substr($s, $start, $length); }
function eduai_norm(?string $s): string {
    $s = trim((string)$s);
    $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
    $s = strtr($s, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u','ñ'=>'n']);
    $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
    return $s;
}

function eduai_tokens(string $q): array {
    $q = eduai_norm($q);
    $raw = preg_split('/[^a-z0-9]+/i', $q) ?: [];
    $stop = array_flip([
        'que','como','donde','cuanto','cuantas','cual','cuales','para','por','con','del','las','los','una','uno','unos','unas',
        'el','la','de','en','un','y','o','a','me','mi','mis','yo','es','hay','quiero','busco','podes','puedo','tenes','tiene',
        'colegio','colegios','escuela','escuelas','instituto','institutos','informacion','información','sobre','esta','este','ese','quiero','necesito'
    ]);
    $out=[];
    foreach ($raw as $t) {
        if (eduai_strlen($t) >= 2 && !isset($stop[$t])) $out[$t]=true;
    }
    return array_keys($out);
}

function eduai_load_json(string $file): array {
    if (!is_file($file)) return [];
    $raw = @file_get_contents($file);
    if ($raw === false) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function eduai_school_key(array $s): string {
    return eduai_norm((string)($s['cue_anexo'] ?? $s['cue'] ?? $s['id'] ?? $s['nombre'] ?? ''));
}

function eduai_catalog(): array {
    static $catalog = null;
    if ($catalog !== null) return $catalog;

    $official = eduai_load_json(__DIR__ . '/data/padron_caba.json');
    $rich = eduai_load_json(__DIR__ . '/data/caba_secondary_demo_oficial.json');
    $legacy = eduai_load_json(__DIR__ . '/data/secondary_schools_demo.json');
    $demo = eduai_load_json(__DIR__ . '/data/demo_100_escuelas.json');

    $richByCue=[];
    foreach ($rich as $s) {
        $k=eduai_school_key($s); if ($k) $richByCue[$k]=$s;
    }
    $seen=[]; $catalog=[];
    foreach ($official as $s) {
        $k=eduai_school_key($s);
        if (!$k || isset($seen[$k])) continue;
        if (isset($richByCue[$k])) {
            // El padrón conserva los datos institucionales; la fuente rica
            // sólo complementa campos que el padrón no trae.
            foreach ($richByCue[$k] as $field=>$value) {
                $current=$s[$field]??null;
                $placeholder=is_string($current) && in_array(eduai_norm($current),['no informado','no informada','sin datos',''],true);
                if (!array_key_exists($field,$s) || $current===null || $current==='' || $current===[] || $placeholder) { $s[$field]=$value; }
            }
        }
        $seen[$k]=true; $catalog[]=$s;
    }
    foreach (array_merge($legacy,$demo) as $s) {
        $k=eduai_school_key($s);
        if (!$k || isset($seen[$k])) continue;
        $seen[$k]=true; $catalog[]=$s;
    }
    return $catalog = $catalog;
}

function eduai_score_school(array $s, string $q, array $tokens): int {
    $name = eduai_norm((string)($s['nombre'] ?? ''));
    $address = eduai_norm((string)($s['direccion'] ?? ''));
    $zone = eduai_norm((string)($s['barrio'] ?? $s['zona'] ?? $s['departamento'] ?? $s['localidad'] ?? ''));
    $level = eduai_norm((string)($s['nivel'] ?? implode(' ', (array)($s['niveles'] ?? []))));
    $modality = eduai_norm((string)($s['modalidad'] ?? implode(' ', (array)($s['modalidades'] ?? []))));
    $orientation = eduai_norm((string)($s['orientacion'] ?? ''));
    $gestion = eduai_norm((string)($s['gestion'] ?? $s['sector'] ?? ''));
    $jornada = eduai_norm((string)($s['jornada'] ?? $s['turno'] ?? $s['jornadas'] ?? ''));
    $services = $s['servicios'] ?? ''; if (is_array($services)) $services=implode(' ', $services);
    $services = eduai_norm((string)$services);
    $becasText=array_key_exists('becas',$s)?((bool)$s['becas']?'becas disponible':'sin becas'):'';
    $cuotaText=array_key_exists('cuota',$s)&&is_numeric($s['cuota'])?'cuota precio '.(string)$s['cuota'] : '';
    $ratingText=array_key_exists('rating',$s)&&is_numeric($s['rating'])?'rating '.(string)$s['rating'] : '';
    $full = implode(' ', [$name,$address,$zone,$level,$modality,$orientation,$gestion,$jornada,$services,eduai_norm((string)($s['oferta_educativa']??'')),$becasText,$cuotaText,$ratingText]);
    $score = 0;
    if ($name !== '' && $q !== '' && str_contains($name, $q)) $score += 160;
    foreach ($tokens as $t) {
        if ($name !== '' && str_contains($name,$t)) $score += 44;
        elseif ($address !== '' && str_contains($address,$t)) $score += 17;
        elseif ($zone !== '' && str_contains($zone,$t)) $score += 19;
        elseif ($level !== '' && str_contains($level,$t)) $score += 15;
        elseif ($modality !== '' && str_contains($modality,$t)) $score += 14;
        elseif ($orientation !== '' && str_contains($orientation,$t)) $score += 13;
        elseif ($gestion !== '' && str_contains($gestion,$t)) $score += 13;
        elseif ($jornada !== '' && str_contains($jornada,$t)) $score += 10;
        elseif ($services !== '' && str_contains($services,$t)) $score += 8;
        elseif (str_contains($full,$t)) $score += 4;
    }
    return $score;
}

function eduai_intent_schools(string $message, array $catalog): array {
    $q=eduai_norm($message);
    $out=[];
    $hasPrice=(bool)preg_match('/\b(barato|baratos|barata|baratas|economico|economica|economicos|economicas|cuota|precio|precios|pagar|accesible|accesibles)\b/u',$q);
    $hasScholarship=str_contains($q,'beca') || str_contains($q,'becas');
    $hasRating=(bool)preg_match('/\b(mejor|mejores|mejor valorad|rating|valoracion|valoraciones|puntaje|puntuacion)\b/u',$q);
    $hasFree=(bool)preg_match('/\b(gratis|gratuita|gratuito|sin cuota|sin pagar)\b/u',$q);
    $candidateSets=[];
    if($hasPrice){
        $tmp=array_values(array_filter($catalog,fn($s)=>array_key_exists('cuota',$s) && is_numeric($s['cuota'])));
        usort($tmp,fn($a,$b)=>(float)$a['cuota']<=>(float)$b['cuota']); $candidateSets[]=$tmp;
    }
    if($hasScholarship){
        $tmp=array_values(array_filter($catalog,fn($s)=>array_key_exists('becas',$s) && (bool)$s['becas']));
        $candidateSets[]=$tmp;
    }
    if($hasRating){
        $tmp=array_values(array_filter($catalog,fn($s)=>array_key_exists('rating',$s) && is_numeric($s['rating'])));
        usort($tmp,fn($a,$b)=>((float)$b['rating']<=>(float)$a['rating'])); $candidateSets[]=$tmp;
    }
    if($hasFree){
        $tmp=array_values(array_filter($catalog,fn($s)=>array_key_exists('cuota',$s) && is_numeric($s['cuota']) && (float)$s['cuota']<=0));
        $candidateSets[]=$tmp;
    }
    foreach($candidateSets as $set) foreach($set as $s){
        $k=eduai_school_key($s); if($k && !isset($out[$k])) $out[$k]=$s;
        if(count($out)>=EDUAI_MAX_SCHOOLS_IN_CONTEXT) break;
        }
    return array_values($out);
}

function eduai_relevant_schools(string $message): array {
    $catalog=eduai_catalog();
    $q=eduai_norm($message);
    $tokens=eduai_tokens($message);
    if (!$tokens && $q !== '') $tokens = [$q];
    $scored=[];
    foreach ($catalog as $s) {
        $score=eduai_score_school($s,$q,$tokens);
        if ($score > 0) $scored[] = [$score,$s];
    }
    usort($scored, fn($a,$b)=>$b[0]<=>$a[0]);
    $intent=eduai_intent_schools($message,$catalog);
    $result=[]; $seen=[];
    foreach(array_merge($intent,array_map(fn($p)=>$p[1],$scored)) as $s){
        $k=eduai_school_key($s); if(!$k || isset($seen[$k])) continue;
        $seen[$k]=true; $result[]=$s;
        if(count($result)>=EDUAI_MAX_SCHOOLS_IN_CONTEXT) break;
    }
    return $result;
}

function eduai_try_db(): ?PDO {
    static $pdo = false;
    if ($pdo instanceof PDO) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host='.EDUAI_DB_HOST.';dbname='.EDUAI_DB_NAME.';charset=utf8mb4',
            EDUAI_DB_USER,
            EDUAI_DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
        );
        return $pdo;
    } catch (Throwable $e) {
        $pdo = null;
        return null;
    }
}

function eduai_save_message(int $userId, string $question, string $reply, array $context): void {
    if ($userId <= 0 || $question === '' || $reply === '') return;
    $pdo = eduai_try_db();
    if (!$pdo) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS eduai_conversaciones (
            id INT NOT NULL AUTO_INCREMENT,
            usuario_id INT NOT NULL,
            pregunta TEXT NOT NULL,
            respuesta TEXT NOT NULL,
            contexto LONGTEXT NULL,
            fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            KEY idx_eduai_usuario_fecha(usuario_id,fecha),
            CONSTRAINT fk_eduai_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $st=$pdo->prepare('INSERT INTO eduai_conversaciones(usuario_id,pregunta,respuesta,contexto) VALUES(?,?,?,?)');
        $safeContext=[
            'filters'=>$context['filters']??[],
            'currentSchool'=>$context['currentSchool']??null,
            'visibleCount'=>$context['visibleCount']??null,
        ];
        $st->execute([$userId,$question,$reply,json_encode($safeContext,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    } catch(Throwable $e) { /* El chat no debe dejar de funcionar por la BD. */ }
}

function eduai_load_history(int $userId): array {
    if ($userId <= 0) return [];
    $pdo=eduai_try_db();
    if (!$pdo) return [];
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS eduai_conversaciones (
            id INT NOT NULL AUTO_INCREMENT,
            usuario_id INT NOT NULL,
            pregunta TEXT NOT NULL,
            respuesta TEXT NOT NULL,
            contexto LONGTEXT NULL,
            fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id), KEY idx_eduai_usuario_fecha(usuario_id,fecha),
            CONSTRAINT fk_eduai_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $st=$pdo->prepare('SELECT pregunta,respuesta,fecha FROM eduai_conversaciones WHERE usuario_id=? ORDER BY id DESC LIMIT 10');
        $st->execute([$userId]);
        $rows=array_reverse($st->fetchAll());
        $history=[];
        foreach($rows as $r){
            $history[]=['role'=>'user','text'=>(string)$r['pregunta']];
            $history[]=['role'=>'assistant','text'=>(string)$r['respuesta']];
        }
        return array_slice($history,-EDUAI_MAX_HISTORY);
    } catch(Throwable $e) { return []; }
}

function eduai_public_user_context(): array {
    $uid=(int)($_SESSION['user_id']??0);
    if ($uid<=0) return ['authenticated'=>false];
    $pdo=eduai_try_db();
    if (!$pdo) return ['authenticated'=>true,'profile_available'=>false];
    try {
        $st=$pdo->prepare('SELECT nombre,email,birth_year,zona FROM usuarios WHERE id=? LIMIT 1');
        $st->execute([$uid]); $u=$st->fetch();
        if(!$u) return ['authenticated'=>false];
        $settings=['nivel_preferido'=>null,'barrio_preferido'=>null,'orientacion_preferida'=>null];
        try{
            $cfg=$pdo->prepare('SELECT nivel_preferido,barrio_preferido,orientacion_preferida FROM configuraciones_usuario WHERE usuario_id=? LIMIT 1');
            $cfg->execute([$uid]); $c=$cfg->fetch(); if($c)$settings=array_merge($settings,$c);
        }catch(Throwable $e){}
        $favorites=[]; $compare=[];
        try{ $qf=$pdo->prepare('SELECT escuela_id FROM favoritos WHERE usuario_id=? ORDER BY id ASC LIMIT 20'); $qf->execute([$uid]); $favorites=array_map('strval',array_column($qf->fetchAll(),'escuela_id')); }catch(Throwable $e){}
        try{ $qc=$pdo->prepare('SELECT escuela_id FROM comparaciones WHERE usuario_id=? ORDER BY id ASC LIMIT 3'); $qc->execute([$uid]); $compare=array_map('strval',array_column($qc->fetchAll(),'escuela_id')); }catch(Throwable $e){}
        return ['authenticated'=>true,'profile_available'=>true,'nombre'=>$u['nombre'],'email'=>$u['email'],'birth_year'=>$u['birth_year']??null,'zona'=>$u['zona']??null,'preferencias'=>$settings,'favoritos_ids'=>$favorites,'comparar_ids'=>$compare];
    } catch(Throwable $e) { return ['authenticated'=>true,'profile_available'=>false]; }
}

function eduai_build_prompt(array $context, array $relevant, array $userContext): string {
    $rows=[];
    foreach($relevant as $s){
        $services=$s['servicios']??null;
        if(is_array($services)) $services=implode(', ',$services);
        $rows[]='- '.implode(' | ',[
            'Nombre: '.($s['nombre']??'Sin nombre'),
            'CUE: '.($s['cue_anexo']??$s['cue']??$s['id']??'—'),
            'Nivel: '.($s['nivel']??'—'),
            'Modalidad: '.($s['modalidad']??(is_array($s['modalidades']??null)?implode(', ',$s['modalidades']):'—')),
            'Orientación: '.($s['orientacion']??'No informada'),
            'Gestión: '.($s['gestion']??$s['sector']??'—'),
            'Zona/barrio: '.($s['barrio']??$s['departamento']??$s['localidad']??'—'),
            'Dirección: '.($s['direccion']??'—'),
            'Teléfono: '.($s['telefono']??'—'),
            'Email: '.($s['email']??'—'),
            'Cuota demo: '.(array_key_exists('cuota',$s)?('$'.number_format((float)$s['cuota'],0,',','.')):'no informada'),
            'Matrícula demo: '.(array_key_exists('matricula',$s)?('$'.number_format((float)$s['matricula'],0,',','.')):'no informada'),
            'Becas demo: '.(array_key_exists('becas',$s)?((bool)$s['becas']?'sí':'no'):'no informadas'),
            'Servicios demo: '.($services!==null?(string)$services:'no informados'),
            'Rating demo: '.(array_key_exists('rating',$s)?(string)$s['rating']:'no informado'),
            'Fuente: '.($s['fuente']??'Padrón/metadata del proyecto'),
        ]);
    }
    $visible=[];
    foreach((array)($context['visibleSchools']??[]) as $s){
        $visible[]='- '.implode(' | ',[
            'Nombre: '.($s['nombre']??'—'),'Nivel: '.($s['nivel']??'—'),'Modalidad: '.($s['modalidad']??'—'),
            'Orientación: '.($s['orientacion']??'—'),'Zona: '.($s['barrio']??$s['localidad']??'—'),'Dirección: '.($s['direccion']??'—')
        ]);
    }
    $siteContext=[
        'visibleCount'=>(int)($context['visibleCount']??0),
        'filters'=>$context['filters']??[],
        'currentSchool'=>$context['currentSchool']??null,
        'favoritesCount'=>(int)($context['favoritesCount']??0),
        'compareCount'=>(int)($context['compareCount']??0),
        'page'=>(string)($context['page']??'menu.html'),
    ];

    $prompt=<<<'PROMPT'
Sos EduAI, el asistente inteligente de Colegio 360. Hablás en español rioplatense claro y natural.

OBJETIVO
Ayudá al usuario a entender y usar TODO lo relacionado con Colegio 360: búsqueda de colegios, filtros, mapa, fichas, favoritos, comparar, perfil, ajustes, cuenta, reseñas y el funcionamiento de EduAI. También podés responder preguntas sobre colegios concretos cuando haya datos en el contexto.

COMPORTAMIENTO
- Conversá como una IA real. No dependas de frases prefabricadas ni respondas siempre con las mismas estructuras.
- Entendé saludos, respuestas cortas, preguntas ambiguas, errores de escritura y lenguaje coloquial.
- No le digas al usuario que "no hay una respuesta específica" solo porque una pregunta no coincide con una regla. Razoná con el contexto y contestá de forma útil.
- No inventes datos de colegios. Diferenciá SIEMPRE los datos del Padrón Oficial de los datos de demostración: cuota, matrícula, rating, becas, orientación, servicios y jornadas son de demo cuando estén marcados así.
- Cuando el usuario pida un colegio por nombre, priorizá coincidencias de NOMBRE sobre coincidencias que solo aparecen en la dirección. Si hay más de una institución posible, explicá la ambigüedad y listá las mejores coincidencias.
- Si no encontrás el colegio en los datos, decí que no aparece en la base cargada y sugerí usar la búsqueda por nombre/dirección o el filtro de zona. No afirmes que no existe.
- Para preguntas sobre navegación, explicá exactamente dónde tocar: Inicio, menú de resultados, Información de perfil o Ajustes.
- Si la persona pregunta por su propia cuenta, usá solo el contexto de usuario autenticado que te paso. Nunca reveles contraseñas ni datos que no estén incluidos.
- Podés mencionar valores concretos de perfil (nombre, correo, año de nacimiento, zona) solo si ayudan a responder. No inventes teléfono, DNI o dirección. Si el usuario pregunta por Favoritos o Comparar, usá los IDs/contexto disponibles y explicá cómo abrir esas secciones.
- Si la pregunta es "hola", "gracias", "no quiero" o una charla breve, respondé naturalmente y no fuerces una recomendación de colegios.
- Si una pregunta es ajena a Colegio 360, respondé brevemente que tu función es ayudar con la plataforma y colegios.
- Mantené respuestas útiles y fáciles de leer en una burbuja de chat: normalmente 2-8 frases; usá pequeñas listas solo cuando mejoren la claridad.

FUNCIONES Y RUTAS DE LA PÁGINA
- inicio.html: portada, búsqueda inicial y filtros rápidos.
- menu.html: listado, mapa, filtros completos, fichas, Favoritos, Comparar y EduAI.
- informacion-perfil.html: editar nombre, año de nacimiento, zona/barrio, teléfono, dirección y DNI de la cuenta.
- ajustes.html: apariencia (claro/oscuro), texto grande, búsqueda por defecto, notificaciones, contraseña, privacidad, eliminar cuenta y acceso al comparador.
- login.html / registro.html: iniciar sesión y crear cuenta.

REGLA FINAL
Contestá primero la pregunta concreta. Solo agregá pasos o recomendaciones cuando realmente ayuden. Basate en la información recibida y no inventes datos.
PROMPT;

    $prompt .= "\n\nCONTEXTO ACTUAL DE LA PÁGINA\n" . json_encode($siteContext,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $prompt .= "\n\nCOLEGIOS VISIBLES AHORA\n" . ($visible ? implode("\n",$visible) : '(ninguno)');
    $prompt .= "\n\nCOLEGIOS RELEVANTES PARA ESTA CONSULTA\n" . ($rows ? implode("\n",$rows) : '(ninguno)');
    $prompt .= "\n\nCONTEXTO DEL USUARIO AUTENTICADO\n" . json_encode($userContext,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $prompt .= "\n\nREGLAS DE INTENCIÓN\n";
    $prompt .= "Cuando pregunten por 'mi perfil', 'mi información', 'mis datos', 'mi cuenta' o datos personales, respondé usando el contexto de usuario y explicá que se editan en informacion-perfil.html. No confundas Perfil con una ficha de colegio. ";
    $prompt .= "Cuando pregunten por un colegio concreto, usá primero COLEGIOS RELEVANTES y luego COLEGIOS VISIBLES. Si el nombre coincide de forma parcial, explicá la coincidencia en lugar de responder que no hay información. ";
    $prompt .= "Cuando la consulta sea una conversación normal, no la conviertas artificialmente en una búsqueda. ";
    $prompt .= "Cuando el usuario pregunte por funciones de la web, podés explicar el funcionamiento aunque no haya colegios relevantes. ";
    return $prompt;
}

function eduai_consume_sse_line(string $line, string &$fullReply, ?string &$apiError): void {
    $line=rtrim($line,"\r");
    if(strpos($line,'data:')!==0) return;
    $json=trim(substr($line,5));
    if($json==='' || $json==='[DONE]') return;
    $d=json_decode($json,true);
    if(!is_array($d)) return;
    $err=$d['error']['message']??null;
    if($err){
        $apiError=(string)$err;
        if(headers_sent()===false) eduai_sse('error',['success'=>false,'reason'=>'api_error','message'=>$apiError]);
        return;
    }
    $parts=$d['candidates'][0]['content']['parts']??[];
    foreach((array)$parts as $part){
        if(!empty($part['thought'])) continue;
        if(!isset($part['text'])) continue;
        $text=(string)$part['text'];
        if($text==='') continue;
        $fullReply.=$text;
        eduai_sse('token',['text'=>$text]);
    }
}

function eduai_http_status_from_headers(array $headers): int {
    foreach(array_reverse($headers) as $line){
        if(preg_match('/^HTTP\/\S+\s+(\d{3})/i',(string)$line,$m)) return (int)$m[1];
    }
    return 0;
}

function eduai_stream_with_php(string $endpoint, string $payload, string $key, string &$fullReply, ?string &$apiError): int {
    $ctx=stream_context_create(['http'=>[
        'method'=>'POST',
        'header'=>"Content-Type: application/json\r\nAccept: text/event-stream\r\nx-goog-api-key: {$key}\r\n",
        'content'=>$payload,
        'timeout'=>45,
        'ignore_errors'=>true,
    ]]);
    $fp=@fopen($endpoint,'rb',false,$ctx);
    if(!$fp) return 0;
    $headers=$http_response_header??[];
    $lineBuffer='';
    while(!feof($fp)){
        $chunk=fread($fp,8192);
        if($chunk===false) break;
        if($chunk==='') { usleep(10000); continue; }
        $lineBuffer.=$chunk;
        while(($pos=strpos($lineBuffer,"\n"))!==false){
            $line=substr($lineBuffer,0,$pos);
            $lineBuffer=substr($lineBuffer,$pos+1);
            eduai_consume_sse_line($line,$fullReply,$apiError);
        }
    }
    if($lineBuffer!=='') eduai_consume_sse_line($lineBuffer,$fullReply,$apiError);
    fclose($fp);
    return eduai_http_status_from_headers($headers);
}

function eduai_request_json_with_php(string $endpoint, string $payload, string $key, int &$http): ?string {
    $ctx=stream_context_create(['http'=>[
        'method'=>'POST',
        'header'=>"Content-Type: application/json\r\nAccept: application/json\r\nx-goog-api-key: {$key}\r\n",
        'content'=>$payload,
        'timeout'=>45,
        'ignore_errors'=>true,
    ]]);
    $response=@file_get_contents($endpoint,false,$ctx);
    $http=eduai_http_status_from_headers($http_response_header??[]);
    return $response===false?null:$response;
}

function eduai_payload(string $message, array $history, array $context, array $relevant, array $userContext): array {
    $contents=[];
    foreach(array_slice($history,-EDUAI_MAX_HISTORY) as $h){
        $role=(($h['role']??'')==='assistant'?'model':'user');
        $text=trim((string)($h['text']??''));
        if($text!=='') $contents[]=['role'=>$role,'parts'=>[['text'=>$text]]];
    }
    $contents[]=['role'=>'user','parts'=>[['text'=>$message]]];
    return [
        'systemInstruction'=>['parts'=>[['text'=>eduai_build_prompt($context,$relevant,$userContext)]]],
        'contents'=>$contents,
        'generationConfig'=>[
            'maxOutputTokens'=>900,
            'thinkingConfig'=>['thinkingLevel'=>'medium'],
        ],
    ];
}

function eduai_api_key(): string {
    $env=trim((string)getenv('GEMINI_API_KEY'));
    if($env!=='') return $env;
    return defined('GEMINI_API_KEY') ? trim((string)GEMINI_API_KEY) : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && (($_GET['history'] ?? '') === '1')) {
    $history=eduai_load_history((int)($_SESSION['user_id']??0));
    eduai_json(['success'=>true,'history'=>$history]);
}

$raw=file_get_contents('php://input');
$body=json_decode($raw?:'{}',true);
if(!is_array($body)) $body=[];
$message=trim((string)($body['message']??''));
if($message==='') eduai_fail('empty_message',400);
$message=eduai_substr($message,0,1200);
$history=is_array($body['history']??null)?$body['history']:[];
$context=is_array($body['context']??null)?$body['context']:[];
$context['visibleSchools']=is_array($context['visibleSchools']??null)?array_slice($context['visibleSchools'],0,EDUAI_MAX_VISIBLE_SCHOOLS):[];
$context['currentSchool']=is_array($context['currentSchool']??null)?$context['currentSchool']:null;
$userContext=eduai_public_user_context();
$relevant=eduai_relevant_schools($message);
$key=eduai_api_key();
if($key==='') eduai_fail('no_api_key',503);

$payload=json_encode(eduai_payload($message,$history,$context,$relevant,$userContext),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if($payload===false) eduai_fail('payload_error',500);

$stream=(($_GET['stream']??'0')==='1');
$apiBase=trim((string)(getenv('EDUAI_API_BASE_URL') ?: (defined('EDUAI_API_BASE_URL') ? EDUAI_API_BASE_URL : '')));
if($apiBase==='') $apiBase='https://generativelanguage.googleapis.com/v1beta';
$apiBase=rtrim($apiBase,'/');
$endpoint=$apiBase.'/models/'.rawurlencode(EDUAI_MODEL).($stream?':streamGenerateContent?alt=sse':':generateContent');
$ch=function_exists('curl_init')?curl_init($endpoint):null;
$fullReply=''; $lineBuffer=''; $apiError=null;

if($stream){
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-transform');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');
    @ini_set('output_buffering','off'); @ini_set('zlib.output_compression','0');
    echo ": eduai\n\n"; @ob_flush(); flush();
    eduai_sse('start',['success'=>true,'model'=>EDUAI_MODEL]);
}

if($ch){
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>!$stream,
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>$payload,
        CURLOPT_HTTPHEADER=>[
            'Content-Type: application/json',
            'Accept: '.($stream?'text/event-stream':'application/json'),
            'x-goog-api-key: '.$key,
        ],
        CURLOPT_CONNECTTIMEOUT=>8,
        CURLOPT_TIMEOUT=>45,
    ]);
}

$response=null; $http=0; $curlErr='';
if($ch){
    if($stream){
        curl_setopt($ch,CURLOPT_WRITEFUNCTION,function($ch,$chunk) use (&$lineBuffer,&$fullReply,&$apiError){
            $lineBuffer.=$chunk;
            while(($pos=strpos($lineBuffer,"\n"))!==false){
                $line=rtrim(substr($lineBuffer,0,$pos),"\r");
                $lineBuffer=substr($lineBuffer,$pos+1);
                eduai_consume_sse_line($line,$fullReply,$apiError);
            }
            return strlen($chunk);
        });
    }
    $response=curl_exec($ch);
    $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
    $curlErr=curl_error($ch);
    if($stream && $lineBuffer!=='') eduai_consume_sse_line($lineBuffer,$fullReply,$apiError);
    curl_close($ch);
} elseif($stream){
    $http=eduai_stream_with_php($endpoint,$payload,$key,$fullReply,$apiError);
    if($http===0) $curlErr='PHP HTTP stream is unavailable.';
} else {
    $response=eduai_request_json_with_php($endpoint,$payload,$key,$http);
    if($response===null) $curlErr='PHP HTTP request failed.';
}
if($stream){
    if($curlErr || $http<200 || $http>=300 || trim($fullReply)==='' || $apiError){
        if(!$apiError){ eduai_sse('error',['success'=>false,'reason'=>$curlErr?'network_error':'api_error_'.$http]); }
        exit;
    }
    eduai_save_message((int)($_SESSION['user_id']??0),$message,$fullReply,$context);
    eduai_sse('done',['success'=>true,'reply'=>$fullReply,'matched_schools'=>count($relevant)]);
    exit;
}

if($response===false || $curlErr) eduai_fail('network_error',502);
$decoded=json_decode((string)$response,true);
if($http<200 || $http>=300 || !is_array($decoded)) eduai_fail('api_error_'.$http,502);
$reply=trim((string)($decoded['candidates'][0]['content']['parts'][0]['text']??''));
if($reply==='') eduai_fail('empty_reply',502);
eduai_save_message((int)($_SESSION['user_id']??0),$message,$reply,$context);
eduai_json(['success'=>true,'reply'=>$reply,'matched_schools'=>count($relevant)]);
