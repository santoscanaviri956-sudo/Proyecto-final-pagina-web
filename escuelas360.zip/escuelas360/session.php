<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
try {
  $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT PRIMARY KEY,nombre VARCHAR(150) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,birth_year SMALLINT NULL,google_sub VARCHAR(255) NULL UNIQUE,zona VARCHAR(100) NULL,telefono VARCHAR(40) NULL,direccion VARCHAR(190) NULL,dni VARCHAR(30) NULL,creado_en DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  foreach ([
    'birth_year'=>'SMALLINT NULL','google_sub'=>'VARCHAR(255) NULL UNIQUE','zona'=>'VARCHAR(100) NULL','telefono'=>'VARCHAR(40) NULL','direccion'=>'VARCHAR(190) NULL','dni'=>'VARCHAR(30) NULL'
  ] as $col=>$def) { try { $pdo->exec("ALTER TABLE usuarios ADD COLUMN `$col` $def"); } catch(Throwable $e) {} }
  if (empty($_SESSION['user_id'])) { echo json_encode(['success'=>true,'authenticated'=>false],JSON_UNESCAPED_UNICODE); exit; }
  $stmt=$pdo->prepare('SELECT id,nombre,email,birth_year,zona,telefono,direccion,dni FROM usuarios WHERE id=? LIMIT 1');$stmt->execute([(int)$_SESSION['user_id']]);$user=$stmt->fetch();
  if(!$user){$_SESSION=[];echo json_encode(['success'=>true,'authenticated'=>false],JSON_UNESCAPED_UNICODE);exit;}
  echo json_encode(['success'=>true,'authenticated'=>true,'user'=>['id'=>(int)$user['id'],'nombre'=>$user['nombre'],'email'=>$user['email'],'birth_year'=>$user['birth_year']??null,'zona'=>$user['zona']??'','telefono'=>$user['telefono']??'','direccion'=>$user['direccion']??'','dni'=>$user['dni']??'']],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'authenticated'=>false],JSON_UNESCAPED_UNICODE);}
