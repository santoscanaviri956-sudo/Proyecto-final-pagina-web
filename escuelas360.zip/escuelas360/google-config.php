<?php
declare(strict_types=1);
const GOOGLE_CLIENT_ID = '486316380383-hcu6bqcc2j3j29jdnudr6ve65l34luur.apps.googleusercontent.com';
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['client_id' => GOOGLE_CLIENT_ID], JSON_UNESCAPED_UNICODE);
}
