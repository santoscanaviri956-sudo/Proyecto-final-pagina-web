```php
<?php

/**
 * ============================================================
 * COLEGIO 360
 * IMPORTADOR DEL PADRÓN OFICIAL DE ESTABLECIMIENTOS
 * ============================================================
 */

ini_set('memory_limit', '512M');
set_time_limit(0);
ini_set('display_errors', '1');
error_reporting(E_ALL);

// ============================================================
// BASE DE DATOS
// ============================================================

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'escuelas360';

// ============================================================
// DATOS DEL PADRÓN
// ============================================================

const FECHA_PADRON = '2026-06-16';
const FUENTE_PADRON = 'Padrón Oficial de Establecimientos Educativos';
const FILA_INICIO_DATOS = 14;
const LIMITE_PRUEBA = 20;

// ============================================================
// ARCHIVO XLSX
// IMPORTANTE: está en la misma carpeta que este PHP
// ============================================================

$archivoXlsx =
    __DIR__ .
    DIRECTORY_SEPARATOR .
    '2026.06.16_padron_oficial_establecimientos_educativos_die_icse.xlsx';

// ============================================================
// FUNCIONES GENERALES
// ============================================================

function limpiarTexto($valor)
{
    if ($valor === null) {
        return null;
    }

    $valor = (string) $valor;

    $valor = preg_replace(
        '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u',
        '',
        $valor
    );

    $valor = preg_replace(
        '/\s+/u',
        ' ',
        $valor
    );

    $valor = trim($valor);

    return $valor === '' ? null : $valor;
}

function limitarTexto($valor, $maximo)
{
    $valor = limpiarTexto($valor);

    if ($valor === null) {
        return null;
    }

    if (function_exists('mb_substr')) {
        return mb_substr(
            $valor,
            0,
            $maximo,
            'UTF-8'
        );
    }

    return substr($valor, 0, $maximo);
}

function esVerdadero($valor)
{
    if ($valor === null) {
        return false;
    }

    $valor = strtoupper(
        trim((string) $valor)
    );

    return in_array(
        $valor,
        [
            '1',
            'SI',
            'SÍ',
            'S',
            'YES',
            'TRUE',
            'X',
            'ACTIVO',
            'ACTIVA'
        ],
        true
    );
}

function normalizarCue($valor)
{
    if ($valor === null) {
        return null;
    }

    $valor = trim((string) $valor);

    if ($valor === '') {
        return null;
    }

    $valor = preg_replace(
        '/[^0-9]/',
        '',
        $valor
    );

    return $valor === '' ? null : $valor;
}

function obtenerCue($cueAnexo)
{
    if ($cueAnexo === null) {
        return null;
    }

    if (strlen($cueAnexo) >= 9) {
        return substr(
            $cueAnexo,
            0,
            7
        );
    }

    return $cueAnexo;
}

// ============================================================
// CONEXIÓN MYSQL
// ============================================================

function conectarBD()
{
    mysqli_report(
        MYSQLI_REPORT_ERROR |
        MYSQLI_REPORT_STRICT
    );

    $db = new mysqli(
        DB_HOST,
        DB_USER,
        DB_PASS,
        DB_NAME
    );

    $db->set_charset('utf8mb4');

    return $db;
}

// ============================================================
// LECTOR XLSX
// ============================================================

class XLSXReader
{
    private $zip;
    private $archivo;
    private $sheetPath = '';
    private $sharedStrings = [];

    public function __construct($archivo)
    {
        $this->archivo = $archivo;

        if (!class_exists('ZipArchive')) {
            throw new RuntimeException(
                'La extensión ZIP de PHP no está habilitada. Activá extension=zip en php.ini y reiniciá Apache.'
            );
        }

        if (!file_exists($archivo)) {
            throw new RuntimeException(
                'No existe el archivo XLSX:<br><br>' .
                htmlspecialchars(
                    $archivo,
                    ENT_QUOTES,
                    'UTF-8'
                )
            );
        }

        $this->zip = new ZipArchive();

        $resultado = $this->zip->open($archivo);

        if ($resultado !== true) {
            throw new RuntimeException(
                'No se pudo abrir el archivo XLSX. Código ZipArchive: ' .
                $resultado
            );
        }

        $this->cargarSharedStrings();
        $this->buscarHojaPadron();
    }

    // --------------------------------------------------------
    // SHARED STRINGS
    // --------------------------------------------------------

    private function cargarSharedStrings()
    {
        $contenido =
            $this->zip->getFromName(
                'xl/sharedStrings.xml'
            );

        if ($contenido === false) {
            return;
        }

        $xml = simplexml_load_string($contenido);

        if ($xml === false) {
            throw new RuntimeException(
                'sharedStrings.xml está corrupto.'
            );
        }

        foreach ($xml->si as $si) {

            $texto = '';

            if (isset($si->t)) {
                $texto = (string) $si->t;
            } else {
                foreach ($si->r as $r) {
                    $texto .= (string) $r->t;
                }
            }

            $this->sharedStrings[] = $texto;
        }
    }

    // --------------------------------------------------------
    // BUSCAR HOJA
    // --------------------------------------------------------

    private function buscarHojaPadron()
    {
        $workbook =
            $this->zip->getFromName(
                'xl/workbook.xml'
            );

        if ($workbook === false) {
            throw new RuntimeException(
                'No se encontró xl/workbook.xml dentro del XLSX.'
            );
        }

        $xml = simplexml_load_string($workbook);

        if ($xml === false) {
            throw new RuntimeException(
                'workbook.xml está corrupto o no se pudo leer.'
            );
        }

        $namespaces =
            $xml->getNamespaces(true);

        if (!isset($namespaces['r'])) {
            throw new RuntimeException(
                'No se encontró el namespace de relaciones del XLSX.'
            );
        }

        $xml->registerXPathNamespace(
            'main',
            $namespaces['']
        );

        $hojas =
            $xml->xpath(
                '//main:sheets/main:sheet'
            );

        if (
            $hojas === false ||
            count($hojas) === 0
        ) {
            throw new RuntimeException(
                'El XLSX no contiene hojas utilizables.'
            );
        }

        $relaciones =
            $this->zip->getFromName(
                'xl/_rels/workbook.xml.rels'
            );

        if ($relaciones === false) {
            throw new RuntimeException(
                'No se encontró xl/_rels/workbook.xml.rels.'
            );
        }

        $rels =
            simplexml_load_string(
                $relaciones
            );

        if ($rels === false) {
            throw new RuntimeException(
                'workbook.xml.rels está corrupto.'
            );
        }

        $relNamespaces =
            $rels->getNamespaces(true);

        $hojaElegida = null;

        /*
         * Primero buscamos una hoja que contenga
         * "padron" en su nombre.
         */

        foreach ($hojas as $sheet) {

            $nombre =
                strtolower(
                    trim(
                        (string) $sheet['name']
                    )
                );

            if (
                $nombre === 'padron' ||
                strpos(
                    $nombre,
                    'padron'
                ) !== false
            ) {
                $hojaElegida = $sheet;
                break;
            }
        }

        /*
         * Si no existe una hoja llamada padron,
         * utilizamos la primera hoja.
         */

        if ($hojaElegida === null) {
            $hojaElegida = $hojas[0];
        }

        /*
         * Obtener r:id.
         */

        $atributosRel =
            $hojaElegida->attributes(
                $namespaces['r']
            );

        $relId = null;

        if (
            $atributosRel !== null &&
            isset($atributosRel['id'])
        ) {
            $relId =
                trim(
                    (string) $atributosRel['id']
                );
        }

        if (
            $relId === null ||
            $relId === ''
        ) {
            throw new RuntimeException(
                'No se pudo obtener el identificador de la hoja del padrón.'
            );
        }

        /*
         * Buscar la relación rId -> sheetN.xml
         */

        $relacionesEncontradas = [];

        if (isset($relNamespaces[''])) {

            $rels->registerXPathNamespace(
                'rel',
                $relNamespaces['']
            );

            $relacionesEncontradas =
                $rels->xpath(
                    '//rel:Relationship'
                );
        }

        /*
         * Fallback por si el namespace no coincide.
         */

        if (
            $relacionesEncontradas === false ||
            count($relacionesEncontradas) === 0
        ) {
            $relacionesEncontradas =
                $rels->Relationship;
        }

        foreach (
            $relacionesEncontradas as $rel
        ) {

            $id =
                trim(
                    (string) $rel['Id']
                );

            if ($id !== $relId) {
                continue;
            }

            $target =
                trim(
                    (string) $rel['Target']
                );

            if ($target === '') {
                continue;
            }

            $target =
                str_replace(
                    '\\',
                    '/',
                    $target
                );

            $target =
                ltrim(
                    $target,
                    '/'
                );

            if (
                strpos(
                    $target,
                    'xl/'
                ) !== 0
            ) {
                $target =
                    'xl/' . $target;
            }

            /*
             * Comprobar que exista.
             */

            if (
                $this->zip->getFromName(
                    $target
                ) === false
            ) {
                throw new RuntimeException(
                    'La hoja indicada por el XLSX no existe dentro del archivo: ' .
                    htmlspecialchars(
                        $target,
                        ENT_QUOTES,
                        'UTF-8'
                    )
                );
            }

            $this->sheetPath = $target;

            return;
        }

        throw new RuntimeException(
            'No se pudo resolver la relación de la hoja del padrón.'
        );
    }

    // --------------------------------------------------------
    // LETRA DE COLUMNA -> NÚMERO
    // --------------------------------------------------------

    private function numeroColumna($referencia)
    {
        preg_match(
            '/([A-Z]+)[0-9]+/i',
            $referencia,
            $match
        );

        if (!isset($match[1])) {
            return -1;
        }

        $letras =
            strtoupper(
                $match[1]
            );

        $numero = 0;

        for (
            $i = 0;
            $i < strlen($letras);
            $i++
        ) {
            $numero =
                $numero * 26 +
                (
                    ord($letras[$i]) -
                    ord('A') +
                    1
                );
        }

        return $numero - 1;
    }

    // --------------------------------------------------------
    // VALOR DE CELDA
    // --------------------------------------------------------

    private function valorCelda($celda)
    {
        $tipo =
            (string) $celda['t'];

        /*
         * Texto inline.
         */

        if ($tipo === 'inlineStr') {

            $texto = '';

            if (isset($celda->is->t)) {

                $texto =
                    (string) $celda->is->t;

            } else {

                foreach ($celda->is->r as $r) {
                    $texto .= (string) $r->t;
                }
            }

            return limpiarTexto($texto);
        }

        /*
         * Valor normal.
         */

        $valor =
            isset($celda->v)
            ? (string) $celda->v
            : '';

        /*
         * Shared string.
         */

        if ($tipo === 's') {

            $indice =
                (int) $valor;

            return limpiarTexto(
                $this->sharedStrings[$indice] ?? null
            );
        }

        return limpiarTexto($valor);
    }

    // --------------------------------------------------------
    // GENERADOR DE FILAS
    // --------------------------------------------------------

    public function filas()
    {
        $rutaReal =
            realpath(
                $this->archivo
            );

        if ($rutaReal === false) {
            throw new RuntimeException(
                'No se pudo resolver la ruta del XLSX.'
            );
        }

        $xmlReader = new XMLReader();

        /*
         * IMPORTANTE:
         * Para Windows utilizamos la ruta real del ZIP.
         */

        $uri =
            'zip://' .
            $rutaReal .
            '#' .
            $this->sheetPath;

        if (!$xmlReader->open($uri)) {
            throw new RuntimeException(
                'No se pudo abrir la hoja XML del XLSX.'
            );
        }

        while ($xmlReader->read()) {

            if (
                $xmlReader->nodeType === XMLReader::ELEMENT &&
                $xmlReader->name === 'row'
            ) {

                $xmlFila =
                    $xmlReader->readOuterXML();

                $fila =
                    simplexml_load_string(
                        $xmlFila
                    );

                if ($fila === false) {
                    continue;
                }

                $numeroFila =
                    (int) $fila['r'];

                /*
                 * El padrón tiene 43 columnas.
                 */

                $datos =
                    array_fill(
                        0,
                        43,
                        null
                    );

                foreach ($fila->c as $celda) {

                    $referencia =
                        (string) $celda['r'];

                    $columna =
                        $this->numeroColumna(
                            $referencia
                        );

                    if (
                        $columna >= 0 &&
                        $columna < 43
                    ) {

                        $datos[$columna] =
                            $this->valorCelda(
                                $celda
                            );
                    }
                }

                yield [
                    'fila' => $numeroFila,
                    'datos' => $datos
                ];
            }
        }

        $xmlReader->close();
    }

    public function cerrar()
    {
        if ($this->zip) {
            $this->zip->close();
        }
    }
}

// ============================================================
// MAPEAR FILA
// ============================================================

function mapearFila($r)
{
    $jurisdiccion =
        limitarTexto(
            $r[0] ?? null,
            100
        );

    $sector =
        limitarTexto(
            $r[1] ?? null,
            100
        );

    $ambito =
        limitarTexto(
            $r[2] ?? null,
            100
        );

    $departamento =
        limitarTexto(
            $r[3] ?? null,
            255
        );

    $localidad =
        limitarTexto(
            $r[5] ?? null,
            255
        );

    $cueAnexo =
        normalizarCue(
            $r[7] ?? null
        );

    if ($cueAnexo === null) {
        throw new RuntimeException(
            'CUEANEXO vacío.'
        );
    }

    $cue =
        obtenerCue(
            $cueAnexo
        );

    $nombre =
        limitarTexto(
            $r[8] ?? null,
            255
        );

    if ($nombre === null) {
        throw new RuntimeException(
            'Nombre del establecimiento vacío.'
        );
    }

    $direccion =
        limitarTexto(
            $r[9] ?? null,
            255
        );

    $codigoPostal =
        limitarTexto(
            $r[10] ?? null,
            20
        );

    $telefono =
        limitarTexto(
            $r[11] ?? null,
            100
        );

    $email =
        limitarTexto(
            $r[12] ?? null,
            255
        );

    // ========================================================
    // MODALIDADES
    // ========================================================

    $modalidades = [];

    if (esVerdadero($r[13] ?? null)) {
        $modalidades[] = 'Común';
    }

    if (esVerdadero($r[14] ?? null)) {
        $modalidades[] = 'Especial';
    }

    if (esVerdadero($r[15] ?? null)) {
        $modalidades[] = 'Adultos';
    }

    if (
        esVerdadero($r[34] ?? null) ||
        esVerdadero($r[35] ?? null) ||
        esVerdadero($r[36] ?? null)
    ) {
        $modalidades[] = 'Hospitalaria';
    }

    if (esVerdadero($r[37] ?? null)) {
        $modalidades[] = 'Artística';
    }

    $modalidades =
        array_values(
            array_unique(
                $modalidades
            )
        );

    $modalidad =
        !empty($modalidades)
        ? implode(
            ' / ',
            $modalidades
        )
        : null;

    // ========================================================
    // NIVELES
    // ========================================================

    $niveles = [];

    $mapaNiveles = [

        16 => 'Inicial - Jardín maternal',
        17 => 'Inicial - Jardín de infantes',
        18 => 'Primario',
        19 => 'Secundario',
        20 => 'Secundario - INET',
        21 => 'SNU',
        22 => 'SNU - INET',
        23 => 'SNU - Cursos',
        24 => 'Educación temprana',
        25 => 'Inicial - Jardín de infantes',
        26 => 'Primario',
        27 => 'Secundario',
        28 => 'Integración',
        29 => 'Primario - Adultos',
        30 => 'Secundario - Adultos',
        31 => 'Formación Profesional',
        32 => 'Formación Profesional - INET',
        33 => 'Alfabetización',
        34 => 'Inicial - Hospitalaria',
        35 => 'Primario - Hospitalaria',
        36 => 'Secundario - Hospitalaria'
    ];

    foreach (
        $mapaNiveles as
        $indice => $nivelNombre
    ) {

        if (
            esVerdadero(
                $r[$indice] ?? null
            )
        ) {
            $niveles[] =
                $nivelNombre;
        }
    }

    $niveles =
        array_values(
            array_unique(
                $niveles
            )
        );

    $nivel =
        !empty($niveles)
        ? implode(
            ' / ',
            $niveles
        )
        : null;

    // ========================================================
    // OFERTA EDUCATIVA
    // ========================================================

    $ofertas = [];

    $mapaOfertas = [

        16 => 'Común: Inicial - Jardín maternal',
        17 => 'Común: Inicial - Jardín de infantes',
        18 => 'Común: Primario',
        19 => 'Común: Secundario',
        20 => 'Común: Secundario - INET',
        21 => 'Común: SNU',
        22 => 'Común: SNU - INET',
        23 => 'Común: SNU - Cursos',
        24 => 'Especial: Educación temprana',
        25 => 'Especial: Inicial - Jardín de infantes',
        26 => 'Especial: Primario',
        27 => 'Especial: Secundario',
        28 => 'Especial: Integración',
        29 => 'Adultos: Primario',
        30 => 'Adultos: Secundario',
        31 => 'Adultos: Formación Profesional',
        32 => 'Adultos: Formación Profesional - INET',
        33 => 'Adultos: Alfabetización',
        34 => 'Hospitalaria: Inicial',
        35 => 'Hospitalaria: Primario',
        36 => 'Hospitalaria: Secundario',
        37 => 'Artística: Talleres'
    ];

    foreach (
        $mapaOfertas as
        $indice => $descripcion
    ) {

        if (
            esVerdadero(
                $r[$indice] ?? null
            )
        ) {
            $ofertas[] =
                $descripcion;
        }
    }

    if (esVerdadero($r[38] ?? null)) {
        $ofertas[] =
            'Servicios complementarios';
    }

    $ofertas =
        array_values(
            array_unique(
                $ofertas
            )
        );

    $ofertaEducativa =
        !empty($ofertas)
        ? implode(
            ' | ',
            $ofertas
        )
        : null;

    // ========================================================
    // RESULTADO
    // ========================================================

    return [

        'cue' =>
            $cue,

        'cue_anexo' =>
            $cueAnexo,

        'nombre' =>
            $nombre,

        'nombre_abreviado' =>
            $nombre,

        'provincia' =>
            $jurisdiccion,

        'jurisdiccion' =>
            $jurisdiccion,

        'departamento' =>
            $departamento,

        'localidad' =>
            $localidad,

        'barrio' =>
            null,

        'direccion' =>
            $direccion,

        'numero' =>
            null,

        'codigo_postal' =>
            $codigoPostal,

        'lat' =>
            null,

        'lng' =>
            null,

        'nivel' =>
            limitarTexto(
                $nivel,
                150
            ),

        'modalidad' =>
            limitarTexto(
                $modalidad,
                150
            ),

        'orientacion' =>
            null,

        'tipo' =>
            limitarTexto(
                !empty($modalidades)
                ? implode(
                    ' / ',
                    $modalidades
                )
                : null,
                100
            ),

        'gestion' =>
            $sector,

        'sector' =>
            $sector,

        'ambito' =>
            $ambito,

        'turno' =>
            null,

        'jornada' =>
            null,

        'telefono' =>
            $telefono,

        'email' =>
            $email,

        'web' =>
            null,

        'oferta_educativa' =>
            limitarTexto(
                $ofertaEducativa,
                2000
            ),

        'dependencia' =>
            null,

        'estado' =>
            'Activo',

        'rating' =>
            null,

        'img' =>
            null,

        'cert' =>
            null,

        'fuente' =>
            FUENTE_PADRON,

        'fecha_actualizacion' =>
            FECHA_PADRON
    ];
}

// ============================================================
// IMPORTADOR
// ============================================================

function importarPadron(
    $archivo,
    $limite = null
) {

    $resultado = [

        'procesadas' => 0,
        'insertadas' => 0,
        'actualizadas' => 0,
        'omitidas' => 0,
        'errores' => 0,
        'mensajes' => []
    ];

    if (!file_exists($archivo)) {

        throw new RuntimeException(
            'No se encontró el archivo XLSX: ' .
            basename($archivo)
        );
    }

    $db =
        conectarBD();

    // ========================================================
    // COMPROBAR TABLA
    // ========================================================

    $tabla =
        $db->query(
            "SHOW TABLES LIKE 'escuelas'"
        );

    if ($tabla->num_rows === 0) {

        $db->close();

        throw new RuntimeException(
            'La tabla escuelas no existe en la base de datos escuelas360.'
        );
    }

    // ========================================================
    // INSERT / UPDATE
    // ========================================================

    $sql = "

        INSERT INTO escuelas (

            cue,
            cue_anexo,
            nombre,
            nombre_abreviado,
            provincia,
            jurisdiccion,
            departamento,
            localidad,
            barrio,
            direccion,
            numero,
            codigo_postal,
            lat,
            lng,
            nivel,
            modalidad,
            orientacion,
            tipo,
            gestion,
            sector,
            ambito,
            turno,
            jornada,
            telefono,
            email,
            web,
            oferta_educativa,
            dependencia,
            estado,
            rating,
            img,
            cert,
            fuente,
            fecha_actualizacion

        )

        VALUES (

            ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?,
            ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?,
            ?, ?

        )

        ON DUPLICATE KEY UPDATE

            cue =
                VALUES(cue),

            nombre =
                VALUES(nombre),

            nombre_abreviado =
                VALUES(nombre_abreviado),

            provincia =
                VALUES(provincia),

            jurisdiccion =
                VALUES(jurisdiccion),

            departamento =
                VALUES(departamento),

            localidad =
                VALUES(localidad),

            barrio =
                VALUES(barrio),

            direccion =
                VALUES(direccion),

            numero =
                VALUES(numero),

            codigo_postal =
                VALUES(codigo_postal),

            nivel =
                VALUES(nivel),

            modalidad =
                VALUES(modalidad),

            orientacion =
                VALUES(orientacion),

            tipo =
                VALUES(tipo),

            gestion =
                VALUES(gestion),

            sector =
                VALUES(sector),

            ambito =
                VALUES(ambito),

            turno =
                VALUES(turno),

            jornada =
                VALUES(jornada),

            telefono =
                VALUES(telefono),

            email =
                VALUES(email),

            web =
                VALUES(web),

            oferta_educativa =
                VALUES(oferta_educativa),

            dependencia =
                VALUES(dependencia),

            estado =
                VALUES(estado),

            fuente =
                VALUES(fuente),

            fecha_actualizacion =
                VALUES(fecha_actualizacion),

            updated_at =
                CURRENT_TIMESTAMP
    ";

    $stmt =
        $db->prepare($sql);

    /*
     * ========================================================
     * TIPOS CORRECTOS
     * ========================================================
     *
     * 35 parámetros:
     *
     * 12 strings
     * 2 doubles
     * 21 strings
     *
     * TOTAL = 35
     */

$tipos =
    'ssssssssssss' .
    'dd' .
    'ssssssssssssssssssss';

/*
 * El INSERT tiene exactamente 34 parámetros:
 *
 * 12 strings
 * 2 doubles (lat y lng)
 * 20 strings
 *
 * Total: 34
 */
if (
    strlen($tipos) !== 34
) {
    $stmt->close();
    $db->close();

    throw new RuntimeException(
        'Error interno: la cantidad de tipos de parámetros no coincide con las columnas. ' .
        'Se esperaban 34 y se encontraron ' .
        strlen($tipos) .
        '.'
    );
}



    $reader =
        new XLSXReader(
            $archivo
        );

    try {

        foreach (
            $reader->filas()
            as $filaInfo
        ) {

            $numeroFila =
                $filaInfo['fila'];

            $r =
                $filaInfo['datos'];

            /*
             * Ignorar encabezados.
             */

            if (
                $numeroFila <
                FILA_INICIO_DATOS
            ) {
                continue;
            }

            /*
             * Límite de prueba.
             */

            if (
                $limite !== null &&
                $resultado['procesadas'] >=
                $limite
            ) {
                break;
            }

            try {

                $escuela =
                    mapearFila(
                        $r
                    );

                if (
                    empty(
                        $escuela['cue_anexo']
                    )
                ) {

                    $resultado['omitidas']++;

                    continue;
                }

                // ====================================================
                // VARIABLES
                // ====================================================

                $cue =
                    $escuela['cue'];

                $cueAnexo =
                    $escuela['cue_anexo'];

                $nombre =
                    $escuela['nombre'];

                $nombreAbreviado =
                    $escuela['nombre_abreviado'];

                $provincia =
                    $escuela['provincia'];

                $jurisdiccion =
                    $escuela['jurisdiccion'];

                $departamento =
                    $escuela['departamento'];

                $localidad =
                    $escuela['localidad'];

                $barrio =
                    $escuela['barrio'];

                $direccion =
                    $escuela['direccion'];

                $numero =
                    $escuela['numero'];

                $codigoPostal =
                    $escuela['codigo_postal'];

                $lat =
                    $escuela['lat'];

                $lng =
                    $escuela['lng'];

                $nivel =
                    $escuela['nivel'];

                $modalidad =
                    $escuela['modalidad'];

                $orientacion =
                    $escuela['orientacion'];

                $tipo =
                    $escuela['tipo'];

                $gestion =
                    $escuela['gestion'];

                $sector =
                    $escuela['sector'];

                $ambito =
                    $escuela['ambito'];

                $turno =
                    $escuela['turno'];

                $jornada =
                    $escuela['jornada'];

                $telefono =
                    $escuela['telefono'];

                $email =
                    $escuela['email'];

                $web =
                    $escuela['web'];

                $ofertaEducativa =
                    $escuela['oferta_educativa'];

                $dependencia =
                    $escuela['dependencia'];

                $estado =
                    $escuela['estado'];

                $rating =
                    $escuela['rating'];

                $img =
                    $escuela['img'];

                $cert =
                    $escuela['cert'];

                $fuente =
                    $escuela['fuente'];

                $fechaActualizacion =
                    $escuela['fecha_actualizacion'];

                // ====================================================
                // BIND
                // ====================================================

                $stmt->bind_param(

                    $tipos,

                    $cue,
                    $cueAnexo,
                    $nombre,
                    $nombreAbreviado,

                    $provincia,
                    $jurisdiccion,
                    $departamento,
                    $localidad,
                    $barrio,

                    $direccion,
                    $numero,
                    $codigoPostal,

                    $lat,
                    $lng,

                    $nivel,
                    $modalidad,
                    $orientacion,
                    $tipo,

                    $gestion,
                    $sector,
                    $ambito,

                    $turno,
                    $jornada,

                    $telefono,
                    $email,
                    $web,

                    $ofertaEducativa,
                    $dependencia,
                    $estado,

                    $rating,
                    $img,
                    $cert,

                    $fuente,
                    $fechaActualizacion
                );

                $stmt->execute();

                /*
                 * affected_rows:
                 *
                 * 1 = INSERT
                 * 2 = UPDATE
                 * 0 = UPDATE sin cambios
                 */

                if (
                    $stmt->affected_rows === 1
                ) {

                    $resultado['insertadas']++;

                } elseif (
                    $stmt->affected_rows === 2
                ) {

                    $resultado['actualizadas']++;

                } elseif (
                    $stmt->affected_rows === 0
                ) {

                    $resultado['actualizadas']++;
                }

                $resultado['procesadas']++;

            } catch (Throwable $e) {

                $resultado['errores']++;

                if (
                    count(
                        $resultado['mensajes']
                    ) < 20
                ) {

                    $resultado['mensajes'][] =
                        'Fila ' .
                        $numeroFila .
                        ': ' .
                        $e->getMessage();
                }
            }
        }

    } finally {

        $reader->cerrar();
        $stmt->close();
        $db->close();
    }

    return $resultado;
}

// ============================================================
// MODO DE EJECUCIÓN
// ============================================================

$modo =
    isset($_GET['modo'])
    ? strtolower(
        trim(
            (string) $_GET['modo']
        )
    )
    : null;

$resultado = null;
$error = null;
$inicio = null;

if ($modo !== null) {

    $inicio =
        microtime(true);

    try {

        if ($modo === 'prueba') {

            $resultado =
                importarPadron(
                    $archivoXlsx,
                    LIMITE_PRUEBA
                );

        } elseif ($modo === 'completo') {

            $resultado =
                importarPadron(
                    $archivoXlsx,
                    null
                );

        } else {

            throw new RuntimeException(
                'Modo de importación inválido.'
            );
        }

    } catch (Throwable $e) {

        $error =
            $e->getMessage();
    }
}

$tiempo =
    $inicio !== null
    ? round(
        microtime(true) -
        $inicio,
        2
    )
    : null;

?>

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Importador Padrón - Colegio 360
</title>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;
    padding: 40px 20px;

    background: #f3f4f6;
    color: #111827;

    font-family:
        Arial,
        Helvetica,
        sans-serif;
}

.contenedor {

    width: 100%;
    max-width: 900px;
    margin: auto;
}

.card {

    background: white;

    border-radius: 18px;

    padding: 32px;

    box-shadow:
        0 10px 35px
        rgba(0, 0, 0, .08);
}

h1 {

    margin:
        0 0 8px;
}

.subtitulo {

    color: #6b7280;

    margin-bottom:
        30px;
}

.archivo {

    padding: 18px;

    background: #f9fafb;

    border:
        1px solid #e5e7eb;

    border-radius: 12px;

    margin-bottom:
        20px;

    word-break:
        break-word;
}

.info {

    padding: 18px;

    background: #eff6ff;

    border:
        1px solid #bfdbfe;

    border-radius: 12px;

    margin:
        20px 0;

    color: #1e40af;

    line-height:
        1.6;
}

.warning {

    padding: 18px;

    background: #fff7ed;

    border:
        1px solid #fed7aa;

    border-radius: 12px;

    margin:
        20px 0;

    color: #9a3412;

    line-height:
        1.6;
}

.error {

    padding: 18px;

    background: #fef2f2;

    border:
        1px solid #fecaca;

    border-radius: 12px;

    color: #991b1b;

    margin-bottom:
        20px;

    line-height:
        1.6;
}

.ok {

    padding: 18px;

    background: #ecfdf5;

    border:
        1px solid #a7f3d0;

    border-radius: 12px;

    color: #065f46;

    margin-bottom:
        20px;

    line-height:
        1.6;
}

.botones {

    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(220px, 1fr)
        );

    gap: 15px;

    margin-top:
        25px;
}

.boton {

    display: block;

    width: 100%;

    border: 0;

    border-radius: 12px;

    padding: 16px;

    font-size: 16px;

    font-weight: bold;

    cursor: pointer;

    text-align: center;

    text-decoration: none;

    transition:
        opacity .2s,
        transform .1s;
}

.boton:hover {

    opacity: .88;

    transform:
        translateY(-1px);
}

.boton.prueba {

    background: #e5e7eb;
    color: #111827;
}

.boton.completo {

    background: #111827;
    color: white;
}

.boton.procesando {

    pointer-events: none;

    opacity: .5;
}

.grid {

    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(150px, 1fr)
        );

    gap: 15px;

    margin:
        25px 0;
}

.stat {

    padding: 20px;

    background: #f9fafb;

    border:
        1px solid #e5e7eb;

    border-radius: 12px;
}

.stat-numero {

    font-size: 28px;
    font-weight: bold;
}

.stat-texto {

    margin-top: 5px;

    color: #6b7280;
}

.errores {

    margin-top: 20px;

    padding: 18px;

    background: #fff7ed;

    border:
        1px solid #fed7aa;

    border-radius: 12px;
}

.errores li {

    margin-bottom:
        8px;
}

.codigo {

    font-family:
        Consolas,
        monospace;

    background: #111827;

    color: #e5e7eb;

    padding:
        3px 7px;

    border-radius: 5px;
}

</style>

</head>

<body>

<div class="contenedor">

<div class="card">

<h1>
🏫 Colegio 360
</h1>

<div class="subtitulo">

Importador del Padrón Oficial de Establecimientos Educativos

</div>

<?php if ($error !== null): ?>

<div class="error">

<strong>
❌ Error
</strong>

<br><br>

<?= $error ?>

</div>

<?php endif; ?>

<?php if ($resultado !== null): ?>

<div class="ok">

<strong>
✅ Importación finalizada
</strong>

<br><br>

Tiempo de ejecución:

<strong>

<?= htmlspecialchars(
    (string) $tiempo
) ?>

segundos

</strong>

</div>

<div class="grid">

<div class="stat">

<div class="stat-numero">

<?= number_format(
    $resultado['procesadas'],
    0,
    ',',
    '.'
) ?>

</div>

<div class="stat-texto">
Procesadas
</div>

</div>

<div class="stat">

<div class="stat-numero">

<?= number_format(
    $resultado['insertadas'],
    0,
    ',',
    '.'
) ?>

</div>

<div class="stat-texto">
Nuevas
</div>

</div>

<div class="stat">

<div class="stat-numero">

<?= number_format(
    $resultado['actualizadas'],
    0,
    ',',
    '.'
) ?>

</div>

<div class="stat-texto">
Actualizadas
</div>

</div>

<div class="stat">

<div class="stat-numero">

<?= number_format(
    $resultado['omitidas'],
    0,
    ',',
    '.'
) ?>

</div>

<div class="stat-texto">
Omitidas
</div>

</div>

<div class="stat">

<div class="stat-numero">

<?= number_format(
    $resultado['errores'],
    0,
    ',',
    '.'
) ?>

</div>

<div class="stat-texto">
Errores
</div>

</div>

</div>

<?php if (!empty($resultado['mensajes'])): ?>

<div class="errores">

<strong>
⚠️ Primeros errores encontrados
</strong>

<ul>

<?php foreach (
    $resultado['mensajes']
    as $mensaje
): ?>

<li>

<?= htmlspecialchars(
    $mensaje,
    ENT_QUOTES,
    'UTF-8'
) ?>

</li>

<?php endforeach; ?>

</ul>

</div>

<?php endif; ?>

<div class="info">

<strong>
Fuente:
</strong>

Padrón Oficial de Establecimientos Educativos

<br><br>

<strong>
Fecha del padrón:
</strong>

16/06/2026

</div>

<?php else: ?>

<div class="archivo">

<strong>
📄 Archivo:
</strong>

<?= htmlspecialchars(
    basename($archivoXlsx),
    ENT_QUOTES,
    'UTF-8'
) ?>

<br><br>

<strong>
📁 Ubicación:
</strong>

<?= htmlspecialchars(
    __DIR__,
    ENT_QUOTES,
    'UTF-8'
) ?>

</div>

<div class="info">

<strong>
El importador hará lo siguiente:
</strong>

<br><br>

✓ Leer las 43 columnas del XLSX<br>
✓ Procesar los establecimientos oficiales<br>
✓ Guardarlos en
<span class="codigo">
escuelas
</span>
<br>
✓ Evitar duplicados mediante
<span class="codigo">
cue_anexo
</span>
<br>
✓ Actualizar establecimientos existentes<br>
✓ Mantener teléfono, email, domicilio y localidad<br>
✓ Crear nivel, modalidad y oferta educativa<br>
✓ Guardar fecha 16/06/2026<br>
✓ Dejar lat/lng preparados para Georef<br>
✓ No inventar rating, imágenes ni coordenadas

</div>

<div class="warning">

<strong>
⚠️ Recomendación
</strong>

<br><br>

Primero ejecutá el modo de prueba.

Solo va a importar

<strong>
20 establecimientos
</strong>.

Si esos 20 aparecen correctamente en phpMyAdmin,
después ejecutamos la importación completa.

</div>

<div class="botones">

<a
    href="?modo=prueba"
    class="boton prueba"
    onclick="procesando(this)"
>
🧪 Probar con 20 escuelas
</a>

<a
    href="?modo=completo"
    class="boton completo"
    onclick="procesando(this)"
>
🚀 Importar todo el padrón
</a>

</div>

<?php endif; ?>

</div>

</div>

<script>

function procesando(boton)
{
    boton.classList.add(
        'procesando'
    );

    boton.innerText =
        '⏳ Procesando...';
}

</script>

</body>

</html>
```
