-- Colegio 360 - migración de base de datos
-- Ejecutar en phpMyAdmin seleccionando la base escuelas360.
-- IMPORTANTE: copiar SOLO este SQL; no incluir ``` ni otros textos.

USE escuelas360;

START TRANSACTION;

-- Relaciona cada reseña con el usuario que la escribió.
ALTER TABLE comentarios
    ADD COLUMN usuario_id INT NULL AFTER escuela_id;

ALTER TABLE comentarios
    ADD KEY idx_comentarios_usuario (usuario_id);

ALTER TABLE comentarios
    ADD CONSTRAINT fk_comentarios_usuario
    FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE;

-- Favoritos guardados por cuenta.
CREATE TABLE favoritos (
    id INT NOT NULL AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    escuela_id INT NOT NULL,
    fecha_guardado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_favorito_usuario_escuela (usuario_id, escuela_id),
    KEY idx_favoritos_usuario (usuario_id),
    KEY idx_favoritos_escuela (escuela_id),
    CONSTRAINT fk_favoritos_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- Colegios seleccionados para comparar por cuenta.
CREATE TABLE comparaciones (
    id INT NOT NULL AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    escuela_id INT NOT NULL,
    fecha_agregado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_comparacion_usuario_escuela (usuario_id, escuela_id),
    KEY idx_comparaciones_usuario (usuario_id),
    KEY idx_comparaciones_escuela (escuela_id),
    CONSTRAINT fk_comparaciones_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

COMMIT;
