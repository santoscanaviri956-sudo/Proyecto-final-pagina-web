<?php
header('Location: inicio.html', true, 302);
exit;
