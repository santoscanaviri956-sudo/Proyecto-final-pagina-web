-- Colegio 360 — migración EduAI + ajustes por usuario
-- Ejecutar sobre la base escuelas360.

USE escuelas360;
START TRANSACTION;

-- 1) Preferencias persistentes por usuario.
CREATE TABLE IF NOT EXISTS configuraciones_usuario (
  id INT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  tema VARCHAR(20) NOT NULL DEFAULT 'claro',
  texto_grande TINYINT(1) NOT NULL DEFAULT 0,
  nivel_preferido VARCHAR(50) DEFAULT NULL,
  barrio_preferido VARCHAR(100) DEFAULT NULL,
  orientacion_preferida VARCHAR(100) DEFAULT NULL,
  notificaciones_email TINYINT(1) NOT NULL DEFAULT 1,
  actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_config_usuario (usuario_id),
  CONSTRAINT fk_config_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) En proyectos que ya tienen configuraciones_usuario, agrega los campos faltantes.
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='configuraciones_usuario' AND COLUMN_NAME='texto_grande')=0,
  'ALTER TABLE configuraciones_usuario ADD COLUMN texto_grande TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='configuraciones_usuario' AND COLUMN_NAME='nivel_preferido')=0,
  'ALTER TABLE configuraciones_usuario ADD COLUMN nivel_preferido VARCHAR(50) DEFAULT NULL', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='configuraciones_usuario' AND COLUMN_NAME='barrio_preferido')=0,
  'ALTER TABLE configuraciones_usuario ADD COLUMN barrio_preferido VARCHAR(100) DEFAULT NULL', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='configuraciones_usuario' AND COLUMN_NAME='orientacion_preferida')=0,
  'ALTER TABLE configuraciones_usuario ADD COLUMN orientacion_preferida VARCHAR(100) DEFAULT NULL', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='configuraciones_usuario' AND COLUMN_NAME='notificaciones_email')=0,
  'ALTER TABLE configuraciones_usuario ADD COLUMN notificaciones_email TINYINT(1) NOT NULL DEFAULT 1', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2b) Inicializar las preferencias de notificaciones de usuarios existentes
-- respetando el valor que ya tenían en usuarios.notif_email.
INSERT IGNORE INTO configuraciones_usuario (usuario_id, notificaciones_email)
SELECT id, COALESCE(notif_email, 1)
FROM usuarios;

-- 3) Historial de conversaciones de EduAI. Solo se guarda para usuarios autenticados.
CREATE TABLE IF NOT EXISTS eduai_conversaciones (
  id INT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  pregunta TEXT NOT NULL,
  respuesta TEXT NOT NULL,
  contexto LONGTEXT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_eduai_usuario_fecha (usuario_id, fecha),
  CONSTRAINT fk_eduai_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;
