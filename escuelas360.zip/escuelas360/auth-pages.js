(() => {
  const path = location.pathname.toLowerCase();
  const isRegister = path.endsWith('registro.html');
  const form = document.getElementById(isRegister ? 'register-form' : 'login-form');
  const error = document.getElementById('auth-error');
  const submit = document.getElementById('submit');
  const params = new URLSearchParams(location.search);
  const returnTo = (() => {
    const raw = params.get('return') || 'inicio.html';
    // Only allow local relative destinations.
    if (/^https?:\/\//i.test(raw) || raw.startsWith('//') || raw.includes('\\')) return 'inicio.html';
    return raw.replace(/^\/+/, '') || 'inicio.html';
  })();
  const showError = msg => { if (!error) return; error.textContent = msg || ''; error.style.display = msg ? 'block' : 'none'; };
  const goBack = () => { location.href = returnTo; };
  document.querySelectorAll('[data-auth-target]').forEach(a => { const target=a.dataset.authTarget; a.href = target==='inicio' ? returnTo : `${target}.html?return=${encodeURIComponent(returnTo)}`; });

  if (form) form.addEventListener('submit', async e => {
    e.preventDefault(); showError(''); if (submit) { submit.disabled = true; submit.textContent = 'Procesando…'; }
    try {
      const payload = isRegister ? {
        nombre: document.getElementById('nombre').value.trim(),
        email: document.getElementById('email').value.trim().toLowerCase(),
        birth_year: Number(document.getElementById('birth_year').value),
        password: document.getElementById('password').value
      } : { email: document.getElementById('email').value.trim().toLowerCase(), password: document.getElementById('password').value };
      const endpoint = isRegister ? 'registro.php' : 'login.php';
      const r = await fetch(endpoint, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
      const data = await r.json();
      if (!r.ok || !data.success) throw new Error(data.error || 'No se pudo completar la operación.');
      goBack();
    } catch (err) { showError(err.message || 'No se pudo conectar con el servidor.'); }
    finally { if (submit) { submit.disabled = false; submit.textContent = isRegister ? 'Crear cuenta' : 'Ingresar'; } }
  });

  const googleBtn = document.getElementById('google-btn');
  let pendingGoogleCredential = null;
  let googlePasswordBox = null;

  function showGooglePasswordBox() {
    if (googlePasswordBox) { googlePasswordBox.style.display='block'; googlePasswordBox.querySelector('input')?.focus(); return; }
    googlePasswordBox=document.createElement('div');
    googlePasswordBox.className='google-password-box';
    googlePasswordBox.style.display='block';
    googlePasswordBox.innerHTML=`<strong>${isRegister?'Creá tu contraseña':'Ingresá tu contraseña'}</strong><p>${isRegister?'Esta contraseña será la que uses para futuros inicios de sesión en Colegio 360.':'Además de verificar tu cuenta de Google, necesitamos tu contraseña de Colegio 360.'}</p><div class="page-auth-field"><label for="google_password">Contraseña</label><input id="google_password" type="password" minlength="6" autocomplete="${isRegister?'new-password':'current-password'}" placeholder="Mínimo 6 caracteres"></div><button class="btn btn-primary" id="google-password-continue" type="button">${isRegister?'Crear cuenta':'Iniciar sesión'}</button>`;
    googleBtn?.parentNode?.insertBefore(googlePasswordBox, googleBtn.nextSibling);
    googlePasswordBox.querySelector('#google-password-continue')?.addEventListener('click',()=>finishGoogle(pendingGoogleCredential, true).catch(err=>showError(err.message||'No se pudo completar el acceso.')));
  }

  async function loadGoogle() {
    if (window.google?.accounts?.id) return;
    await new Promise((resolve, reject) => {
      const existing = document.querySelector('script[data-google-gsi]');
      if (existing) { existing.addEventListener('load', resolve, {once:true}); existing.addEventListener('error', reject, {once:true}); return; }
      const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.defer = true; s.dataset.googleGsi = '1';
      s.onload = resolve; s.onerror = () => reject(new Error('No se pudo cargar Google Identity Services.')); document.head.appendChild(s);
    });
    if (!window.google?.accounts?.id) throw new Error('Google Identity Services no está disponible.');
  }

  async function finishGoogle(credential, withPassword=false) {
    if (!credential) return;
    const payload={credential,mode:isRegister?'register':'login'};
    if(withPassword){ payload.password=document.getElementById('google_password')?.value||''; if(payload.password.length<6){showError('La contraseña debe tener al menos 6 caracteres.');return;} }
    const r=await fetch('google-login.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data=await r.json();
    if(data.needs_google_password){ pendingGoogleCredential=credential; showGooglePasswordBox(); showError(isRegister?'Creá una contraseña para terminar el registro.':'Ingresá la contraseña de Colegio 360 para continuar.'); return; }
    if(!r.ok||!data.success) throw new Error(data.error||'Google no pudo completar el acceso.');
    goBack();
  }

  async function startGoogle() {
    showError('');
    try {
      const cfgResponse=await fetch('google-config.php',{credentials:'same-origin',cache:'no-store'});
      if(!cfgResponse.ok) throw new Error('No se pudo leer google-config.php.');
      const cfg=await cfgResponse.json(); if(!cfg.client_id) throw new Error('Falta el Client ID de Google en google-config.php.');
      await loadGoogle();
      google.accounts.id.initialize({client_id:cfg.client_id,callback:async response=>{try{await finishGoogle(response.credential,false);}catch(err){showError(err.message||'No se pudo completar el acceso con Google.');}},auto_select:false,cancel_on_tap_outside:true});
      if(googleBtn){googleBtn.innerHTML='';google.accounts.id.renderButton(googleBtn,{type:'standard',theme:'outline',size:'large',text:isRegister?'signup_with':'signin_with',shape:'rectangular',width:390,logo_alignment:'left'});}
    } catch(err) { showError(err.message||'No se pudo cargar Google Identity Services.'); if(googleBtn)googleBtn.textContent=isRegister?'Registrarme con Google':'Iniciar sesión con Google'; }
  }

  if(googleBtn) startGoogle();
  if(params.get('google')==='1'&&googleBtn)setTimeout(()=>googleBtn.scrollIntoView({behavior:'smooth',block:'center'}),450);
})();
