<?php
declare(strict_types=1);

/*
 * EduAI — configuración del asistente.
 *
 * Prioridad para la clave:
 * 1) variable de entorno GEMINI_API_KEY
 * 2) archivo local eduai-config.local.php (no se debe versionar)
 *
 * El ZIP no incluye ninguna clave activa.
 */

$localConfigFile = __DIR__ . '/eduai-config.local.php';
$localConfig = [];
if (is_file($localConfigFile)) {
    $loaded = require $localConfigFile;
    if (is_array($loaded)) {
        $localConfig = $loaded;
    }
}

$envKey = trim((string) (getenv('GEMINI_API_KEY') ?: ($_ENV['GEMINI_API_KEY'] ?? ($_SERVER['GEMINI_API_KEY'] ?? ''))));
$localKey = trim((string) ($localConfig['GEMINI_API_KEY'] ?? ''));

define('GEMINI_API_KEY', $envKey !== '' ? $envKey : $localKey);
define('EDUAI_MODEL', 'gemini-3.8-flash');
define('EDUAI_MAX_SCHOOLS_IN_CONTEXT', 18);
define('EDUAI_MAX_VISIBLE_SCHOOLS', 10);
define('EDUAI_MAX_HISTORY', 10);
define('EDUAI_STREAM', true);
define('EDUAI_API_BASE_URL', '');
define('EDUAI_DB_HOST', 'localhost');
define('EDUAI_DB_NAME', 'escuelas360');
define('EDUAI_DB_USER', 'root');
define('EDUAI_DB_PASS', '');
