-- Colegio 360 - migración completa del esquema de escuelas y limpieza de selecciones de prueba
-- Ejecutar en phpMyAdmin sobre la base `escuelas360`.
-- Esta migración NO borra usuarios ni colegios.

USE escuelas360;

START TRANSACTION;

-- ============================================================
-- 1) Completar `escuelas` para que coincida con escuelas.php
--    e importar_padron.php.
-- ============================================================

ALTER TABLE escuelas
  ADD COLUMN cue VARCHAR(30) NULL,
  ADD COLUMN cue_anexo VARCHAR(30) NULL,
  ADD COLUMN nombre_abreviado VARCHAR(255) NULL,
  ADD COLUMN provincia VARCHAR(100) NULL,
  ADD COLUMN jurisdiccion VARCHAR(150) NULL,
  ADD COLUMN departamento VARCHAR(150) NULL,
  ADD COLUMN localidad VARCHAR(150) NULL,
  ADD COLUMN barrio VARCHAR(150) NULL,
  ADD COLUMN numero VARCHAR(30) NULL,
  ADD COLUMN codigo_postal VARCHAR(20) NULL,
  ADD COLUMN lat DECIMAL(10,7) NULL,
  ADD COLUMN lng DECIMAL(10,7) NULL,
  ADD COLUMN nivel VARCHAR(150) NULL,
  ADD COLUMN modalidad VARCHAR(150) NULL,
  ADD COLUMN orientacion VARCHAR(255) NULL,
  ADD COLUMN tipo VARCHAR(150) NULL,
  ADD COLUMN gestion VARCHAR(100) NULL,
  ADD COLUMN sector VARCHAR(100) NULL,
  ADD COLUMN ambito VARCHAR(100) NULL,
  ADD COLUMN turno VARCHAR(100) NULL,
  ADD COLUMN jornada VARCHAR(100) NULL,
  ADD COLUMN telefono VARCHAR(100) NULL,
  ADD COLUMN email VARCHAR(190) NULL,
  ADD COLUMN web VARCHAR(255) NULL,
  ADD COLUMN oferta_educativa TEXT NULL,
  ADD COLUMN dependencia VARCHAR(255) NULL,
  ADD COLUMN estado VARCHAR(100) NULL,
  ADD COLUMN rating DECIMAL(3,2) NULL,
  ADD COLUMN img TEXT NULL,
  ADD COLUMN cert VARCHAR(255) NULL,
  ADD COLUMN fuente VARCHAR(255) NULL,
  ADD COLUMN fecha_actualizacion DATE NULL,
  ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- `cuota`, `matricula`, `metodologia`, `becas` y `servicios`
-- ya existen en el esquema que me pasaste.

UPDATE escuelas
SET nivel = COALESCE(NULLIF(nivel,''), nivel_educativo),
    gestion = COALESCE(NULLIF(gestion,''), tipo_gestion),
    email = COALESCE(NULLIF(email,''), email_contacto)
WHERE nivel_educativo IS NOT NULL
   OR tipo_gestion IS NOT NULL
   OR email_contacto IS NOT NULL;

-- El CUE anexo es el identificador estable que utiliza el padrón.
-- Si ya existe un índice equivalente, phpMyAdmin puede omitir esta línea.
ALTER TABLE escuelas ADD UNIQUE KEY uq_escuelas_cue_anexo (cue_anexo);

-- ============================================================
-- 2) La información personal/preferencias por usuario ya está
--    contemplada: usuarios + configuraciones_usuario.
--    Favoritos y comparaciones también son por usuario.
-- ============================================================

-- Asegurar columnas de configuración que usa la página.
ALTER TABLE configuraciones_usuario
  ADD COLUMN actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- ============================================================
-- 3) IMPORTANTE: quitar las 3 selecciones de prueba del usuario 1
--    que aparecen en el dump recibido.
--
--    Si esas selecciones SÍ son reales y querés conservarlas,
--    NO ejecutes estas dos líneas.
-- ============================================================

DELETE FROM favoritos
WHERE usuario_id = 1
  AND escuela_id IN (20000100, 20000102, 20000200);

DELETE FROM comparaciones
WHERE usuario_id = 1
  AND escuela_id IN (20000100, 20000102, 20000200);

COMMIT;
